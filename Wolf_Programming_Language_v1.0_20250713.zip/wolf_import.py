#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Wolf Programming Language - Import Module
Модуль для импорта внешних Python библиотек
"""

import importlib
import sys
from typing import Any, Dict, Optional

class WolfImportManager:
    """Менеджер импорта для Wolf"""
    
    def __init__(self):
        self.imported_modules = {}
        self.aliases = {}
    
    def подключить(self, имя_библиотеки: str, псевдоним: str = None) -> Any:
        """
        Подключить внешнюю Python библиотеку
        
        Args:
            имя_библиотеки: Имя библиотеки для импорта
            псевдоним: Псевдоним для библиотеки
            
        Returns:
            Импортированная библиотека
        """
        try:
            # Проверяем, не импортирована ли уже
            if имя_библиотеки in self.imported_modules:
                module = self.imported_modules[имя_библиотеки]
                print(f"✅ Библиотека '{имя_библиотеки}' уже подключена")
            else:
                # Импортируем библиотеку
                module = importlib.import_module(имя_библиотеки)
                self.imported_modules[имя_библиотеки] = module
                print(f"📚 Библиотека '{имя_библиотеки}' успешно подключена")
            
            # Сохраняем псевдоним если указан
            if псевдоним:
                self.aliases[псевдоним] = module
                print(f"🏷️ Псевдоним '{псевдоним}' установлен")
            
            return module
            
        except ImportError as e:
            print(f"❌ Ошибка импорта '{имя_библиотеки}': {e}")
            print("💡 Убедитесь, что библиотека установлена: pip install " + имя_библиотеки)
            return None
        except Exception as e:
            print(f"❌ Неожиданная ошибка при импорте '{имя_библиотеки}': {e}")
            return None
    
    def получить_модуль(self, имя: str) -> Any:
        """Получить импортированный модуль по имени или псевдониму"""
        if имя in self.aliases:
            return self.aliases[имя]
        elif имя in self.imported_modules:
            return self.imported_modules[имя]
        else:
            print(f"❌ Модуль '{имя}' не найден")
            return None
    
    def список_модулей(self):
        """Показать список импортированных модулей"""
        print("\n📚 ИМПОРТИРОВАННЫЕ МОДУЛИ:")
        print("-" * 50)
        for name, module in self.imported_modules.items():
            version = getattr(module, '__version__', 'неизвестно')
            print(f"  📦 {name} (версия: {version})")
        
        if self.aliases:
            print("\n🏷️ ПСЕВДОНИМЫ:")
            print("-" * 50)
            for alias, module in self.aliases.items():
                module_name = module.__name__
                print(f"  {alias} -> {module_name}")
        print("-" * 50)
    
    def установить_библиотеку(self, имя_библиотеки: str):
        """Установить библиотеку через pip"""
        import subprocess
        try:
            print(f"📥 Установка библиотеки '{имя_библиотеки}'...")
            result = subprocess.run([sys.executable, '-m', 'pip', 'install', имя_библиотеки], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                print(f"✅ Библиотека '{имя_библиотеки}' успешно установлена")
                return True
            else:
                print(f"❌ Ошибка установки: {result.stderr}")
                return False
        except Exception as e:
            print(f"❌ Ошибка при установке '{имя_библиотеки}': {e}")
            return False

# Глобальный менеджер импорта
import_manager = WolfImportManager()

# Функции для использования в Wolf
def подключить(имя_библиотеки: str, псевдоним: str = None):
    """Подключить внешнюю библиотеку"""
    return import_manager.подключить(имя_библиотеки, псевдоним)

def получить_модуль(имя: str):
    """Получить импортированный модуль"""
    return import_manager.получить_модуль(имя)

def список_модулей():
    """Показать список импортированных модулей"""
    import_manager.список_модулей()

def установить_библиотеку(имя_библиотеки: str):
    """Установить библиотеку через pip"""
    return import_manager.установить_библиотеку(имя_библиотеки)

def популярные_библиотеки():
    """Показать список популярных библиотек для импорта"""
    libraries = {
        "Математика и наука": [
            ("numpy", "Работа с массивами и математические операции"),
            ("scipy", "Научные вычисления"),
            ("matplotlib", "Построение графиков"),
            ("pandas", "Анализ данных"),
            ("sympy", "Символьная математика")
        ],
        "Веб-разработка": [
            ("requests", "HTTP запросы"),
            ("flask", "Веб-фреймворк"),
            ("django", "Полнофункциональный веб-фреймворк"),
            ("beautifulsoup4", "Парсинг HTML"),
            ("selenium", "Автоматизация браузера")
        ],
        "GUI": [
            ("tkinter", "Встроенная библиотека GUI (уже доступна)"),
            ("pygame", "Игровая библиотека"),
            ("kivy", "Мобильные и десктопные приложения"),
            ("PyQt5", "Профессиональные GUI приложения")
        ],
        "Машинное обучение": [
            ("tensorflow", "Глубокое обучение"),
            ("torch", "PyTorch для глубокого обучения"),
            ("scikit-learn", "Машинное обучение"),
            ("opencv-python", "Компьютерное зрение")
        ],
        "Утилиты": [
            ("pillow", "Работа с изображениями"),
            ("openpyxl", "Работа с Excel файлами"),
            ("python-docx", "Работа с Word документами"),
            ("psutil", "Информация о системе")
        ]
    }
    
    print("\n🌟 ПОПУЛЯРНЫЕ БИБЛИОТЕКИ ДЛЯ ИМПОРТА:")
    print("=" * 60)
    
    for category, libs in libraries.items():
        print(f"\n📂 {category}:")
        print("-" * 40)
        for name, description in libs:
            print(f"  📦 {name:<20} - {description}")
    
    print("\n💡 ИСПОЛЬЗОВАНИЕ:")
    print("  библиотека = подключить('название_библиотеки')")
    print("  или")
    print("  библиотека = подключить('название_библиотеки', 'псевдоним')")
    print("=" * 60)

# Класс для создания Wolf-friendly обёрток
class WolfLibraryWrapper:
    """Обёртка для Python библиотек в стиле Wolf"""
    
    def __init__(self, module, name):
        self.module = module
        self.name = name
        self._create_wolf_methods()
    
    def _create_wolf_methods(self):
        """Создать Wolf-совместимые методы"""
        # Примеры адаптации популярных библиотек
        if self.name == 'numpy':
            self.массив = self.module.array
            self.среднее = self.module.mean
            self.сумма = self.module.sum
            self.минимум = self.module.min
            self.максимум = self.module.max
            self.форма = lambda arr: arr.shape
        
        elif self.name == 'matplotlib.pyplot':
            self.график = self.module.plot
            self.показать = self.module.show
            self.заголовок = self.module.title
            self.подпись_x = self.module.xlabel
            self.подпись_y = self.module.ylabel
        
        elif self.name == 'requests':
            self.получить = self.module.get
            self.отправить = self.module.post
            self.статус = lambda r: r.status_code
            self.текст = lambda r: r.text
    
    def __getattr__(self, name):
        """Перенаправить неизвестные атрибуты к исходному модулю"""
        return getattr(self.module, name)

def создать_обёртку(module, name):
    """Создать Wolf-friendly обёртку для библиотеки"""
    return WolfLibraryWrapper(module, name)

if __name__ == "__main__":
    # Демонстрация модуля импорта
    print("🐺 Wolf Import Module - Demo")
    print("=" * 50)
    
    # Показать популярные библиотеки
    популярные_библиотеки()
    
    # Демонстрация импорта встроенных модулей
    print("\n🧪 ТЕСТИРОВАНИЕ ИМПОРТА:")
    print("-" * 30)
    
    # Импорт встроенных модулей Python
    math_module = подключить('math', 'математика')
    if math_module:
        print(f"π = {math_module.pi}")
        print(f"sin(π/2) = {math_module.sin(math_module.pi/2)}")
    
    datetime_module = подключить('datetime', 'время')
    if datetime_module:
        now = datetime_module.datetime.now()
        print(f"Текущее время: {now}")
    
    random_module = подключить('random', 'случайно')
    if random_module:
        print(f"Случайное число: {random_module.randint(1, 100)}")
    
    # Показать импортированные модули
    список_модулей()
    
    print("\n✅ Демонстрация завершена")