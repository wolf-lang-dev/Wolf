"""
Wolf Programming Language v1.0 - Parser Module  
Парсер языка программирования Wolf
"""

from wolf_core import *

# Дополнительные узлы AST
class ImportStatement(Statement):
    """Узел для оператора использовать"""
    def __init__(self, module_name: str, alias: str = None):
        self.module_name = module_name
        self.alias = alias

class NeuralNetworkDef(Statement):
    """Узел для определения нейросети"""
    def __init__(self, name: str, layers: List['LayerDef']):
        self.name = name
        self.layers = layers

class LayerDef:
    """Определение слоя нейросети"""
    def __init__(self, layer_type: str, **params):
        self.layer_type = layer_type
        for key, value in params.items():
            setattr(self, key, value)

class SimpleWolfParser:
    """Простой парсер Wolf"""
    
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
        self.current_token = tokens[0] if tokens else None
    
    def error(self, message: str):
        line = self.current_token.line if self.current_token else "EOF"
        raise WolfSyntaxError(f"{message} на строке {line}")
    
    def advance(self):
        if self.pos < len(self.tokens) - 1:
            self.pos += 1
            self.current_token = self.tokens[self.pos]
        else:
            self.current_token = None
    
    def peek(self, offset: int = 1):
        peek_pos = self.pos + offset
        return self.tokens[peek_pos] if peek_pos < len(self.tokens) else None
    
    def match(self, *token_types):
        return self.current_token and self.current_token.type in token_types
    
    def skip_newlines(self):
        while self.match(TokenType.NEWLINE):
            self.advance()
    
    def parse(self) -> Program:
        """Главная функция парсинга"""
        statements = []
        
        while self.current_token and self.current_token.type != TokenType.EOF:
            self.skip_newlines()
            if not self.current_token or self.current_token.type == TokenType.EOF:
                break
                
            stmt = self.parse_statement()
            if stmt:
                statements.append(stmt)
        
        return Program(statements)
    
    def parse_statement(self) -> Statement:
        """Парсинг операторов"""
        self.skip_newlines()
        
        if not self.current_token:
            return None
        
        # Новые операторы
        if self.current_token.value == 'использовать':
            return self.parse_import()
        elif self.current_token.value == 'нейросеть':
            return self.parse_neural_network()
        
        # Стандартные операторы
        elif self.current_token.value == 'функция':
            return self.parse_function()
        elif self.current_token.value == 'класс':
            return self.parse_class()
        elif self.current_token.value == 'если':
            return self.parse_if()
        elif self.current_token.value == 'для':
            return self.parse_for()
        elif self.current_token.value == 'пока':
            return self.parse_while()
        elif self.current_token.value == 'вернуть':
            return self.parse_return()
        elif self.match(TokenType.IDENTIFIER):
            # Присваивание или выражение
            if self.peek() and self.peek().type in [TokenType.ASSIGN, TokenType.PLUS_ASSIGN]:
                return self.parse_assignment()
            else:
                expr = self.parse_expression()
                return ExpressionStatement(expr)
        else:
            expr = self.parse_expression()
            return ExpressionStatement(expr)
    
    def parse_import(self) -> ImportStatement:
        """Парсинг использовать модуль"""
        self.advance()  # пропускаем 'использовать'
        
        if not self.match(TokenType.IDENTIFIER):
            self.error("Ожидается имя модуля")
        
        module_name = self.current_token.value
        self.advance()
        
        alias = None
        if self.current_token and self.current_token.value == 'как':
            self.advance()
            if not self.match(TokenType.IDENTIFIER):
                self.error("Ожидается псевдоним")
            alias = self.current_token.value
            self.advance()
        
        return ImportStatement(module_name, alias)
    
    def parse_neural_network(self) -> NeuralNetworkDef:
        """Парсинг нейросеть Имя:"""
        self.advance()  # пропускаем 'нейросеть'
        
        if not self.match(TokenType.IDENTIFIER):
            self.error("Ожидается имя нейросети")
        
        name = self.current_token.value
        self.advance()
        
        if not self.match(TokenType.COLON):
            self.error("Ожидается ':'")
        self.advance()
        
        layers = []
        self.skip_newlines()
        
        # Простой парсинг слоев без отступов
        while self.current_token and self.current_token.value in ['линейный', 'релю', 'сигмоид', 'танх', 'софтмакс']:
            layer = self.parse_layer()
            if layer:
                layers.append(layer)
            self.skip_newlines()
        
        return NeuralNetworkDef(name, layers)
    
    def parse_layer(self) -> LayerDef:
        """Парсинг слоя нейросети"""
        layer_type = self.current_token.value
        self.advance()
        
        if layer_type == 'линейный':
            if self.match(TokenType.LPAREN):
                self.advance()
                params = {}
                
                # Парсим параметры вида вход=10, выход=5
                while not self.match(TokenType.RPAREN) and self.current_token:
                    if self.current_token.value == 'вход':
                        self.advance()
                        if self.match(TokenType.ASSIGN):
                            self.advance()
                            if self.match(TokenType.INTEGER):
                                params['input_size'] = int(self.current_token.value)
                                self.advance()
                    elif self.current_token.value == 'выход':
                        self.advance()
                        if self.match(TokenType.ASSIGN):
                            self.advance()
                            if self.match(TokenType.INTEGER):
                                params['output_size'] = int(self.current_token.value)
                                self.advance()
                    else:
                        self.advance()
                    
                    if self.match(TokenType.COMMA):
                        self.advance()
                
                if self.match(TokenType.RPAREN):
                    self.advance()
                
                return LayerDef(layer_type, **params)
            else:
                return LayerDef(layer_type)
        else:
            return LayerDef(layer_type)
    
    def parse_function(self) -> FunctionDef:
        """Простой парсинг функции"""
        self.advance()  # пропускаем 'функция'
        
        name = self.current_token.value
        self.advance()
        
        params = []
        if self.match(TokenType.LPAREN):
            self.advance()
            while not self.match(TokenType.RPAREN) and self.current_token:
                if self.match(TokenType.IDENTIFIER):
                    params.append(self.current_token.value)
                    self.advance()
                if self.match(TokenType.COMMA):
                    self.advance()
            if self.match(TokenType.RPAREN):
                self.advance()
        
        if self.match(TokenType.COLON):
            self.advance()
        
        # Простое тело функции - одно выражение
        body = []
        self.skip_newlines()
        if self.current_token:
            stmt = self.parse_statement()
            if stmt:
                body.append(stmt)
        
        return FunctionDef(name, params, body)
    
    def parse_class(self) -> ClassDef:
        """Простой парсинг класса"""
        self.advance()  # пропускаем 'класс'
        
        name = self.current_token.value
        self.advance()
        
        if self.match(TokenType.COLON):
            self.advance()
        
        methods = []
        attributes = {}
        
        # Упрощенный парсинг - одну функцию
        self.skip_newlines()
        if self.current_token and self.current_token.value == 'функция':
            method = self.parse_function()
            methods.append(method)
        
        return ClassDef(name, methods, attributes)
    
    def parse_assignment(self) -> Assignment:
        """Парсинг присваивания"""
        target = self.current_token.value
        self.advance()
        
        op = self.current_token.value
        self.advance()
        
        value = self.parse_expression()
        return Assignment(target, value, op)
    
    def parse_expression(self) -> Expression:
        """Простой парсинг выражений"""
        return self.parse_addition()
    
    def parse_addition(self) -> Expression:
        """Парсинг сложения"""
        expr = self.parse_multiplication()
        
        while self.current_token and self.current_token.type in [TokenType.PLUS, TokenType.MINUS]:
            op = self.current_token.value
            self.advance()
            right = self.parse_multiplication()
            expr = BinaryOp(expr, op, right)
        
        return expr
    
    def parse_multiplication(self) -> Expression:
        """Парсинг умножения"""
        expr = self.parse_primary()
        
        while self.current_token and self.current_token.type in [TokenType.MULTIPLY, TokenType.DIVIDE]:
            op = self.current_token.value
            self.advance()
            right = self.parse_primary()
            expr = BinaryOp(expr, op, right)
        
        return expr
    
    def parse_primary(self) -> Expression:
        """Парсинг первичных выражений"""
        if self.match(TokenType.INTEGER):
            value = int(self.current_token.value)
            self.advance()
            return Literal(value, WolfType.INT)
        
        elif self.match(TokenType.FLOAT):
            value = float(self.current_token.value)
            self.advance()
            return Literal(value, WolfType.FLOAT)
        
        elif self.match(TokenType.STRING):
            value = self.current_token.value
            self.advance()
            return Literal(value, WolfType.STRING)
        
        elif self.match(TokenType.TRUE):
            self.advance()
            return Literal(True, WolfType.BOOL)
        
        elif self.match(TokenType.FALSE):
            self.advance()
            return Literal(False, WolfType.BOOL)
        
        elif self.match(TokenType.IDENTIFIER):
            name = self.current_token.value
            self.advance()
            
            # Вызов функции
            if self.match(TokenType.LPAREN):
                self.advance()
                args = []
                
                while not self.match(TokenType.RPAREN) and self.current_token:
                    args.append(self.parse_expression())
                    if self.match(TokenType.COMMA):
                        self.advance()
                
                if self.match(TokenType.RPAREN):
                    self.advance()
                
                return FunctionCall(name, args)
            else:
                return Identifier(name)
        
        elif self.match(TokenType.PRINT, TokenType.INPUT, TokenType.LEN, TokenType.TYPE):
            # Встроенные функции
            name = self.current_token.value
            self.advance()
            
            if self.match(TokenType.LPAREN):
                self.advance()
                args = []
                
                while not self.match(TokenType.RPAREN) and self.current_token:
                    args.append(self.parse_expression())
                    if self.match(TokenType.COMMA):
                        self.advance()
                
                if self.match(TokenType.RPAREN):
                    self.advance()
                
                return FunctionCall(name, args)
            else:
                return Identifier(name)
        
        elif self.match(TokenType.LPAREN):
            self.advance()
            expr = self.parse_expression()
            if self.match(TokenType.RPAREN):
                self.advance()
            return expr
        
        elif self.match(TokenType.LBRACKET):
            return self.parse_list()
        
        else:
            if self.current_token:
                self.error(f"Неожиданный токен: {self.current_token.type}")
            else:
                return Literal(None, WolfType.NONE)
    
    def parse_list(self) -> ListLiteral:
        """Парсинг списка"""
        self.advance()  # пропускаем '['
        
        elements = []
        while not self.match(TokenType.RBRACKET) and self.current_token:
            elements.append(self.parse_expression())
            if self.match(TokenType.COMMA):
                self.advance()
        
        if self.match(TokenType.RBRACKET):
            self.advance()
        
        return ListLiteral(elements)
    
    def parse_if(self) -> IfStatement:
        """Простой парсинг if"""
        self.advance()  # пропускаем 'если'
        condition = self.parse_expression()
        
        if self.match(TokenType.COLON):
            self.advance()
        
        then_body = []
        self.skip_newlines()
        if self.current_token:
            stmt = self.parse_statement()
            if stmt:
                then_body.append(stmt)
        
        return IfStatement(condition, then_body, [])
    
    def parse_for(self) -> ForStatement:
        """Простой парсинг for"""
        self.advance()  # пропускаем 'для'
        
        var = self.current_token.value
        self.advance()
        
        if self.current_token and self.current_token.value == 'в':
            self.advance()
        
        iterable = self.parse_expression()
        
        if self.match(TokenType.COLON):
            self.advance()
        
        body = []
        self.skip_newlines()
        if self.current_token:
            stmt = self.parse_statement()
            if stmt:
                body.append(stmt)
        
        return ForStatement(var, iterable, body)
    
    def parse_while(self) -> WhileStatement:
        """Простой парсинг while"""
        self.advance()  # пропускаем 'пока'
        condition = self.parse_expression()
        
        if self.match(TokenType.COLON):
            self.advance()
        
        body = []
        self.skip_newlines()
        if self.current_token:
            stmt = self.parse_statement()
            if stmt:
                body.append(stmt)
        
        return WhileStatement(condition, body)
    
    def parse_return(self) -> ReturnStatement:
        """Парсинг return"""
        self.advance()  # пропускаем 'вернуть'
        
        value = None
        if self.current_token and not self.match(TokenType.NEWLINE):
            value = self.parse_expression()
        
        return ReturnStatement(value)

# Функция для быстрого парсинга
def parse_wolf_code(code: str) -> Program:
    """Парсинг Wolf кода"""
    lexer = Lexer(code)
    tokens = lexer.tokenize()
    
    parser = SimpleWolfParser(tokens)
    return parser.parse()

if __name__ == "__main__":
    print("🐺 Simple Wolf Parser готов к работе!")
    
    # Тестовый код
    test_code = '''
использовать математика
x = синус(3.14)
вывести(x)
'''
    
    try:
        ast = parse_wolf_code(test_code)
        print("✅ Парсинг выполнен успешно!")
        print(f"Найдено операторов: {len(ast.statements)}")
    except Exception as e:
        print(f"❌ Ошибка парсинга: {e}")