#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Wolf REPL (Read-Eval-Print Loop)
Интерактивная оболочка для Wolf Programming Language

Поддерживает:
- Интерактивное выполнение кода
- История команд
- Автодополнение
- Подсветка синтаксиса
- Многострочный ввод
- Встроенные команды
- Сохранение/загрузка сессий
"""

import sys
import os
import traceback
import readline
import rlcompleter
import json
from typing import Any, Dict, List, Optional, Callable
from datetime import datetime
import re

# Добавляем путь к модулям Wolf
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

class WolfREPLHistory:
    """Управление историей команд"""
    
    def __init__(self, history_file: str = None):
        if history_file is None:
            history_file = os.path.expanduser("~/.wolf_history")
        self.history_file = history_file
        self.commands = []
        self.load_history()
    
    def load_history(self):
        """Загружает историю команд"""
        try:
            if os.path.exists(self.history_file):
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    self.commands = [line.strip() for line in f.readlines()]
                    
                # Загружаем в readline
                for cmd in self.commands:
                    if cmd:
                        readline.add_history(cmd)
        except Exception as e:
            print(f"Ошибка загрузки истории: {e}")
    
    def save_history(self):
        """Сохраняет историю команд"""
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                for cmd in self.commands:
                    f.write(cmd + '\n')
        except Exception as e:
            print(f"Ошибка сохранения истории: {e}")
    
    def add_command(self, command: str):
        """Добавляет команду в историю"""
        if command and command not in self.commands:
            self.commands.append(command)
            readline.add_history(command)
    
    def get_history(self) -> List[str]:
        """Возвращает историю команд"""
        return self.commands.copy()

class WolfREPLCompleter:
    """Автодополнение для Wolf REPL"""
    
    def __init__(self, namespace: Dict[str, Any]):
        self.namespace = namespace
        self.keywords = [
            'вывести', 'ввести', 'если', 'иначе', 'для', 'в', 'пока',
            'функция', 'класс', 'метод', 'вернуть', 'импорт', 'из',
            'асинх', 'ожидать', 'попробовать', 'поймать', 'наконец',
            'сравнить', 'случай', 'иначе', 'λ', 'функция', 'модуль',
            'True', 'False', 'None', 'и', 'или', 'не'
        ]
        self.builtin_functions = [
            'создать_вектор', 'создать_словарь', 'создать_множество',
            'создать_очередь', 'создать_стек', 'создать_класс',
            'создать_экземпляр', 'импорт_python', 'вызвать_python',
            'применить', 'фильтровать', 'свернуть', 'сравнить',
            'любое', 'переменная', 'тип', 'значение'
        ]
    
    def complete(self, text: str, state: int) -> Optional[str]:
        """Функция автодополнения"""
        if state == 0:
            # Получаем все возможные варианты
            self.matches = []
            
            # Ключевые слова
            for keyword in self.keywords:
                if keyword.startswith(text):
                    self.matches.append(keyword)
            
            # Встроенные функции
            for func in self.builtin_functions:
                if func.startswith(text):
                    self.matches.append(func)
            
            # Переменные из namespace
            for name in self.namespace:
                if name.startswith(text):
                    self.matches.append(name)
        
        try:
            return self.matches[state]
        except IndexError:
            return None

class WolfREPLSession:
    """Сессия Wolf REPL"""
    
    def __init__(self):
        self.variables = {}
        self.functions = {}
        self.imports = {}
        self.created_at = datetime.now()
        self.command_count = 0
    
    def to_dict(self) -> Dict[str, Any]:
        """Преобразует сессию в словарь"""
        return {
            'variables': {k: str(v) for k, v in self.variables.items()},
            'functions': list(self.functions.keys()),
            'imports': list(self.imports.keys()),
            'created_at': self.created_at.isoformat(),
            'command_count': self.command_count
        }
    
    def save(self, filename: str):
        """Сохраняет сессию в файл"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(self.to_dict(), f, indent=2, ensure_ascii=False)
            print(f"✅ Сессия сохранена в {filename}")
        except Exception as e:
            print(f"❌ Ошибка сохранения сессии: {e}")

class WolfREPL:
    """Интерактивная оболочка Wolf"""
    
    def __init__(self):
        self.namespace = {}
        self.history = WolfREPLHistory()
        self.completer = WolfREPLCompleter(self.namespace)
        self.session = WolfREPLSession()
        self.running = True
        self.multiline_buffer = ""
        self.prompt = "🐺 >>> "
        self.continuation_prompt = "... "
        
        # Настройка readline
        readline.set_completer(self.completer.complete)
        readline.parse_and_bind("tab: complete")
        readline.set_completer_delims(" \t\n()[]{}:,")
        
        # Инициализация модулей Wolf
        self.init_wolf_modules()
    
    def init_wolf_modules(self):
        """Инициализирует модули Wolf"""
        try:
            # Базовые функции
            self.namespace['вывести'] = print
            self.namespace['ввести'] = input
            self.namespace['тип'] = type
            self.namespace['длина'] = len
            self.namespace['диапазон'] = range
            self.namespace['список'] = list
            self.namespace['словарь'] = dict
            self.namespace['множество'] = set
            
            # Импорт модулей Wolf
            try:
                from wolf_collections import *
                self.namespace.update({
                    'создать_вектор': создать_вектор,
                    'создать_словарь': создать_словарь,
                    'создать_множество': создать_множество,
                    'создать_очередь': создать_очередь,
                    'создать_стек': создать_стек
                })
                print("✅ Модуль коллекций загружен")
            except ImportError:
                print("⚠️ Модуль коллекций недоступен")
            
            try:
                from wolf_oop import *
                self.namespace.update({
                    'создать_класс': создать_класс,
                    'создать_экземпляр': создать_экземпляр,
                    'это_объект': это_объект
                })
                print("✅ Модуль ООП загружен")
            except ImportError:
                print("⚠️ Модуль ООП недоступен")
            
            try:
                from wolf_lambda import *
                self.namespace.update({
                    'функция': функция,
                    'λ': λ,
                    'применить': применить,
                    'фильтровать': фильтровать,
                    'свернуть': свернуть
                })
                print("✅ Модуль лямбда-функций загружен")
            except ImportError:
                print("⚠️ Модуль лямбда-функций недоступен")
            
            try:
                from wolf_pattern_matching import *
                self.namespace.update({
                    'сравнить': сравнить,
                    'любое': любое,
                    'переменная': переменная,
                    'тип': тип,
                    'значение': значение
                })
                print("✅ Модуль сопоставления загружен")
            except ImportError:
                print("⚠️ Модуль сопоставления недоступен")
            
            try:
                from wolf_ffi import *
                self.namespace.update({
                    'импорт_python': импорт_python,
                    'вызвать_python': вызвать_python,
                    'создать_python_объект': создать_python_объект
                })
                print("✅ Модуль FFI загружен")
            except ImportError:
                print("⚠️ Модуль FFI недоступен")
            
            try:
                from wolf_async import *
                self.namespace.update({
                    'асинх': асинх,
                    'ожидать': ожидать,
                    'создать_задачу': создать_задачу,
                    'запустить_асинх': запустить_асинх
                })
                print("✅ Модуль асинхронности загружен")
            except ImportError:
                print("⚠️ Модуль асинхронности недоступен")
            
        except Exception as e:
            print(f"❌ Ошибка инициализации модулей: {e}")
    
    def show_banner(self):
        """Показывает приветственное сообщение"""
        print("🐺 Wolf Programming Language - Интерактивная оболочка")
        print("=" * 60)
        print("Версия: Ultimate Edition")
        print("Python версия:", sys.version.split()[0])
        print("Введите 'помощь' для получения справки")
        print("Введите 'выход' для завершения работы")
        print("=" * 60)
    
    def show_help(self):
        """Показывает справку"""
        help_text = """
📖 СПРАВКА ПО WOLF REPL

🔧 ВСТРОЕННЫЕ КОМАНДЫ:
  помощь          - Показать эту справку
  выход           - Выйти из REPL
  очистить        - Очистить экран
  переменные      - Показать все переменные
  функции         - Показать все функции
  история         - Показать историю команд
  сохранить <имя> - Сохранить сессию
  загрузить <имя> - Загрузить сессию
  сброс           - Сбросить сессию

🐺 ПРИМЕРЫ КОДА:
  # Переменные
  >>> x = 42
  >>> имя = "Волк"
  >>> числа = [1, 2, 3, 4, 5]

  # Функции
  >>> функция удвоить(x): вернуть x * 2
  >>> удвоить(21)

  # Коллекции
  >>> вектор = создать_вектор(1, 2, 3)
  >>> словарь = создать_словарь(a=1, b=2)

  # Лямбда-функции
  >>> квадрат = λ(lambda x: x ** 2)
  >>> применить(квадрат, [1, 2, 3, 4])

  # Сопоставление
  >>> сравнить(5).случай(5, lambda: "пять").выполнить()

  # FFI
  >>> импорт_python('math')
  >>> вызвать_python('math', 'sin', 1.57)

⌨️ ГОРЯЧИЕ КЛАВИШИ:
  Tab             - Автодополнение
  Ctrl+C          - Прервать выполнение
  Ctrl+D          - Выход
  Стрелки ↑↓      - История команд
"""
        print(help_text)
    
    def show_variables(self):
        """Показывает все переменные"""
        if not self.namespace:
            print("📦 Переменные не определены")
            return
        
        print("📦 ПЕРЕМЕННЫЕ:")
        for name, value in self.namespace.items():
            if not name.startswith('__') and not callable(value):
                print(f"  {name} = {value} ({type(value).__name__})")
    
    def show_functions(self):
        """Показывает все функции"""
        functions = [name for name, value in self.namespace.items() 
                    if callable(value) and not name.startswith('__')]
        
        if not functions:
            print("🔧 Функции не определены")
            return
        
        print("🔧 ФУНКЦИИ:")
        for name in functions:
            print(f"  {name}")
    
    def show_history(self):
        """Показывает историю команд"""
        history = self.history.get_history()
        if not history:
            print("📜 История команд пуста")
            return
        
        print("📜 ИСТОРИЯ КОМАНД:")
        for i, cmd in enumerate(history[-10:], 1):  # Показываем последние 10
            print(f"  {i:2d}. {cmd}")
    
    def clear_screen(self):
        """Очищает экран"""
        os.system('cls' if os.name == 'nt' else 'clear')
    
    def reset_session(self):
        """Сбрасывает сессию"""
        self.namespace.clear()
        self.session = WolfREPLSession()
        self.init_wolf_modules()
        print("🔄 Сессия сброшена")
    
    def save_session(self, filename: str):
        """Сохраняет сессию"""
        if not filename.endswith('.json'):
            filename += '.json'
        self.session.save(filename)
    
    def handle_builtin_command(self, command: str) -> bool:
        """Обрабатывает встроенные команды"""
        cmd_parts = command.strip().split()
        if not cmd_parts:
            return False
        
        cmd = cmd_parts[0].lower()
        
        if cmd == 'помощь':
            self.show_help()
            return True
        elif cmd == 'выход':
            self.running = False
            return True
        elif cmd == 'очистить':
            self.clear_screen()
            return True
        elif cmd == 'переменные':
            self.show_variables()
            return True
        elif cmd == 'функции':
            self.show_functions()
            return True
        elif cmd == 'история':
            self.show_history()
            return True
        elif cmd == 'сброс':
            self.reset_session()
            return True
        elif cmd == 'сохранить':
            if len(cmd_parts) > 1:
                self.save_session(cmd_parts[1])
            else:
                print("❌ Укажите имя файла для сохранения")
            return True
        
        return False
    
    def is_multiline(self, code: str) -> bool:
        """Проверяет, требует ли код многострочного ввода"""
        # Простая проверка на незакрытые скобки
        open_brackets = code.count('(') - code.count(')')
        open_braces = code.count('{') - code.count('}')
        open_squares = code.count('[') - code.count(']')
        
        return (open_brackets > 0 or open_braces > 0 or open_squares > 0 or
                code.strip().endswith(':') or code.strip().endswith('\\'))
    
    def execute_code(self, code: str):
        """Выполняет код Wolf"""
        try:
            # Простая трансляция Wolf -> Python
            python_code = self.translate_wolf_to_python(code)
            
            # Выполняем код
            result = eval(python_code, {"__builtins__": __builtins__}, self.namespace)
            
            # Показываем результат, если он не None
            if result is not None:
                print(f"📤 {result}")
            
            self.session.command_count += 1
            
        except SyntaxError:
            try:
                # Пробуем выполнить как statement
                exec(python_code, {"__builtins__": __builtins__}, self.namespace)
                self.session.command_count += 1
            except Exception as e:
                print(f"❌ Ошибка: {e}")
                traceback.print_exc()
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            traceback.print_exc()
    
    def translate_wolf_to_python(self, code: str) -> str:
        """Простая трансляция Wolf в Python"""
        # Замены ключевых слов
        replacements = {
            'вывести': 'print',
            'ввести': 'input',
            'если': 'if',
            'иначе': 'else',
            'для': 'for',
            'в': 'in',
            'пока': 'while',
            'функция': 'def',
            'класс': 'class',
            'метод': 'def',
            'вернуть': 'return',
            'и': 'and',
            'или': 'or',
            'не': 'not',
            'истина': 'True',
            'ложь': 'False',
            'ничего': 'None'
        }
        
        # Применяем замены
        python_code = code
        for wolf_word, python_word in replacements.items():
            python_code = re.sub(r'\b' + wolf_word + r'\b', python_word, python_code)
        
        return python_code
    
    def run(self):
        """Запускает REPL"""
        self.show_banner()
        
        try:
            while self.running:
                try:
                    # Получаем ввод
                    if self.multiline_buffer:
                        prompt = self.continuation_prompt
                    else:
                        prompt = self.prompt
                    
                    line = input(prompt)
                    
                    # Добавляем к буферу
                    if self.multiline_buffer:
                        self.multiline_buffer += '\n' + line
                    else:
                        self.multiline_buffer = line
                    
                    # Проверяем встроенные команды
                    if not self.multiline_buffer.strip():
                        continue
                    
                    if self.handle_builtin_command(self.multiline_buffer):
                        self.multiline_buffer = ""
                        continue
                    
                    # Проверяем многострочный ввод
                    if self.is_multiline(self.multiline_buffer):
                        continue
                    
                    # Выполняем код
                    if self.multiline_buffer.strip():
                        self.history.add_command(self.multiline_buffer)
                        self.execute_code(self.multiline_buffer)
                    
                    # Очищаем буфер
                    self.multiline_buffer = ""
                    
                except EOFError:
                    print("\n👋 До свидания!")
                    break
                except KeyboardInterrupt:
                    print("\n⚠️ Прервано пользователем")
                    self.multiline_buffer = ""
                    continue
                except Exception as e:
                    print(f"❌ Неожиданная ошибка: {e}")
                    self.multiline_buffer = ""
                    continue
        
        finally:
            # Сохраняем историю
            self.history.save_history()
            print("📜 История команд сохранена")

# Функция для запуска REPL
def запустить_repl():
    """Запускает Wolf REPL"""
    repl = WolfREPL()
    repl.run()

if __name__ == "__main__":
    запустить_repl()