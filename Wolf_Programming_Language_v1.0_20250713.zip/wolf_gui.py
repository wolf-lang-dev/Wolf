#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Wolf Programming Language - GUI Module
Модуль для создания графических интерфейсов
"""

try:
    import tkinter as tk
    from tkinter import ttk, messagebox, filedialog, colorchooser
    TKINTER_AVAILABLE = True
except ImportError:
    TKINTER_AVAILABLE = False
    print("⚠️ Tkinter не доступен. GUI функции не будут работать.")

from typing import Callable, Any, Optional, List, Tuple

class WolfWindow:
    """Класс окна Wolf"""
    
    def __init__(self, название: str, размер: List[int]):
        if not TKINTER_AVAILABLE:
            raise ImportError("Tkinter не доступен")
        
        self.root = tk.Tk()
        self.root.title(название)
        self.root.geometry(f"{размер[0]}x{размер[1]}")
        self.widgets = []
        self.callbacks = {}
        
        # Настройка темы
        self.style = ttk.Style()
        self.setup_wolf_theme()
    
    def setup_wolf_theme(self):
        """Настроить тему Wolf"""
        try:
            # Попытка использовать современную тему
            available_themes = self.style.theme_names()
            if 'clam' in available_themes:
                self.style.theme_use('clam')
            elif 'alt' in available_themes:
                self.style.theme_use('alt')
            
            # Настройка цветов Wolf
            self.style.configure('Wolf.TButton', 
                               background='#4CAF50', 
                               foreground='white',
                               padding=10)
            self.style.configure('Wolf.TLabel',
                               background='#f0f0f0',
                               foreground='#333333',
                               font=('Arial', 10))
        except:
            pass  # Если настройка темы не удалась, используем стандартную
    
    def добавить_кнопку(self, текст: str, действие: Callable = None, **kwargs) -> Any:
        """Добавить кнопку"""
        button = ttk.Button(self.root, text=текст, style='Wolf.TButton')
        if действие:
            button.configure(command=lambda: self._safe_call(действие))
        
        # Упаковка
        padding = kwargs.get('отступ', 5)
        button.pack(pady=padding, padx=padding)
        
        self.widgets.append(button)
        return button
    
    def добавить_текст(self, текст: str, **kwargs) -> Any:
        """Добавить текстовую метку"""
        label = ttk.Label(self.root, text=текст, style='Wolf.TLabel')
        
        # Настройки
        if 'размер_шрифта' in kwargs:
            font = ('Arial', kwargs['размер_шрифта'])
            label.configure(font=font)
        
        if 'цвет' in kwargs:
            label.configure(foreground=kwargs['цвет'])
        
        # Упаковка
        padding = kwargs.get('отступ', 5)
        label.pack(pady=padding, padx=padding)
        
        self.widgets.append(label)
        return label
    
    def добавить_поле_ввода(self, **kwargs) -> Any:
        """Добавить поле ввода"""
        entry = ttk.Entry(self.root)
        
        # Настройки
        if 'ширина' in kwargs:
            entry.configure(width=kwargs['ширина'])
        
        if 'заполнитель' in kwargs:
            entry.insert(0, kwargs['заполнитель'])
        
        # Упаковка
        padding = kwargs.get('отступ', 5)
        entry.pack(pady=padding, padx=padding)
        
        self.widgets.append(entry)
        return entry
    
    def добавить_флажок(self, текст: str, **kwargs) -> Any:
        """Добавить флажок (checkbox)"""
        var = tk.BooleanVar()
        checkbox = ttk.Checkbutton(self.root, text=текст, variable=var)
        
        # Упаковка
        padding = kwargs.get('отступ', 5)
        checkbox.pack(pady=padding, padx=padding)
        
        self.widgets.append((checkbox, var))
        return checkbox, var
    
    def добавить_список(self, элементы: List[str], **kwargs) -> Any:
        """Добавить список выбора"""
        listbox = tk.Listbox(self.root)
        
        for элемент in элементы:
            listbox.insert(tk.END, элемент)
        
        # Настройки
        if 'высота' in kwargs:
            listbox.configure(height=kwargs['высота'])
        
        # Упаковка
        padding = kwargs.get('отступ', 5)
        listbox.pack(pady=padding, padx=padding)
        
        self.widgets.append(listbox)
        return listbox
    
    def добавить_меню(self) -> Any:
        """Добавить меню"""
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        return menubar
    
    def добавить_пункт_меню(self, меню: Any, название: str, действие: Callable = None) -> Any:
        """Добавить пункт меню"""
        if действие:
            меню.add_command(label=название, command=lambda: self._safe_call(действие))
        else:
            submenu = tk.Menu(меню, tearoff=0)
            меню.add_cascade(label=название, menu=submenu)
            return submenu
    
    def показать_сообщение(self, заголовок: str, текст: str, тип: str = "инфо"):
        """Показать диалоговое окно"""
        if тип == "инфо":
            messagebox.showinfo(заголовок, текст)
        elif тип == "предупреждение":
            messagebox.showwarning(заголовок, текст)
        elif тип == "ошибка":
            messagebox.showerror(заголовок, текст)
        elif тип == "вопрос":
            return messagebox.askyesno(заголовок, текст)
    
    def выбрать_файл(self, заголовок: str = "Выберите файл", типы: List[Tuple[str, str]] = None):
        """Диалог выбора файла"""
        if типы is None:
            типы = [("Все файлы", "*.*")]
        
        filename = filedialog.askopenfilename(
            title=заголовок,
            filetypes=типы
        )
        return filename
    
    def сохранить_файл(self, заголовок: str = "Сохранить файл", типы: List[Tuple[str, str]] = None):
        """Диалог сохранения файла"""
        if типы is None:
            типы = [("Все файлы", "*.*")]
        
        filename = filedialog.asksaveasfilename(
            title=заголовок,
            filetypes=типы
        )
        return filename
    
    def выбрать_цвет(self, заголовок: str = "Выберите цвет"):
        """Диалог выбора цвета"""
        color = colorchooser.askcolor(title=заголовок)
        return color[1] if color[1] else None  # Возвращаем hex значение
    
    def _safe_call(self, func: Callable):
        """Безопасный вызов функции с обработкой ошибок"""
        try:
            func()
        except Exception as e:
            print(f"❌ Ошибка в обработчике события: {e}")
            messagebox.showerror("Ошибка", f"Произошла ошибка: {e}")
    
    def запустить(self):
        """Запустить главный цикл окна"""
        try:
            self.root.mainloop()
        except KeyboardInterrupt:
            print("\n🔚 Окно закрыто пользователем")
        except Exception as e:
            print(f"❌ Ошибка в главном цикле: {e}")

class WolfGUI:
    """Основной класс для работы с GUI в Wolf"""
    
    @staticmethod
    def создать_окно(название: str, размер: List[int]) -> WolfWindow:
        """Создать новое окно"""
        if not TKINTER_AVAILABLE:
            print("❌ Tkinter не доступен. Установите Python с поддержкой Tkinter.")
            return None
        
        return WolfWindow(название, размер)
    
    @staticmethod
    def create_window(название: str, размер: List[int]) -> WolfWindow:
        """Создать новое окно (английский алиас)"""
        return WolfGUI.создать_окно(название, размер)
    
    @staticmethod
    def create_button(*args, **kwargs):
        """Создать кнопку"""
        print("⚠️ Функция create_button в разработке")
        return None
    
    @staticmethod
    def create_label(*args, **kwargs):
        """Создать текстовую метку"""
        print("⚠️ Функция create_label в разработке")
        return None
    
    @staticmethod
    def create_entry(*args, **kwargs):
        """Создать поле ввода"""
        print("⚠️ Функция create_entry в разработке")
        return None
    
    @staticmethod
    def show(*args, **kwargs):
        """Показать элемент"""
        print("⚠️ Функция show в разработке")
        return None
    
    @staticmethod
    def проверить_доступность():
        """Проверить доступность GUI"""
        return TKINTER_AVAILABLE

# Функции для использования в Wolf
def создать_окно(название: str, размер: List[int]) -> WolfWindow:
    """Создать окно"""
    return WolfGUI.создать_окно(название, размер)

def доступен_gui() -> bool:
    """Проверить доступность GUI"""
    return WolfGUI.проверить_доступность()

# Примеры использования
def пример_простое_окно():
    """Пример простого окна"""
    def нажатие():
        print("🔘 Кнопка нажата!")
    
    окно = создать_окно("Простое окно Wolf", [400, 300])
    if окно:
        окно.добавить_текст("Добро пожаловать в Wolf GUI!", размер_шрифта=14)
        окно.добавить_кнопку("Нажми меня!", нажатие)
        окно.запустить()

def пример_калькулятор():
    """Пример простого калькулятора"""
    def вычислить():
        try:
            число1 = float(поле1.get())
            число2 = float(поле2.get())
            результат = число1 + число2
            поле_результат.delete(0, tk.END)
            поле_результат.insert(0, str(результат))
        except ValueError:
            окно.показать_сообщение("Ошибка", "Введите корректные числа!", "ошибка")
    
    окно = создать_окно("Калькулятор Wolf", [300, 200])
    if окно:
        окно.добавить_текст("Простой калькулятор", размер_шрифта=16)
        
        поле1 = окно.добавить_поле_ввода(ширина=20)
        окно.добавить_текст("+")
        поле2 = окно.добавить_поле_ввода(ширина=20)
        окно.добавить_текст("=")
        поле_результат = окно.добавить_поле_ввода(ширина=20)
        
        окно.добавить_кнопку("Вычислить", вычислить)
        окно.запустить()

def пример_файловый_менеджер():
    """Пример работы с файлами"""
    def открыть_файл():
        файл = окно.выбрать_файл("Выберите файл", [("Текстовые файлы", "*.txt"), ("Все файлы", "*.*")])
        if файл:
            окно.показать_сообщение("Файл выбран", f"Выбран файл: {файл}")
    
    def сохранить():
        файл = окно.сохранить_файл("Сохранить как", [("Текстовые файлы", "*.txt")])
        if файл:
            окно.показать_сообщение("Файл сохранен", f"Файл сохранен: {файл}")
    
    def выбрать_цвет():
        цвет = окно.выбрать_цвет("Выберите цвет")
        if цвет:
            окно.показать_сообщение("Цвет выбран", f"Выбран цвет: {цвет}")
    
    окно = создать_окно("Файловый менеджер Wolf", [400, 300])
    if окно:
        окно.добавить_текст("Работа с файлами и диалогами", размер_шрифта=14)
        окно.добавить_кнопку("Открыть файл", открыть_файл)
        окно.добавить_кнопку("Сохранить файл", сохранить)
        окно.добавить_кнопку("Выбрать цвет", выбрать_цвет)
        окно.запустить()

if __name__ == "__main__":
    print("🐺 Wolf GUI Module - Demo")
    print("=" * 40)
    
    if доступен_gui():
        print("✅ GUI доступен")
        print("\nВыберите демонстрацию:")
        print("1. Простое окно")
        print("2. Калькулятор")
        print("3. Файловый менеджер")
        
        choice = input("\nВаш выбор (1-3): ").strip()
        
        if choice == "1":
            пример_простое_окно()
        elif choice == "2":
            пример_калькулятор()
        elif choice == "3":
            пример_файловый_менеджер()
        else:
            print("❌ Неверный выбор")
    else:
        print("❌ GUI недоступен")