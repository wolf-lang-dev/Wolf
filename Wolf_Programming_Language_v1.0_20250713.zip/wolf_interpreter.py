"""
Wolf Programming Language v1.0 - Interpreter Module
Интерпретатор языка программирования Wolf
"""

import sys
import os
import traceback
from typing import Dict, List, Any, Optional, Union

# Импорт всех модулей Wolf
from wolf_core import *
from wolf_parser import *

class WolfUnifiedInterpreter:
    def __init__(self):
        self.global_scope = {}
        self.current_scope = self.global_scope
        self.call_stack = []
        self.exception_stack = []
        self.modules = {}
        
        # Инициализация всех компонентов
        self.init_builtins()
        self.init_wolf_modules()
    
    def init_builtins(self):
        """Инициализация встроенных функций"""
        self.global_scope.update({
            'вывести': WolfBuiltins.wolf_print,
            'ввести': WolfBuiltins.wolf_input,
            'длина': WolfBuiltins.wolf_len,
            'тип': WolfBuiltins.wolf_type,
            'строка': WolfBuiltins.wolf_str,
            'число': WolfBuiltins.wolf_int,
            'дробь': WolfBuiltins.wolf_float,
            'открыть': WolfBuiltins.wolf_open,
            'да': True,
            'нет': False,
            'истина': True,
            'ложь': False,
            'None': None,
        })
    
    def init_wolf_modules(self):
        """Инициализация модулей Wolf"""
        # Математические функции
        self.init_math_module()
        
        # Нейросетевые функции
        self.init_neural_module()
        
        # Модуль импорта
        self.init_import_module()
        
        # Аппаратные функции
        self.init_hardware_module()
        
        # GUI функции
        self.init_gui_module()
        
        # Игровые функции
        self.init_game_module()
    
    def init_math_module(self):
        """Инициализация математического модуля"""
        try:
            from wolf_math import WolfMath, Tensor, WolfLinAlg
            
            # Добавляем математические функции в глобальную область
            self.global_scope.update({
                'синус': WolfMath.sin,
                'косинус': WolfMath.cos,
                'экспонента': WolfMath.exp,
                'логарифм': WolfMath.log,
                'корень': WolfMath.sqrt,
                'тензор': Tensor,
                'матрица': lambda *args: Tensor(args),
                'случайное': WolfLinAlg.randn,
                'нули': WolfLinAlg.zeros,
                'единицы': WolfLinAlg.ones,
                'пи': 3.14159265359,
                'е': 2.71828182846,
            })
            
            self.modules['математика'] = {
                'синус': WolfMath.sin,
                'косинус': WolfMath.cos,
                'экспонента': WolfMath.exp,
                'логарифм': WolfMath.log,
                'корень': WolfMath.sqrt,
                'тензор': Tensor,
                'матрица': lambda *args: Tensor(args),
            }
            
        except ImportError as e:
            print(f"⚠️ Модуль математики недоступен: {e}")
    
    def init_neural_module(self):
        """Инициализация модуля нейронных сетей"""
        try:
            from wolf_nn import NeuralNetwork, Linear, ReLU, Sigmoid, Tanh, Softmax
            
            self.global_scope.update({
                'НейроСеть': NeuralNetwork,
                'Линейный': Linear,
                'РеЛю': ReLU,
                'Сигмоид': Sigmoid,
                'Танх': Tanh,
                'СофтМакс': Softmax,
            })
            
            self.modules['нейросеть'] = {
                'НейроСеть': NeuralNetwork,
                'Линейный': Linear,
                'РеЛю': ReLU,
                'Сигмоид': Sigmoid,
                'Танх': Tanh,
                'СофтМакс': Softmax,
            }
            
        except ImportError as e:
            print(f"⚠️ Модуль нейросетей недоступен: {e}")
    
    def init_import_module(self):
        """Инициализация модуля импорта"""
        try:
            from wolf_import import подключить, получить_модуль, список_модулей
            
            self.global_scope.update({
                'подключить': подключить,
                'получить_модуль': получить_модуль,
                'список_модулей': список_модулей,
            })
            
        except ImportError as e:
            print(f"⚠️ Модуль импорта недоступен: {e}")
    
    def init_hardware_module(self):
        """Инициализация аппаратного модуля"""
        try:
            from wolf_hardware import WolfHardware
            
            self.modules['аппаратура'] = {
                'процессор_инфо': WolfHardware.процессор_инфо,
                'память_инфо': WolfHardware.память_инфо,
                'температура': WolfHardware.температура,
            }
            
        except ImportError as e:
            print(f"⚠️ Модуль аппаратуры недоступен: {e}")
            # Создаем заглушки
            self.modules['аппаратура'] = {
                'процессор_инфо': lambda: "Информация о процессоре недоступна",
                'память_инфо': lambda: "Информация о памяти недоступна",
                'диск_инфо': lambda: "Информация о диске недоступна",
                'температура': lambda: 0.0,
                'нагрузка': lambda: 0.0,
            }
    
    def init_gui_module(self):
        """Инициализация GUI модуля"""
        try:
            from wolf_gui import WolfGUI
            
            self.modules['gui'] = {
                'окно': WolfGUI.create_window,
                'кнопка': WolfGUI.create_button,
                'текст': WolfGUI.create_label,
                'поле_ввода': WolfGUI.create_entry,
                'показать': WolfGUI.show,
            }
            
        except ImportError as e:
            print(f"⚠️ Модуль GUI недоступен: {e}")
            # Создаем заглушки
            self.modules['gui'] = {
                'окно': lambda *args, **kwargs: print("GUI недоступен"),
                'кнопка': lambda *args, **kwargs: print("GUI недоступен"),
                'текст': lambda *args, **kwargs: print("GUI недоступен"),
                'поле_ввода': lambda *args, **kwargs: print("GUI недоступен"),
                'показать': lambda *args, **kwargs: print("GUI недоступен"),
            }
    
    def init_game_module(self):
        """Инициализация игрового модуля"""
        try:
            from wolf_game import WolfGame
            
            self.modules['игра'] = {
                'создать_игру': WolfGame.create_game,
                'спрайт': WolfGame.create_sprite,
                'звук': WolfGame.load_sound,
                'цвет': WolfGame.Color,
                'запустить': WolfGame.run,
            }
            
        except ImportError as e:
            print(f"⚠️ Модуль игр недоступен: {e}")
            # Создаем заглушки
            self.modules['игра'] = {
                'создать_игру': lambda *args, **kwargs: print("Игровой модуль недоступен"),
                'спрайт': lambda *args, **kwargs: print("Игровой модуль недоступен"),
                'звук': lambda *args, **kwargs: print("Игровой модуль недоступен"),
                'цвет': lambda *args, **kwargs: (255, 255, 255),
                'запустить': lambda *args, **kwargs: print("Игровой модуль недоступен"),
            }
    
    def visit_ImportStatement(self, node) -> Any:
        """Обработка оператора использовать"""
        module_name = node.module_name
        
        if module_name in self.modules:
            # Модуль Wolf
            module_dict = self.modules[module_name]
            
            if hasattr(node, 'alias') and node.alias:
                # использовать математика как мат
                self.current_scope[node.alias] = WolfModule(module_name, module_dict)
            else:
                # использовать математика
                self.current_scope.update(module_dict)
            
            print(f"✅ Модуль '{module_name}' успешно подключен")
        else:
            # Попытка импорта Python модуля
            try:
                if 'подключить' in self.global_scope:
                    python_module = self.global_scope['подключить'](module_name)
                    if python_module:
                        self.current_scope[module_name] = python_module
                        print(f"✅ Python модуль '{module_name}' успешно подключен")
                else:
                    raise WolfRuntimeError(f"Модуль '{module_name}' не найден")
            except Exception as e:
                raise WolfRuntimeError(f"Ошибка подключения модуля '{module_name}': {e}")
    
    def visit_NeuralNetworkDef(self, node) -> Any:
        """Обработка определения нейросети"""
        layers = []
        
        for layer_def in node.layers:
            if layer_def.layer_type == 'линейный':
                layer = self.global_scope['Линейный'](
                    layer_def.input_size,
                    layer_def.output_size
                )
            elif layer_def.layer_type == 'релю':
                layer = self.global_scope['РеЛю']()
            elif layer_def.layer_type == 'сигмоид':
                layer = self.global_scope['Сигмоид']()
            elif layer_def.layer_type == 'танх':
                layer = self.global_scope['Танх']()
            elif layer_def.layer_type == 'софтмакс':
                layer = self.global_scope['СофтМакс']()
            else:
                raise WolfRuntimeError(f"Неизвестный тип слоя: {layer_def.layer_type}")
            
            layers.append(layer)
        
        network = self.global_scope['НейроСеть'](layers)
        self.current_scope[node.name] = network
        return network
    
    def error(self, message: str):
        """Обработка ошибок"""
        raise WolfRuntimeError(f"Ошибка выполнения: {message}")
    
    def interpret(self, ast: Program) -> Any:
        """Главная функция интерпретации"""
        try:
            result = None
            for statement in ast.statements:
                result = self.visit(statement)
                if isinstance(result, ReturnValue):
                    return result.value
            return result
        except WolfException as e:
            print(f"Ошибка Wolf: {e}")
            return None
        except Exception as e:
            print(f"Системная ошибка: {e}")
            traceback.print_exc()
            return None
    
    def visit(self, node: ASTNode) -> Any:
        """Универсальный метод посещения узлов"""
        method_name = f'visit_{type(node).__name__}'
        method = getattr(self, method_name, self.generic_visit)
        return method(node)
    
    def generic_visit(self, node: ASTNode):
        """Обработка неизвестных узлов"""
        # Попробуем использовать базовый интерпретатор
        if hasattr(WolfInterpreter, f'visit_{type(node).__name__}'):
            base_interpreter = WolfInterpreter()
            base_interpreter.global_scope = self.global_scope
            base_interpreter.current_scope = self.current_scope
            return getattr(base_interpreter, f'visit_{type(node).__name__}')(node)
        else:
            self.error(f"Неизвестный узел AST: {type(node).__name__}")
    
    # Наследуем все методы из базового интерпретатора
    def visit_Program(self, node: Program) -> Any:
        """Посещение программы"""
        result = None
        for statement in node.statements:
            result = self.visit(statement)
            if isinstance(result, ReturnValue):
                return result
        return result
    
    def visit_FunctionDef(self, node: FunctionDef) -> Any:
        """Посещение определения функции"""
        func = WolfFunction(node.name, node.params, node.body, dict(self.current_scope))
        self.current_scope[node.name] = func
        return func
    
    def visit_ClassDef(self, node: ClassDef) -> Any:
        """Посещение определения класса"""
        methods = {}
        for method in node.methods:
            methods[method.name] = WolfFunction(method.name, method.params, method.body, dict(self.current_scope))
        
        attributes = {}
        for attr_name, attr_expr in node.attributes.items():
            attributes[attr_name] = self.visit(attr_expr)
        
        wolf_class = WolfClass(node.name, methods, attributes)
        self.current_scope[node.name] = wolf_class
        return wolf_class
    
    def visit_Assignment(self, node: Assignment) -> Any:
        """Посещение присваивания"""
        value = self.visit(node.value)
        
        if node.op == "=":
            self.current_scope[node.target] = value
        elif node.op == "+=":
            if node.target in self.current_scope:
                self.current_scope[node.target] += value
            else:
                self.current_scope[node.target] = value
        elif node.op == "-=":
            if node.target in self.current_scope:
                self.current_scope[node.target] -= value
            else:
                self.current_scope[node.target] = -value
        elif node.op == "*=":
            if node.target in self.current_scope:
                self.current_scope[node.target] *= value
            else:
                self.current_scope[node.target] = 0
        elif node.op == "/=":
            if node.target in self.current_scope:
                self.current_scope[node.target] /= value
            else:
                raise WolfRuntimeError("Деление на неопределенную переменную")
        
        return value
    
    def visit_BinaryOp(self, node: BinaryOp) -> Any:
        """Посещение бинарной операции"""
        left = self.visit(node.left)
        right = self.visit(node.right)
        
        if node.op == "+":
            return left + right
        elif node.op == "-":
            return left - right
        elif node.op == "*":
            return left * right
        elif node.op == "/":
            if right == 0:
                raise WolfRuntimeError("Деление на ноль")
            return left / right
        elif node.op == "**":
            return left ** right
        elif node.op == "%":
            return left % right
        elif node.op == "==":
            return left == right
        elif node.op == "!=":
            return left != right
        elif node.op == "<":
            return left < right
        elif node.op == ">":
            return left > right
        elif node.op == "<=":
            return left <= right
        elif node.op == ">=":
            return left >= right
        elif node.op == "и":
            return bool(left) and bool(right)
        elif node.op == "или":
            return bool(left) or bool(right)
        else:
            raise WolfRuntimeError(f"Неизвестная операция: {node.op}")
    
    def visit_UnaryOp(self, node: UnaryOp) -> Any:
        """Посещение унарной операции"""
        operand = self.visit(node.operand)
        
        if node.op == "+":
            return +operand
        elif node.op == "-":
            return -operand
        elif node.op == "не":
            return not bool(operand)
        else:
            raise WolfRuntimeError(f"Неизвестная унарная операция: {node.op}")
    
    def visit_Identifier(self, node: Identifier) -> Any:
        """Посещение идентификатора"""
        name = node.name
        
        if name in self.current_scope:
            return self.current_scope[name]
        elif name in self.global_scope:
            return self.global_scope[name]
        else:
            raise WolfRuntimeError(f"Переменная '{name}' не определена")
    
    def visit_Literal(self, node: Literal) -> Any:
        """Посещение литерала"""
        if node.type == WolfType.STRING:
            return WolfString(node.value)
        else:
            return node.value
    
    def visit_FunctionCall(self, node: FunctionCall) -> Any:
        """Посещение вызова функции"""
        func_name = node.name
        args = [self.visit(arg) for arg in node.args]
        
        if func_name in self.current_scope:
            func = self.current_scope[func_name]
        elif func_name in self.global_scope:
            func = self.global_scope[func_name]
        else:
            raise WolfRuntimeError(f"Функция '{func_name}' не определена")
        
        if isinstance(func, WolfFunction):
            return self.call_wolf_function(func, args)
        elif callable(func):
            return func(*args)
        elif isinstance(func, WolfClass):
            return func.create_instance(*args)
        else:
            raise WolfRuntimeError(f"'{func_name}' не является функцией")
    
    def call_wolf_function(self, func: WolfFunction, args: List[Any]) -> Any:
        """Вызов Wolf функции"""
        # Создаем новую область видимости
        old_scope = self.current_scope
        new_scope = dict(func.closure)
        
        # Привязываем аргументы к параметрам
        for i, param in enumerate(func.params):
            if i < len(args):
                new_scope[param] = args[i]
        
        self.current_scope = new_scope
        
        try:
            result = None
            for stmt in func.body:
                result = self.visit(stmt)
                if isinstance(result, ReturnValue):
                    return result.value
            return result
        finally:
            self.current_scope = old_scope
    
    def visit_ReturnStatement(self, node: ReturnStatement) -> Any:
        """Посещение оператора возврата"""
        value = None
        if node.value:
            value = self.visit(node.value)
        return ReturnValue(value)
    
    def visit_ExpressionStatement(self, node: ExpressionStatement) -> Any:
        """Посещение выражения-оператора"""
        return self.visit(node.expression)
    
    def visit_IfStatement(self, node: IfStatement) -> Any:
        """Посещение условного оператора"""
        condition_result = self.visit(node.condition)
        
        if bool(condition_result):
            for stmt in node.then_body:
                result = self.visit(stmt)
                if isinstance(result, ReturnValue):
                    return result
        elif node.else_body:
            for stmt in node.else_body:
                result = self.visit(stmt)
                if isinstance(result, ReturnValue):
                    return result
    
    def visit_ForStatement(self, node: ForStatement) -> Any:
        """Посещение цикла for"""
        iterable = self.visit(node.iterable)
        
        if isinstance(iterable, WolfList):
            python_iterable = iterable.data
        elif isinstance(iterable, WolfString):
            python_iterable = iterable.data
        elif isinstance(iterable, WolfDict):
            python_iterable = iterable.data.keys()
        elif hasattr(iterable, '__iter__'):
            python_iterable = iterable
        else:
            python_iterable = [iterable]
        
        for item in python_iterable:
            self.current_scope[node.var] = item
            for stmt in node.body:
                result = self.visit(stmt)
                if isinstance(result, ReturnValue):
                    return result
    
    def visit_WhileStatement(self, node: WhileStatement) -> Any:
        """Посещение цикла while"""
        while bool(self.visit(node.condition)):
            for stmt in node.body:
                result = self.visit(stmt)
                if isinstance(result, ReturnValue):
                    return result
    
    def visit_ListLiteral(self, node: ListLiteral) -> Any:
        """Посещение литерала списка"""
        elements = [self.visit(elem) for elem in node.elements]
        return WolfList(elements)
    
    def visit_DictLiteral(self, node: DictLiteral) -> Any:
        """Посещение литерала словаря"""
        data = {}
        for key_node, value_node in node.pairs:
            key = self.visit(key_node)
            value = self.visit(value_node)
            data[key] = value
        return WolfDict(data)

class WolfModule:
    """Класс для представления модуля Wolf"""
    
    def __init__(self, name: str, functions: Dict[str, Any]):
        self.name = name
        self.functions = functions
    
    def __getattr__(self, name: str):
        if name in self.functions:
            return self.functions[name]
        else:
            raise WolfAttributeError(f"Модуль '{self.name}' не содержит '{name}'")

# Главная функция для выполнения Wolf кода
def run_wolf_code(code: str):
    """Выполнение Wolf кода с унифицированным интерпретатором"""
    try:
        # Лексический анализ
        lexer = Lexer(code)
        tokens = lexer.tokenize()
        
        # Синтаксический анализ
        parser = SimpleWolfParser(tokens)
        ast = parser.parse()
        
        # Интерпретация
        interpreter = WolfUnifiedInterpreter()
        result = interpreter.interpret(ast)
        
        return result
        
    except WolfException as e:
        print(f"Ошибка Wolf: {e}")
        return None
    except Exception as e:
        print(f"Системная ошибка: {e}")
        traceback.print_exc()
        return None

if __name__ == "__main__":
    print("🐺 Wolf Unified Interpreter готов к работе!")
    
    # Тестовый код
    test_code = '''
# Тест математических функций
использовать математика

x = синус(пи / 2)
вывести("sin(π/2) =", x)

y = косинус(0)
вывести("cos(0) =", y)

# Тест аппаратуры
использовать аппаратура

инфо = процессор_инфо()
вывести("Процессор:", инфо)
'''
    
    print("Выполнение тестового кода:")
    run_wolf_code(test_code)