"""
Wolf Math Module - Встроенная математическая библиотека
Полностью самодостаточная, без внешних зависимостей
"""

import math
from typing import List, Union, Optional, Tuple
from dataclasses import dataclass

# ===== БАЗОВЫЕ МАТЕМАТИЧЕСКИЕ ФУНКЦИИ =====

class WolfMath:
    """Класс с математическими функциями Wolf"""
    
    @staticmethod
    def sin(x: float) -> float:
        """Синус через ряд Тейлора"""
        # sin(x) = x - x³/3! + x⁵/5! - x⁷/7! + ...
        x = x % (2 * 3.14159265359)  # Нормализация
        result = 0.0
        term = x
        n = 1
        
        for i in range(20):  # 20 итераций для точности
            result += term
            term *= -x * x / ((2 * n) * (2 * n + 1))
            n += 1
        
        return result
    
    @staticmethod
    def cos(x: float) -> float:
        """Косинус через ряд Тейлора"""
        # cos(x) = 1 - x²/2! + x⁴/4! - x⁶/6! + ...
        x = x % (2 * 3.14159265359)  # Нормализация
        result = 1.0
        term = 1.0
        n = 1
        
        for i in range(20):
            term *= -x * x / ((2 * n - 1) * (2 * n))
            result += term
            n += 1
        
        return result
    
    @staticmethod
    def exp(x: float) -> float:
        """Экспонента через ряд Тейлора"""
        # e^x = 1 + x + x²/2! + x³/3! + ...
        result = 1.0
        term = 1.0
        
        for i in range(1, 50):
            term *= x / i
            result += term
        
        return result
    
    @staticmethod
    def log(x: float) -> float:
        """Натуральный логарифм"""
        if x <= 0:
            raise ValueError("Логарифм неопределен для неположительных чисел")
        
        # Используем приближение для ln(x)
        # ln(x) ≈ 2 * ((x-1)/(x+1) + 1/3*((x-1)/(x+1))³ + ...)
        if x < 1:
            return -WolfMath.log(1/x)
        
        y = (x - 1) / (x + 1)
        result = 0.0
        term = y
        
        for i in range(1, 50, 2):
            result += term / i
            term *= y * y
        
        return 2 * result
    
    @staticmethod
    def sqrt(x: float) -> float:
        """Квадратный корень методом Ньютона"""
        if x < 0:
            raise ValueError("Квадратный корень из отрицательного числа")
        
        if x == 0:
            return 0
        
        # Метод Ньютона: x_n+1 = (x_n + a/x_n) / 2
        guess = x / 2
        
        for _ in range(20):
            better_guess = (guess + x / guess) / 2
            if abs(guess - better_guess) < 1e-10:
                break
            guess = better_guess
        
        return guess
    
    @staticmethod
    def pow(base: float, exponent: float) -> float:
        """Возведение в степень"""
        if exponent == 0:
            return 1
        elif exponent == 1:
            return base
        elif exponent < 0:
            return 1 / WolfMath.pow(base, -exponent)
        elif exponent == int(exponent):
            # Целая степень
            result = 1
            exp = int(exponent)
            while exp > 0:
                if exp % 2 == 1:
                    result *= base
                base *= base
                exp //= 2
            return result
        else:
            # Дробная степень: a^b = e^(b * ln(a))
            return WolfMath.exp(exponent * WolfMath.log(base))

# ===== ТЕНЗОРЫ =====

@dataclass
class Shape:
    """Форма тензора"""
    dims: Tuple[int, ...]
    
    def __post_init__(self):
        self.dims = tuple(self.dims)
    
    @property
    def ndim(self) -> int:
        return len(self.dims)
    
    @property
    def size(self) -> int:
        result = 1
        for dim in self.dims:
            result *= dim
        return result
    
    def __getitem__(self, idx: int) -> int:
        return self.dims[idx]
    
    def __len__(self) -> int:
        return len(self.dims)

class Tensor:
    """Тензор Wolf - многомерный массив"""
    
    def __init__(self, data: Union[List, float, int], shape: Optional[Tuple[int, ...]] = None):
        if isinstance(data, (int, float)):
            self.data = [float(data)]
            self.shape = Shape((1,))
        elif isinstance(data, list):
            self.data = self._flatten(data)
            if shape:
                self.shape = Shape(shape)
            else:
                self.shape = Shape(self._infer_shape(data))
        else:
            raise TypeError(f"Неподдерживаемый тип данных: {type(data)}")
        
        # Проверка соответствия размера данных и формы
        if len(self.data) != self.shape.size:
            raise ValueError(f"Размер данных ({len(self.data)}) не соответствует форме ({self.shape.size})")
    
    def _flatten(self, data: List) -> List[float]:
        """Преобразовать многомерный список в плоский"""
        result = []
        for item in data:
            if isinstance(item, list):
                result.extend(self._flatten(item))
            else:
                result.append(float(item))
        return result
    
    def _infer_shape(self, data: List) -> Tuple[int, ...]:
        """Определить форму из данных"""
        if not isinstance(data, list):
            return ()
        
        if not data:
            return (0,)
        
        shape = [len(data)]
        if isinstance(data[0], list):
            shape.extend(self._infer_shape(data[0]))
        
        return tuple(shape)
    
    def __getitem__(self, indices: Union[int, Tuple[int, ...]]) -> Union[float, 'Tensor']:
        """Получить элемент тензора"""
        if isinstance(indices, int):
            indices = (indices,)
        
        if len(indices) > self.shape.ndim:
            raise IndexError("Слишком много индексов")
        
        flat_index = self._multi_to_flat(indices)
        
        if len(indices) == self.shape.ndim:
            return self.data[flat_index]
        else:
            # Возвращаем срез
            remaining_dims = self.shape.dims[len(indices):]
            slice_size = 1
            for dim in remaining_dims:
                slice_size *= dim
            
            start_idx = flat_index * slice_size
            end_idx = start_idx + slice_size
            
            return Tensor(self.data[start_idx:end_idx], remaining_dims)
    
    def __setitem__(self, indices: Union[int, Tuple[int, ...]], value: Union[float, 'Tensor']):
        """Установить элемент тензора"""
        if isinstance(indices, int):
            indices = (indices,)
        
        flat_index = self._multi_to_flat(indices)
        
        if isinstance(value, Tensor):
            if len(indices) == self.shape.ndim:
                self.data[flat_index] = value.data[0]
            else:
                # Установить срез
                remaining_dims = self.shape.dims[len(indices):]
                slice_size = 1
                for dim in remaining_dims:
                    slice_size *= dim
                
                start_idx = flat_index * slice_size
                end_idx = start_idx + slice_size
                
                if len(value.data) != slice_size:
                    raise ValueError("Размер значения не соответствует срезу")
                
                self.data[start_idx:end_idx] = value.data
        else:
            self.data[flat_index] = float(value)
    
    def _multi_to_flat(self, indices: Tuple[int, ...]) -> int:
        """Преобразовать многомерный индекс в плоский"""
        flat_index = 0
        stride = 1
        
        for i in range(len(indices) - 1, -1, -1):
            if indices[i] >= self.shape.dims[i]:
                raise IndexError(f"Индекс {indices[i]} выходит за границы размерности {self.shape.dims[i]}")
            flat_index += indices[i] * stride
            stride *= self.shape.dims[i]
        
        return flat_index
    
    def __add__(self, other: Union['Tensor', float, int]) -> 'Tensor':
        """Сложение тензоров"""
        if isinstance(other, (int, float)):
            return Tensor([x + float(other) for x in self.data], self.shape.dims)
        elif isinstance(other, Tensor):
            if self.shape.dims != other.shape.dims:
                raise ValueError("Тензоры должны иметь одинаковую форму для сложения")
            return Tensor([x + y for x, y in zip(self.data, other.data)], self.shape.dims)
        else:
            raise TypeError(f"Неподдерживаемый тип для сложения: {type(other)}")
    
    def __sub__(self, other: Union['Tensor', float, int]) -> 'Tensor':
        """Вычитание тензоров"""
        if isinstance(other, (int, float)):
            return Tensor([x - float(other) for x in self.data], self.shape.dims)
        elif isinstance(other, Tensor):
            if self.shape.dims != other.shape.dims:
                raise ValueError("Тензоры должны иметь одинаковую форму для вычитания")
            return Tensor([x - y for x, y in zip(self.data, other.data)], self.shape.dims)
        else:
            raise TypeError(f"Неподдерживаемый тип для вычитания: {type(other)}")
    
    def __mul__(self, other: Union['Tensor', float, int]) -> 'Tensor':
        """Умножение тензоров (поэлементное)"""
        if isinstance(other, (int, float)):
            return Tensor([x * float(other) for x in self.data], self.shape.dims)
        elif isinstance(other, Tensor):
            if self.shape.dims != other.shape.dims:
                raise ValueError("Тензоры должны иметь одинаковую форму для умножения")
            return Tensor([x * y for x, y in zip(self.data, other.data)], self.shape.dims)
        else:
            raise TypeError(f"Неподдерживаемый тип для умножения: {type(other)}")
    
    def __truediv__(self, other: Union['Tensor', float, int]) -> 'Tensor':
        """Деление тензоров"""
        if isinstance(other, (int, float)):
            if other == 0:
                raise ZeroDivisionError("Деление на ноль")
            return Tensor([x / float(other) for x in self.data], self.shape.dims)
        elif isinstance(other, Tensor):
            if self.shape.dims != other.shape.dims:
                raise ValueError("Тензоры должны иметь одинаковую форму для деления")
            return Tensor([x / y for x, y in zip(self.data, other.data)], self.shape.dims)
        else:
            raise TypeError(f"Неподдерживаемый тип для деления: {type(other)}")
    
    def dot(self, other: 'Tensor') -> 'Tensor':
        """Матричное произведение"""
        if self.shape.ndim != 2 or other.shape.ndim != 2:
            raise ValueError("Матричное произведение поддерживается только для 2D тензоров")
        
        if self.shape.dims[1] != other.shape.dims[0]:
            raise ValueError("Размерности матриц не совпадают для умножения")
        
        rows = self.shape.dims[0]
        cols = other.shape.dims[1]
        inner = self.shape.dims[1]
        
        result = []
        for i in range(rows):
            for j in range(cols):
                value = 0.0
                for k in range(inner):
                    value += self[i, k] * other[k, j]
                result.append(value)
        
        return Tensor(result, (rows, cols))
    
    def transpose(self) -> 'Tensor':
        """Транспонирование матрицы"""
        if self.shape.ndim != 2:
            raise ValueError("Транспонирование поддерживается только для 2D тензоров")
        
        rows, cols = self.shape.dims
        result = []
        
        for j in range(cols):
            for i in range(rows):
                result.append(self[i, j])
        
        return Tensor(result, (cols, rows))
    
    def sum(self, axis: Optional[int] = None) -> Union['Tensor', float]:
        """Сумма элементов"""
        if axis is None:
            return sum(self.data)
        else:
            raise NotImplementedError("Сумма по оси пока не реализована")
    
    def mean(self, axis: Optional[int] = None) -> Union['Tensor', float]:
        """Среднее значение"""
        if axis is None:
            return sum(self.data) / len(self.data)
        else:
            raise NotImplementedError("Среднее по оси пока не реализовано")
    
    def max(self) -> float:
        """Максимальное значение"""
        return max(self.data)
    
    def min(self) -> float:
        """Минимальное значение"""
        return min(self.data)
    
    def reshape(self, new_shape: Tuple[int, ...]) -> 'Tensor':
        """Изменить форму тензора"""
        new_shape_obj = Shape(new_shape)
        if new_shape_obj.size != self.shape.size:
            raise ValueError("Новая форма должна иметь тот же размер")
        
        return Tensor(self.data.copy(), new_shape)
    
    def copy(self) -> 'Tensor':
        """Создать копию тензора"""
        return Tensor(self.data.copy(), self.shape.dims)
    
    def __str__(self) -> str:
        return f"Tensor(shape={self.shape.dims}, data={self.data[:10]}{'...' if len(self.data) > 10 else ''})"
    
    def __repr__(self) -> str:
        return self.__str__()

# ===== ЛИНЕЙНАЯ АЛГЕБРА =====

class WolfLinAlg:
    """Операции линейной алгебры"""
    
    @staticmethod
    def zeros(shape: Tuple[int, ...]) -> Tensor:
        """Создать тензор из нулей"""
        size = 1
        for dim in shape:
            size *= dim
        return Tensor([0.0] * size, shape)
    
    @staticmethod
    def ones(shape: Tuple[int, ...]) -> Tensor:
        """Создать тензор из единиц"""
        size = 1
        for dim in shape:
            size *= dim
        return Tensor([1.0] * size, shape)
    
    @staticmethod
    def eye(n: int) -> Tensor:
        """Создать единичную матрицу"""
        data = []
        for i in range(n):
            for j in range(n):
                data.append(1.0 if i == j else 0.0)
        return Tensor(data, (n, n))
    
    @staticmethod
    def random(shape: Tuple[int, ...], seed: int = 42) -> Tensor:
        """Создать тензор со случайными значениями"""
        # Простой линейный конгруэнтный генератор
        def lcg(prev_seed):
            return (prev_seed * 1103515245 + 12345) % (2**31)
        
        size = 1
        for dim in shape:
            size *= dim
        
        data = []
        current_seed = seed
        for _ in range(size):
            current_seed = lcg(current_seed)
            # Нормализация к [0, 1)
            data.append(current_seed / (2**31))
        
        return Tensor(data, shape)
    
    @staticmethod
    def randn(shape: Tuple[int, ...], seed: int = 42) -> Tensor:
        """Создать тензор с нормально распределенными случайными значениями"""
        # Используем метод Бокса-Мюллера
        def box_muller(u1, u2):
            z1 = WolfMath.sqrt(-2 * WolfMath.log(u1)) * WolfMath.cos(2 * 3.14159265359 * u2)
            z2 = WolfMath.sqrt(-2 * WolfMath.log(u1)) * WolfMath.sin(2 * 3.14159265359 * u2)
            return z1, z2
        
        uniform = WolfLinAlg.random(shape, seed)
        size = len(uniform.data)
        
        data = []
        for i in range(0, size, 2):
            u1 = uniform.data[i]
            u2 = uniform.data[i + 1] if i + 1 < size else uniform.data[0]
            
            # Избегаем log(0)
            u1 = max(u1, 1e-10)
            u2 = max(u2, 1e-10)
            
            z1, z2 = box_muller(u1, u2)
            data.append(z1)
            if len(data) < size:
                data.append(z2)
        
        return Tensor(data[:size], shape)

# ===== АВТОМАТИЧЕСКОЕ ДИФФЕРЕНЦИРОВАНИЕ =====

class Variable:
    """Переменная с автоматическим дифференцированием"""
    
    def __init__(self, tensor: Tensor, requires_grad: bool = True):
        self.tensor = tensor
        self.requires_grad = requires_grad
        self.grad = None
        self.grad_fn = None
        self.is_leaf = True
    
    def backward(self, grad: Optional[Tensor] = None):
        """Обратное распространение градиента"""
        if not self.requires_grad:
            return
        
        if grad is None:
            if self.tensor.shape.size != 1:
                raise RuntimeError("Градиент должен быть указан для не скалярных тензоров")
            grad = Tensor([1.0], self.tensor.shape.dims)
        
        if self.grad is None:
            self.grad = grad
        else:
            self.grad = self.grad + grad
        
        if self.grad_fn is not None:
            self.grad_fn(grad)
    
    def __add__(self, other: Union['Variable', float, int]) -> 'Variable':
        """Сложение с градиентом"""
        if isinstance(other, (int, float)):
            result_tensor = self.tensor + other
            result = Variable(result_tensor, self.requires_grad)
            
            if self.requires_grad:
                result.is_leaf = False
                def grad_fn(grad):
                    self.backward(grad)
                result.grad_fn = grad_fn
            
            return result
        elif isinstance(other, Variable):
            result_tensor = self.tensor + other.tensor
            result = Variable(result_tensor, self.requires_grad or other.requires_grad)
            
            if self.requires_grad or other.requires_grad:
                result.is_leaf = False
                def grad_fn(grad):
                    if self.requires_grad:
                        self.backward(grad)
                    if other.requires_grad:
                        other.backward(grad)
                result.grad_fn = grad_fn
            
            return result
        else:
            raise TypeError(f"Неподдерживаемый тип: {type(other)}")
    
    def __mul__(self, other: Union['Variable', float, int]) -> 'Variable':
        """Умножение с градиентом"""
        if isinstance(other, (int, float)):
            result_tensor = self.tensor * other
            result = Variable(result_tensor, self.requires_grad)
            
            if self.requires_grad:
                result.is_leaf = False
                def grad_fn(grad):
                    self.backward(grad * other)
                result.grad_fn = grad_fn
            
            return result
        elif isinstance(other, Variable):
            result_tensor = self.tensor * other.tensor
            result = Variable(result_tensor, self.requires_grad or other.requires_grad)
            
            if self.requires_grad or other.requires_grad:
                result.is_leaf = False
                def grad_fn(grad):
                    if self.requires_grad:
                        self.backward(grad * other.tensor)
                    if other.requires_grad:
                        other.backward(grad * self.tensor)
                result.grad_fn = grad_fn
            
            return result
        else:
            raise TypeError(f"Неподдерживаемый тип: {type(other)}")
    
    def __str__(self) -> str:
        return f"Variable({self.tensor}, requires_grad={self.requires_grad})"

# ===== ФУНКЦИИ АКТИВАЦИИ =====

class Activation:
    """Функции активации"""
    
    @staticmethod
    def relu(x: Tensor) -> Tensor:
        """ReLU активация"""
        return Tensor([max(0, val) for val in x.data], x.shape.dims)
    
    @staticmethod
    def sigmoid(x: Tensor) -> Tensor:
        """Сигмоида"""
        return Tensor([1 / (1 + WolfMath.exp(-val)) for val in x.data], x.shape.dims)
    
    @staticmethod
    def tanh(x: Tensor) -> Tensor:
        """Гиперболический тангенс"""
        return Tensor([(WolfMath.exp(val) - WolfMath.exp(-val)) / (WolfMath.exp(val) + WolfMath.exp(-val)) 
                      for val in x.data], x.shape.dims)
    
    @staticmethod
    def softmax(x: Tensor) -> Tensor:
        """Softmax активация"""
        if x.shape.ndim != 1:
            raise ValueError("Softmax поддерживается только для 1D тензоров")
        
        # Для численной стабильности вычитаем максимум
        max_val = x.max()
        exp_vals = [WolfMath.exp(val - max_val) for val in x.data]
        sum_exp = sum(exp_vals)
        
        return Tensor([val / sum_exp for val in exp_vals], x.shape.dims)

# ===== ФУНКЦИИ ПОТЕРЬ =====

class Loss:
    """Функции потерь"""
    
    @staticmethod
    def mse(y_true: Tensor, y_pred: Tensor) -> float:
        """Среднеквадратичная ошибка"""
        if y_true.shape.dims != y_pred.shape.dims:
            raise ValueError("Тензоры должны иметь одинаковую форму")
        
        diff = y_true - y_pred
        squared_diff = diff * diff
        return squared_diff.mean()
    
    @staticmethod
    def cross_entropy(y_true: Tensor, y_pred: Tensor) -> float:
        """Кросс-энтропия"""
        if y_true.shape.dims != y_pred.shape.dims:
            raise ValueError("Тензоры должны иметь одинаковую форму")
        
        # Избегаем log(0)
        epsilon = 1e-15
        y_pred_clipped = Tensor([max(min(val, 1 - epsilon), epsilon) for val in y_pred.data], y_pred.shape.dims)
        
        log_pred = Tensor([WolfMath.log(val) for val in y_pred_clipped.data], y_pred_clipped.shape.dims)
        return -(y_true * log_pred).mean()

# ===== ГЛАВНАЯ ФУНКЦИЯ ТЕСТИРОВАНИЯ =====

if __name__ == "__main__":
    # Тестирование математических функций
    print("=== Тестирование математических функций ===")
    print(f"sin(π/2) = {WolfMath.sin(3.14159265359/2)}")
    print(f"cos(0) = {WolfMath.cos(0)}")
    print(f"exp(1) = {WolfMath.exp(1)}")
    print(f"log(e) = {WolfMath.log(2.71828)}")
    print(f"sqrt(16) = {WolfMath.sqrt(16)}")
    print(f"pow(2, 8) = {WolfMath.pow(2, 8)}")
    
    # Тестирование тензоров
    print("\n=== Тестирование тензоров ===")
    t1 = Tensor([[1, 2], [3, 4]])
    t2 = Tensor([[5, 6], [7, 8]])
    print(f"t1 = {t1}")
    print(f"t2 = {t2}")
    print(f"t1 + t2 = {t1 + t2}")
    print(f"t1 * t2 = {t1 * t2}")
    print(f"t1.dot(t2) = {t1.dot(t2)}")
    print(f"t1.transpose() = {t1.transpose()}")
    
    # Тестирование линейной алгебры
    print("\n=== Тестирование линейной алгебры ===")
    zeros = WolfLinAlg.zeros((2, 3))
    ones = WolfLinAlg.ones((2, 3))
    eye = WolfLinAlg.eye(3)
    random = WolfLinAlg.random((2, 2), seed=42)
    randn = WolfLinAlg.randn((2, 2), seed=42)
    
    print(f"zeros(2, 3) = {zeros}")
    print(f"ones(2, 3) = {ones}")
    print(f"eye(3) = {eye}")
    print(f"random(2, 2) = {random}")
    print(f"randn(2, 2) = {randn}")
    
    # Тестирование активаций
    print("\n=== Тестирование активаций ===")
    x = Tensor([-2, -1, 0, 1, 2])
    print(f"x = {x}")
    print(f"relu(x) = {Activation.relu(x)}")
    print(f"sigmoid(x) = {Activation.sigmoid(x)}")
    print(f"tanh(x) = {Activation.tanh(x)}")
    print(f"softmax(x) = {Activation.softmax(x)}")
    
    # Тестирование функций потерь
    print("\n=== Тестирование функций потерь ===")
    y_true = Tensor([1, 0, 1])
    y_pred = Tensor([0.9, 0.1, 0.8])
    print(f"y_true = {y_true}")
    print(f"y_pred = {y_pred}")
    print(f"mse = {Loss.mse(y_true, y_pred)}")
    print(f"cross_entropy = {Loss.cross_entropy(y_true, y_pred)}")