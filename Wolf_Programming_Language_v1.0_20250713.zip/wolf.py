#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Wolf Programming Language v1.0 - Main Entry Point
Главная точка входа для Wolf Programming Language
"""

import sys
import os
import argparse
import traceback
from pathlib import Path

# Добавляем текущую директорию в путь
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Импорт всех модулей Wolf
try:
    from wolf_interpreter import WolfUnifiedInterpreter, run_wolf_code
    from wolf_parser import SimpleWolfParser, parse_wolf_code
    from wolf_core import Lexer, WolfException
    print("✅ Wolf v1.0 загружен!")
except ImportError as e:
    print(f"❌ Ошибка импорта: {e}")
    print("Убедитесь, что все файлы Wolf находятся в той же директории")
    sys.exit(1)

class WolfREPL:
    """Интерактивная оболочка Wolf с расширенными возможностями"""
    
    def __init__(self):
        self.interpreter = WolfUnifiedInterpreter()
        self.history = []
        self.multiline_buffer = []
        self.in_multiline = False
    
    def run(self):
        """Запуск REPL"""
        self.show_banner()
        
        while True:
            try:
                if self.in_multiline:
                    prompt = "... "
                else:
                    prompt = "Wolf> "
                
                line = input(prompt)
                
                # Обработка команд
                if line.strip() == "выход":
                    break
                elif line.strip() == "помощь":
                    self.show_help()
                    continue
                elif line.strip() == "модули":
                    self.show_modules()
                    continue
                elif line.strip() == "история":
                    self.show_history()
                    continue
                elif line.strip() == "очистить":
                    self.clear_screen()
                    continue
                elif line.strip() == "примеры":
                    self.show_examples()
                    continue
                elif line.strip() == "":
                    if self.in_multiline:
                        # Завершаем многострочный ввод
                        code = "\n".join(self.multiline_buffer)
                        self.multiline_buffer = []
                        self.in_multiline = False
                        self.execute_code(code)
                    continue
                
                # Обработка многострочного ввода
                if line.strip().endswith(":") or self.in_multiline:
                    self.multiline_buffer.append(line)
                    self.in_multiline = True
                    continue
                
                # Выполнение одной строки
                self.history.append(line)
                self.execute_code(line)
                    
            except KeyboardInterrupt:
                print("\n👋 До свидания!")
                break
            except EOFError:
                print("\n👋 До свидания!")
                break
            except Exception as e:
                print(f"❌ Неожиданная ошибка: {e}")
                traceback.print_exc()
    
    def execute_code(self, code: str):
        """Выполнение кода Wolf"""
        try:
            result = run_wolf_code(code)
            if result is not None and result != "":
                print(f"=> {result}")
        except Exception as e:
            print(f"❌ Ошибка выполнения: {e}")
    
    def show_banner(self):
        """Показать баннер при запуске"""
        banner = """
🐺 ================================================
   WOLF PROGRAMMING LANGUAGE v1.0
🐺 ================================================

🚀 Возможности:
   • Русскоязычный синтаксис
   • Встроенные нейронные сети
   • Математические вычисления  
   • Аппаратная диагностика
   • Модульная архитектура

💡 Команды:
   помощь   - справка
   модули   - доступные модули
   примеры  - примеры кода
   история  - история команд
   очистить - очистить экран
   выход    - завершить работу

📚 Для многострочного ввода завершите строку двоеточием (:)
   и нажмите Enter дважды для выполнения

🐺 Введите код Wolf или команду:
"""
        print(banner)
    
    def show_help(self):
        """Показать справку"""
        help_text = """
🐺 СПРАВКА WOLF PROGRAMMING LANGUAGE v1.0

📚 ДОСТУПНЫЕ МОДУЛИ:
  использовать математика    # sin, cos, log, sqrt, pi, e
  использовать аппаратура    # процессор_инфо, память_инфо, температура
  использовать нейросеть     # НейроСеть, Линейный, РеЛю, Сигмоид
  использовать gui           # окно, кнопка, текст (если доступно)
  использовать игра          # создать_игру, спрайт (если доступно)

🔧 ОСНОВНОЙ СИНТАКСИС:
  # Переменные
  x = 10
  текст = "Привет"
  список = [1, 2, 3]
  
  # Функции
  функция имя(параметры):
      код
      вернуть результат
  
  # Классы
  класс ИмяКласса:
      функция __init__(self, параметры):
          self.атрибут = значение
  
  # Условия
  если условие:
      код
  иначе:
      код
  
  # Циклы
  для переменная в список:
      код
  
  пока условие:
      код

🧠 НЕЙРОННЫЕ СЕТИ:
  нейросеть МояСеть:
      линейный(вход=10, выход=5)
      релю
      линейный(вход=5, выход=1)
      сигмоид

📊 МАТЕМАТИКА:
  использовать математика
  
  результат = синус(пи / 2)
  корень_16 = корень(16)
  логарифм_е = логарифм(е)

🖥️ АППАРАТУРА:
  использовать аппаратура
  
  процессор = процессор_инфо()
  температура_cpu = температура()

💡 ПРИМЕРЫ:
  примеры - показать готовые примеры кода

📖 Полная документация в README.md
"""
        print(help_text)
    
    def show_modules(self):
        """Показать доступные модули"""
        print("\n🐺 ДОСТУПНЫЕ МОДУЛИ WOLF v1.0:")
        print("=" * 50)
        
        modules_info = [
            ("математика", "Математические функции", "синус, косинус, логарифм, корень"),
            ("аппаратура", "Системная диагностика", "процессор_инфо, память_инфо, температура"),
            ("нейросеть", "Нейронные сети", "НейроСеть, Линейный, РеЛю, Сигмоид"),
            ("gui", "Графический интерфейс", "окно, кнопка, текст"),
            ("игра", "Игровая разработка", "создать_игру, спрайт, звук"),
        ]
        
        for module, description, functions in modules_info:
            print(f"📦 {module:<12} - {description}")
            print(f"   Функции: {functions}")
            print()
        
        print("💡 Использование: использовать имя_модуля")
        print("💡 С псевдонимом: использовать модуль как псевдоним")
    
    def show_examples(self):
        """Показать примеры кода"""
        examples = [
            ("Основы", '''
# Переменные и арифметика
x = 15
y = 25
сумма = x + y
вывести("Сумма:", сумма)
'''),
            ("Функции", '''
функция факториал(n: int) -> int:
    если n <= 1:
        вернуть 1
    иначе:
        вернуть n * факториал(n - 1)

результат = факториал(5)
вывести("5! =", результат)
'''),
            ("Классы", '''
класс Калькулятор:
    функция __init__(self):
        self.результат = 0
    
    функция сложить(self, число):
        self.результат += число
        вернуть self.результат

калк = Калькулятор()
калк.сложить(10)
калк.сложить(5)
вывести("Результат:", калк.результат)
'''),
            ("Математика", '''
использовать математика

угол = пи / 6
sin_значение = синус(угол)
cos_значение = косинус(угол)

вывести("sin(π/6) =", sin_значение)
вывести("cos(π/6) =", cos_значение)
'''),
            ("Нейросети", '''
использовать нейросеть

нейросеть МояСеть:
    линейный(вход=3, выход=4)
    релю
    линейный(вход=4, выход=1)
    сигмоид

вывести("Нейросеть создана!")
'''),
        ]
        
        print("\n🐺 ПРИМЕРЫ КОДА WOLF:")
        print("=" * 40)
        
        for i, (title, code) in enumerate(examples, 1):
            print(f"\n{i}. {title}:")
            print("-" * 20)
            print(code.strip())
        
        print("\n💡 Скопируйте и вставьте любой пример в REPL для выполнения")
    
    def show_history(self):
        """Показать историю команд"""
        if not self.history:
            print("\n📜 История команд пуста")
            return
        
        print("\n📜 ИСТОРИЯ КОМАНД:")
        print("-" * 30)
        for i, cmd in enumerate(self.history[-10:], 1):  # Последние 10 команд
            print(f"{i:2d}. {cmd}")
    
    def clear_screen(self):
        """Очистить экран"""
        os.system('cls' if os.name == 'nt' else 'clear')
        self.show_banner()

def run_file(filename: str):
    """Запуск Wolf файла"""
    if not os.path.exists(filename):
        print(f"❌ Файл {filename} не найден")
        return False
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            code = f.read()
        
        print(f"🐺 Выполнение файла: {filename}")
        print("=" * 60)
        
        result = run_wolf_code(code)
        
        print("=" * 60)
        print("✅ Выполнение завершено")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка при выполнении файла: {e}")
        traceback.print_exc()
        return False

def run_tests():
    """Запуск встроенных тестов"""
    print("🧪 Запуск тестов Wolf v6.2...")
    print("=" * 40)
    
    test_files = [
        "test_unified.wolf",
        "examples/01_basics.wolf",
        "examples/02_functions_classes.wolf",
        "examples/03_modules.wolf",
        "examples/04_neural_networks.wolf",
    ]
    
    passed = 0
    total = 0
    
    for test_file in test_files:
        if os.path.exists(test_file):
            total += 1
            print(f"\n🧪 Тест: {test_file}")
            if run_file(test_file):
                passed += 1
                print(f"✅ {test_file} - ПРОЙДЕН")
            else:
                print(f"❌ {test_file} - ПРОВАЛЕН")
        else:
            print(f"⚠️ Тест {test_file} не найден")
    
    print(f"\n📊 Результаты тестов: {passed}/{total} пройдено")
    
    if passed == total and total > 0:
        print("🎉 Все тесты пройдены успешно!")
    elif total == 0:
        print("⚠️ Тестовые файлы не найдены")
    else:
        print("❌ Некоторые тесты провалены")

def main():
    """Главная функция"""
    parser = argparse.ArgumentParser(
        description="Wolf Programming Language v1.0",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры использования:
  wolf                     # Запуск REPL
  wolf script.wolf         # Выполнение файла
  wolf -i                  # Интерактивный режим
  wolf --test              # Запуск тестов
  wolf --version           # Показать версию
  wolf --modules           # Показать модули
"""
    )
    
    parser.add_argument('file', nargs='?', help='Wolf файл для выполнения')
    parser.add_argument('-i', '--interactive', action='store_true', 
                       help='Интерактивный режим (REPL)')
    parser.add_argument('--version', action='store_true', 
                       help='Показать версию')
    parser.add_argument('--test', action='store_true',
                       help='Запуск встроенных тестов')
    parser.add_argument('--modules', action='store_true',
                       help='Показать доступные модули')
    parser.add_argument('--build', action='store_true',
                       help='Запуск системы сборки')
    
    args = parser.parse_args()
    
    if args.version:
        print("🐺 Wolf Programming Language")
        print("Версия: 1.0")
        print("Возможности: Классы, Функции, Нейросети, Модули, Аппаратура")
        print("Архитектура: Единая интегрированная система")
        return
    
    if args.modules:
        repl = WolfREPL()
        repl.show_modules()
        return
    
    if args.test:
        run_tests()
        return
    
    if args.build:
        try:
            from wolf_unified_build import WolfBuilder
            builder = WolfBuilder()
            builder.build()
        except ImportError:
            print("❌ Модуль сборки недоступен")
        return
    
    if args.file:
        success = run_file(args.file)
        sys.exit(0 if success else 1)
    elif args.interactive or not args.file:
        repl = WolfREPL()
        repl.run()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n👋 Программа прервана пользователем")
    except Exception as e:
        print(f"❌ Критическая ошибка: {e}")
        traceback.print_exc()
        sys.exit(1)