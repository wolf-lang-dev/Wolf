"""
Wolf Programming Language v1.0 - GUI Installer
Графический установщик Wolf с поддержкой иконок
"""

import os
import sys
import shutil
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
import subprocess
import winreg
from typing import Optional

class WolfInstaller:
    """GUI Установщик Wolf Programming Language"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Wolf Programming Language v1.0 - Установщик")
        self.root.geometry("600x500")
        self.root.resizable(False, False)
        
        # Пытаемся загрузить иконку
        try:
            icon_path = Path(__file__).parent / "Wolf Installer.ico"
            if icon_path.exists():
                self.root.iconbitmap(str(icon_path))
        except:
            pass  # Игнорируем ошибки иконки
        
        self.install_path = Path(os.path.expanduser("~/Wolf"))
        self.progress_var = tk.DoubleVar()
        self.status_var = tk.StringVar(value="Готов к установке")
        
        self.setup_ui()
    
    def setup_ui(self):
        """Настройка интерфейса"""
        # Заголовок
        title_frame = ttk.Frame(self.root)
        title_frame.pack(fill="x", padx=20, pady=20)
        
        ttk.Label(
            title_frame, 
            text="🐺 Wolf Programming Language v1.0",
            font=("Arial", 16, "bold")
        ).pack()
        
        ttk.Label(
            title_frame,
            text="Установщик языка программирования Wolf",
            font=("Arial", 10)
        ).pack()
        
        # Информация о Wolf
        info_frame = ttk.LabelFrame(self.root, text="Информация о Wolf v1.0")
        info_frame.pack(fill="x", padx=20, pady=10)
        
        info_text = """
• Русскоязычный синтаксис программирования
• Поддержка математических вычислений  
• Встроенные нейронные сети
• Аппаратная диагностика системы
• Графический интерфейс и игры
• Интерактивная оболочка (REPL)
"""
        ttk.Label(info_frame, text=info_text, justify="left").pack(padx=10, pady=10)
        
        # Путь установки
        path_frame = ttk.LabelFrame(self.root, text="Путь установки")
        path_frame.pack(fill="x", padx=20, pady=10)
        
        path_entry_frame = ttk.Frame(path_frame)
        path_entry_frame.pack(fill="x", padx=10, pady=10)
        
        self.path_var = tk.StringVar(value=str(self.install_path))
        ttk.Entry(path_entry_frame, textvariable=self.path_var, width=50).pack(side="left", fill="x", expand=True)
        ttk.Button(path_entry_frame, text="Обзор...", command=self.browse_path).pack(side="right", padx=(10, 0))
        
        # Опции установки
        options_frame = ttk.LabelFrame(self.root, text="Опции установки")
        options_frame.pack(fill="x", padx=20, pady=10)
        
        self.create_shortcuts = tk.BooleanVar(value=True)
        self.add_to_path = tk.BooleanVar(value=True)
        self.create_file_association = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(
            options_frame, 
            text="Создать ярлыки на рабочем столе",
            variable=self.create_shortcuts
        ).pack(anchor="w", padx=10, pady=2)
        
        ttk.Checkbutton(
            options_frame,
            text="Добавить Wolf в PATH системы", 
            variable=self.add_to_path
        ).pack(anchor="w", padx=10, pady=2)
        
        ttk.Checkbutton(
            options_frame,
            text="Ассоциировать файлы .wolf с Wolf",
            variable=self.create_file_association
        ).pack(anchor="w", padx=10, pady=2)
        
        # Прогресс
        progress_frame = ttk.Frame(self.root)
        progress_frame.pack(fill="x", padx=20, pady=10)
        
        ttk.Label(progress_frame, textvariable=self.status_var).pack(anchor="w")
        self.progress_bar = ttk.Progressbar(
            progress_frame, 
            variable=self.progress_var,
            maximum=100
        )
        self.progress_bar.pack(fill="x", pady=(5, 0))
        
        # Кнопки
        button_frame = ttk.Frame(self.root)
        button_frame.pack(fill="x", padx=20, pady=20)
        
        ttk.Button(
            button_frame,
            text="Установить Wolf v1.0",
            command=self.install_wolf
        ).pack(side="right", padx=(10, 0))
        
        ttk.Button(
            button_frame,
            text="Отмена",
            command=self.root.quit
        ).pack(side="right")
        
        ttk.Button(
            button_frame,
            text="Деинсталлятор",
            command=self.open_uninstaller
        ).pack(side="left")
    
    def browse_path(self):
        """Выбор пути установки"""
        path = filedialog.askdirectory(initialdir=str(self.install_path.parent))
        if path:
            self.install_path = Path(path) / "Wolf"
            self.path_var.set(str(self.install_path))
    
    def update_progress(self, value: float, status: str):
        """Обновление прогресса"""
        self.progress_var.set(value)
        self.status_var.set(status)
        self.root.update()
    
    def install_wolf(self):
        """Установка Wolf"""
        try:
            self.update_progress(0, "Начало установки...")
            
            # Создание директории
            self.install_path.mkdir(parents=True, exist_ok=True)
            self.update_progress(10, "Создана директория установки")
            
            # Копирование файлов
            self.copy_wolf_files()
            self.update_progress(50, "Файлы Wolf скопированы")
            
            # Создание ярлыков
            if self.create_shortcuts.get():
                self.create_desktop_shortcuts()
                self.update_progress(70, "Созданы ярлыки")
            
            # Добавление в PATH
            if self.add_to_path.get():
                self.add_to_system_path()
                self.update_progress(80, "Добавлено в PATH")
            
            # Ассоциация файлов
            if self.create_file_association.get():
                self.create_file_associations()
                self.update_progress(90, "Созданы ассоциации файлов")
            
            # Создание деинсталлятора
            self.create_uninstaller()
            self.update_progress(100, "Установка завершена!")
            
            messagebox.showinfo(
                "Установка завершена",
                "Wolf Programming Language v1.0 успешно установлен!\n\n"
                "Вы можете запустить Wolf из командной строки: wolf\n"
                "Или использовать ярлыки на рабочем столе."
            )
            
        except Exception as e:
            messagebox.showerror("Ошибка установки", f"Произошла ошибка: {e}")
            self.update_progress(0, "Ошибка установки")
    
    def copy_wolf_files(self):
        """Копирование файлов Wolf"""
        source_dir = Path(__file__).parent
        
        # Основные модули Wolf
        wolf_files = [
            "wolf_core.py",
            "wolf_parser.py", 
            "wolf_interpreter.py",
            "wolf_main.py",
            "wolf_math.py",
            "wolf_nn.py",
            "wolf_hardware.py",
            "wolf_import.py",
            "wolf_gui.py",
            "wolf_game.py"
        ]
        
        for file_name in wolf_files:
            src = source_dir / file_name
            if src.exists():
                dst = self.install_path / file_name
                shutil.copy2(src, dst)
        
        # Создание главного запускателя
        self.create_main_launcher()
    
    def create_main_launcher(self):
        """Создание главного запускателя wolf.py"""
        launcher_content = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Wolf Programming Language v1.0 - Launcher
Запускатель Wolf Programming Language
"""

import sys
import os
from pathlib import Path

# Добавляем директорию Wolf в путь
wolf_dir = Path(__file__).parent
sys.path.insert(0, str(wolf_dir))

try:
    from wolf_main import main
    main()
except ImportError as e:
    print(f"❌ Ошибка запуска Wolf: {e}")
    print("Убедитесь, что все модули Wolf установлены")
    sys.exit(1)
'''
        
        launcher_path = self.install_path / "wolf.py"
        with open(launcher_path, 'w', encoding='utf-8') as f:
            f.write(launcher_content)
        
        # Создание batch файла для Windows
        batch_content = f'''@echo off
chcp 65001 > nul
cd /d "{self.install_path}"
python wolf.py %*
'''
        
        batch_path = self.install_path / "wolf.bat"
        with open(batch_path, 'w', encoding='utf-8') as f:
            f.write(batch_content)
    
    def create_desktop_shortcuts(self):
        """Создание ярлыков на рабочем столе"""
        try:
            import win32com.client
            
            desktop = Path.home() / "Desktop"
            
            # Ярлык для Wolf REPL
            shell = win32com.client.Dispatch("WScript.Shell")
            shortcut = shell.CreateShortCut(str(desktop / "Wolf REPL.lnk"))
            shortcut.Targetpath = str(self.install_path / "wolf.bat")
            shortcut.Arguments = "-i"
            shortcut.WorkingDirectory = str(self.install_path)
            shortcut.Description = "Wolf Programming Language REPL"
            shortcut.save()
            
        except ImportError:
            # Fallback без win32com
            pass
    
    def add_to_system_path(self):
        """Добавление Wolf в PATH системы"""
        try:
            # Открываем реестр для изменения PATH
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                "Environment",
                0,
                winreg.KEY_SET_VALUE | winreg.KEY_READ
            ) as key:
                try:
                    current_path, _ = winreg.QueryValueEx(key, "PATH")
                except FileNotFoundError:
                    current_path = ""
                
                if str(self.install_path) not in current_path:
                    new_path = f"{current_path};{self.install_path}" if current_path else str(self.install_path)
                    winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ, new_path)
                    
        except Exception:
            pass  # Игнорируем ошибки PATH
    
    def create_file_associations(self):
        """Создание ассоциаций файлов .wolf"""
        try:
            # Регистрируем тип файла .wolf
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\.wolf") as key:
                winreg.SetValue(key, "", winreg.REG_SZ, "WolfScript")
            
            # Регистрируем команду открытия
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\WolfScript\shell\open\command") as key:
                command = f'"{self.install_path / "wolf.bat"}" "%1"'
                winreg.SetValue(key, "", winreg.REG_SZ, command)
                
        except Exception:
            pass  # Игнорируем ошибки ассоциации
    
    def create_uninstaller(self):
        """Создание деинсталлятора"""
        uninstaller_content = '''"""
Wolf Programming Language v1.0 - Uninstaller
Деинсталлятор Wolf Programming Language
"""

import os
import sys
import shutil
import tkinter as tk
from tkinter import messagebox
from pathlib import Path
import winreg

def remove_from_path():
    """Удаление из PATH"""
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            "Environment", 
            0,
            winreg.KEY_SET_VALUE | winreg.KEY_READ
        ) as key:
            current_path, _ = winreg.QueryValueEx(key, "PATH")
            install_path = str(Path(__file__).parent)
            new_path = current_path.replace(f";{install_path}", "").replace(install_path, "")
            winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ, new_path)
    except:
        pass

def remove_file_associations():
    """Удаление ассоциаций файлов"""
    try:
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\.wolf")
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\WolfScript\\shell\\open\\command")
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\WolfScript\\shell\\open")
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\WolfScript\\shell")
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\WolfScript")
    except:
        pass

def main():
    """Главная функция деинсталлятора"""
    root = tk.Tk()
    root.withdraw()  # Скрываем главное окно
    
    # Пытаемся загрузить иконку деинсталлятора
    try:
        icon_path = Path(__file__).parent / "Wolf Uninstaller.ico"
        if icon_path.exists():
            root.iconbitmap(str(icon_path))
    except:
        pass
    
    result = messagebox.askyesno(
        "Wolf Uninstaller v1.0",
        "Вы действительно хотите удалить Wolf Programming Language v1.0?\\n\\n"
        "Это действие нельзя отменить!"
    )
    
    if result:
        try:
            install_dir = Path(__file__).parent
            
            # Удаляем из PATH
            remove_from_path()
            
            # Удаляем ассоциации файлов
            remove_file_associations()
            
            # Удаляем ярлыки
            desktop = Path.home() / "Desktop"
            shortcut_path = desktop / "Wolf REPL.lnk"
            if shortcut_path.exists():
                shortcut_path.unlink()
            
            messagebox.showinfo(
                "Деинсталляция завершена",
                "Wolf Programming Language v1.0 успешно удален!\\n\\n"
                "Директория установки будет удалена после закрытия этого окна."
            )
            
            # Создаем batch файл для удаления директории после закрытия
            batch_content = f'''@echo off
timeout /t 2 /nobreak > nul
rmdir /s /q "{install_dir}"
del "%~f0"
'''
            
            batch_path = install_dir.parent / "remove_wolf.bat"
            with open(batch_path, 'w') as f:
                f.write(batch_content)
            
            os.system(f'start "" "{batch_path}"')
            
        except Exception as e:
            messagebox.showerror("Ошибка", f"Ошибка деинсталляции: {e}")
    
    root.destroy()

if __name__ == "__main__":
    main()
'''
        
        uninstaller_path = self.install_path / "wolf_uninstaller.py"
        with open(uninstaller_path, 'w', encoding='utf-8') as f:
            f.write(uninstaller_content)
        
        # Создание bat файла для деинсталлятора
        uninstaller_bat = f'''@echo off
cd /d "{self.install_path}"
python wolf_uninstaller.py
'''
        
        bat_path = self.install_path / "Uninstall Wolf.bat"
        with open(bat_path, 'w', encoding='utf-8') as f:
            f.write(uninstaller_bat)
    
    def open_uninstaller(self):
        """Открытие деинсталлятора"""
        messagebox.showinfo(
            "Деинсталлятор", 
            "Деинсталлятор будет создан после установки Wolf.\n"
            "Вы найдете его в директории установки."
        )
    
    def run(self):
        """Запуск установщика"""
        self.root.mainloop()

if __name__ == "__main__":
    print("🐺 Wolf Programming Language v1.0 - Installer")
    installer = WolfInstaller()
    installer.run()