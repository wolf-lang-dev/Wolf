"""
Wolf Programming Language v1.0 - Console Installer
Консольный установщик Wolf Programming Language
"""

import os
import sys
import shutil
import zipfile
from pathlib import Path

class WolfFinalBuilder:
    """Финальный сборщик Wolf Programming Language"""
    
    def __init__(self):
        self.project_dir = Path(__file__).parent
        self.build_dir = self.project_dir / "wolf_final_build"
        self.dist_dir = self.project_dir / "wolf_distribution"
        
        # Все модули Wolf в правильном порядке
        self.core_modules = [
            "wolf_core_advanced.py",
            "wolf_simple_parser.py", 
            "wolf_unified_interpreter.py",
            "wolf_main_unified.py",
        ]
        
        # Математические модули
        self.math_modules = [
            "wolf_math.py",
            "wolf_nn.py",
        ]
        
        # Системные модули
        self.system_modules = [
            "wolf_import.py",
            "wolf_hardware.py",
        ]
        
        # GUI и игровые модули
        self.gui_game_modules = [
            "wolf_gui.py",
            "wolf_game.py",
        ]
        
        # Тестовые файлы
        self.test_files = [
            "test_simple.wolf",
            "test_unified.wolf",
        ]
    
    def clean_build(self):
        """Очистка директорий сборки"""
        print("🧹 Очистка директорий сборки...")
        
        for directory in [self.build_dir, self.dist_dir]:
            if directory.exists():
                shutil.rmtree(directory)
            directory.mkdir(exist_ok=True)
        
        print("✅ Директории очищены")
    
    def copy_modules(self):
        """Копирование всех модулей"""
        print("📦 Копирование модулей Wolf...")
        
        all_modules = (
            self.core_modules + 
            self.math_modules + 
            self.system_modules + 
            self.gui_game_modules
        )
        
        copied_count = 0
        missing_count = 0
        
        for module in all_modules:
            src = self.project_dir / module
            dst = self.build_dir / module
            
            if src.exists():
                shutil.copy2(src, dst)
                print(f"  ✅ {module}")
                copied_count += 1
            else:
                print(f"  ⚠️ {module} - отсутствует")
                missing_count += 1
        
        print(f"📊 Скопировано: {copied_count}, Отсутствует: {missing_count}")
        return copied_count, missing_count
    
    def copy_test_files(self):
        """Копирование тестовых файлов"""
        print("🧪 Копирование тестовых файлов...")
        
        for test_file in self.test_files:
            src = self.project_dir / test_file
            dst = self.build_dir / test_file
            
            if src.exists():
                shutil.copy2(src, dst)
                print(f"  📋 {test_file}")
    
    def create_launcher(self):
        """Создание универсального запускателя"""
        print("🚀 Создание запускателя...")
        
        launcher_content = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Wolf Programming Language v1.0 - Universal Launcher
Универсальный запускатель Wolf
"""

import sys
import os
from pathlib import Path

# Добавляем текущую директорию в путь
wolf_dir = Path(__file__).parent
sys.path.insert(0, str(wolf_dir))

def main():
    """Главная функция запуска"""
    try:
        # Проверяем наличие основных модулей
        required_modules = [
            "wolf_core_advanced.py",
            "wolf_simple_parser.py", 
            "wolf_unified_interpreter.py",
            "wolf_main_unified.py"
        ]
        
        missing_modules = []
        for module in required_modules:
            if not (wolf_dir / module).exists():
                missing_modules.append(module)
        
        if missing_modules:
            print("❌ Отсутствуют обязательные модули:")
            for module in missing_modules:
                print(f"   - {module}")
            print("\\nПожалуйста, убедитесь, что все файлы Wolf находятся в той же директории.")
            return 1
        
        # Импортируем главный модуль
        from wolf_main_unified import main as wolf_main
        
        # Запускаем Wolf
        wolf_main()
        return 0
        
    except ImportError as e:
        print(f"❌ Ошибка импорта: {e}")
        print("Убедитесь, что все модули Wolf находятся в той же директории")
        return 1
    except Exception as e:
        print(f"❌ Критическая ошибка: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
'''
        
        launcher_file = self.build_dir / "wolf.py"
        with open(launcher_file, 'w', encoding='utf-8') as f:
            f.write(launcher_content)
        
        print(f"✅ Запускатель создан: {launcher_file}")
    
    def create_batch_files(self):
        """Создание batch файлов для Windows"""
        print("🪟 Создание batch файлов для Windows...")
        
        # Основной batch файл
        batch_content = '''@echo off
chcp 65001 > nul
cd /d "%~dp0"
python wolf.py %*
if errorlevel 1 (
    echo.
    echo ❌ Ошибка выполнения Wolf
    pause
)
'''
        
        batch_file = self.build_dir / "wolf.bat"
        with open(batch_file, 'w', encoding='utf-8') as f:
            f.write(batch_content)
        
        # REPL batch файл
        repl_batch = '''@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo 🐺 Запуск Wolf REPL...
python wolf.py -i
pause
'''
        
        repl_file = self.build_dir / "wolf_repl.bat"
        with open(repl_file, 'w', encoding='utf-8') as f:
            f.write(repl_batch)
        
        print("✅ Batch файлы созданы")
    
    def create_shell_scripts(self):
        """Создание shell скриптов для Linux/macOS"""
        print("🐧 Создание shell скриптов...")
        
        # Основной shell скрипт
        shell_content = '''#!/bin/bash
cd "$(dirname "$0")"
python3 wolf.py "$@"
'''
        
        shell_file = self.build_dir / "wolf.sh"
        with open(shell_file, 'w', encoding='utf-8') as f:
            f.write(shell_content)
        os.chmod(shell_file, 0o755)
        
        # REPL shell скрипт
        repl_shell = '''#!/bin/bash
cd "$(dirname "$0")"
echo "🐺 Запуск Wolf REPL..."
python3 wolf.py -i
'''
        
        repl_file = self.build_dir / "wolf_repl.sh"
        with open(repl_file, 'w', encoding='utf-8') as f:
            f.write(repl_shell)
        os.chmod(repl_file, 0o755)
        
        print("✅ Shell скрипты созданы")
    
    def create_readme(self):
        """Создание README файла"""
        print("📖 Создание документации...")
        
        readme_content = '''# 🐺 Wolf Programming Language v1.0

## Быстрый старт

### Windows
```bash
wolf.bat                    # REPL
wolf.bat script.wolf        # Выполнение файла
wolf_repl.bat              # Только REPL
```

### Linux/macOS
```bash
./wolf.sh                  # REPL
./wolf.sh script.wolf       # Выполнение файла
./wolf_repl.sh             # Только REPL
```

### Универсально
```bash
python wolf.py             # REPL
python wolf.py script.wolf  # Выполнение файла
```

## Возможности Wolf v6.2

### ✅ Реализованные модули
- 🧠 **wolf_core_advanced.py** - Ядро языка
- 📝 **wolf_simple_parser.py** - Парсер 
- 🔧 **wolf_unified_interpreter.py** - Интерпретатор
- 📊 **wolf_math.py** - Математические функции
- 🧠 **wolf_nn.py** - Нейронные сети
- 🖥️ **wolf_hardware.py** - Аппаратная диагностика
- 📦 **wolf_import.py** - Система импорта
- 🖼️ **wolf_gui.py** - Графический интерфейс
- 🎮 **wolf_game.py** - Игровые функции

### 📝 Синтаксис

#### Переменные и операции
```wolf
x = 10
y = 20.5
текст = "Привет, Wolf!"
список = [1, 2, 3, 4, 5]
```

#### Функции
```wolf
функция сложить(a, b):
    вернуть a + b

результат = сложить(10, 20)
вывести(результат)
```

#### Классы
```wolf
класс Калькулятор:
    функция __init__(self):
        self.результат = 0
    
    функция сложить(self, число):
        self.результат += число

калк = Калькулятор()
калк.сложить(15)
```

#### Модули
```wolf
использовать математика
использовать аппаратура как железо

x = синус(пи / 2)
процессор = железо.процессор_инфо()
```

#### Нейронные сети
```wolf
использовать нейросеть

нейросеть МояСеть:
    линейный(вход=10, выход=5)
    релю
    линейный(вход=5, выход=1)
    сигмоид
```

## Тестирование

### Быстрый тест
```bash
python wolf.py test_simple.wolf
```

### Полный тест
```bash
python wolf.py test_unified.wolf
```

## Архитектура

Wolf v6.2 имеет модульную архитектуру:

1. **Ядро** - Базовые типы данных, токены, исключения
2. **Парсер** - Простой рекурсивный парсер 
3. **Интерпретатор** - Унифицированный интерпретатор с поддержкой всех модулей
4. **Модули** - Специализированные модули для разных задач

## Производительность

- ⚡ Быстрый старт - менее 1 секунды
- 🧠 Поддержка нейросетей - базовая архитектура
- 📊 Математические вычисления - синус, косинус, логарифм
- 🖥️ Системная информация - процессор, память, температура

## Планы развития

### v7.0 - Native Compiler
- 🦀 Переписать на Rust для независимости от Python
- ⚡ Компиляция в машинный код
- 🔧 Статическая типизация
- 📦 Менеджер пакетов

### IDE Integration
- 🎨 Visual Studio Code расширение
- 🔍 Подсветка синтаксиса
- 🐛 Отладчик
- 📝 Автодополнение

## Поддержка
-🐙 GitHub: https://github.com/wolf-lang-dev

---
🐺 **Wolf Programming Language** - Программирование на русском языке!
'''
        
        readme_file = self.build_dir / "README.md"
        with open(readme_file, 'w', encoding='utf-8') as f:
            f.write(readme_content)
        
        print(f"✅ Документация создана: {readme_file}")
    
    def create_distribution(self):
        """Создание дистрибутива"""
        print("📦 Создание дистрибутива...")
        
        # Создаем ZIP архив
        zip_file = self.dist_dir / "Wolf_v6.2_Unified.zip"
        
        with zipfile.ZipFile(zip_file, 'w', zipfile.ZIP_DEFLATED) as zf:
            for file_path in self.build_dir.rglob('*'):
                if file_path.is_file():
                    arc_name = file_path.relative_to(self.build_dir)
                    zf.write(file_path, arc_name)
        
        print(f"✅ Дистрибутив создан: {zip_file}")
        
        # Создаем portable версию
        portable_dir = self.dist_dir / "Wolf_Portable"
        if portable_dir.exists():
            shutil.rmtree(portable_dir)
        
        shutil.copytree(self.build_dir, portable_dir)
        print(f"✅ Portable версия: {portable_dir}")
        
        return zip_file, portable_dir
    
    def build(self):
        """Основной процесс сборки"""
        print("🐺 ФИНАЛЬНАЯ СБОРКА WOLF v6.2 UNIFIED")
        print("=" * 60)
        
        # Очистка
        self.clean_build()
        
        # Копирование модулей
        copied, missing = self.copy_modules()
        
        # Копирование тестов
        self.copy_test_files()
        
        # Создание запускателя
        self.create_launcher()
        
        # Создание скриптов
        self.create_batch_files()
        self.create_shell_scripts()
        
        # Создание документации
        self.create_readme()
        
        # Создание дистрибутива
        zip_file, portable_dir = self.create_distribution()
        
        print("=" * 60)
        print("✅ ФИНАЛЬНАЯ СБОРКА ЗАВЕРШЕНА!")
        print(f"📁 Сборка: {self.build_dir}")
        print(f"📦 Дистрибутив: {zip_file}")
        print(f"💾 Portable: {portable_dir}")
        print(f"📊 Модулей: {copied} из {copied + missing}")
        
        if missing == 0:
            print("🎉 Все модули включены в сборку!")
        else:
            print(f"⚠️ Отсутствует модулей: {missing}")
        
        print("\n🚀 Для запуска:")
        print(f"   cd {self.build_dir}")
        print("   python wolf.py")

def main():
    """Главная функция"""
    builder = WolfFinalBuilder()
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "clean":
            builder.clean_build()
        elif sys.argv[1] == "build":
            builder.build()
        elif sys.argv[1] == "dist":
            builder.clean_build()
            builder.copy_modules()
            builder.copy_test_files()
            builder.create_launcher()
            builder.create_batch_files()
            builder.create_shell_scripts()
            builder.create_readme()
            builder.create_distribution()
        else:
            print("Использование: python wolf_final_build.py [clean|build|dist]")
    else:
        builder.build()

if __name__ == "__main__":
    main()