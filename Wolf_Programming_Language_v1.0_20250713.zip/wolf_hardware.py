#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Wolf Programming Language - Hardware Module
Модуль для мониторинга и управления аппаратным обеспечением
"""

import platform
import time
from typing import Dict, List, Optional

# Попытка импорта psutil для мониторинга системы
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("⚠️ psutil не установлен. Установите: pip install psutil")

# Попытка импорта GPUtil для мониторинга GPU
try:
    import GPUtil
    GPUTIL_AVAILABLE = True
except ImportError:
    GPUTIL_AVAILABLE = False
    print("⚠️ GPUtil не установлен. Установите: pip install gputil")

class WolfHardwareMonitor:
    """Монитор аппаратного обеспечения Wolf"""
    
    def __init__(self):
        self.system_info = self._get_system_info()
    
    def _get_system_info(self) -> Dict:
        """Получить информацию о системе"""
        info = {
            "операционная_система": platform.system(),
            "версия_ос": platform.version(),
            "архитектура": platform.machine(),
            "процессор": platform.processor(),
            "имя_компьютера": platform.node(),
            "python_версия": platform.python_version()
        }
        return info
    
    def информация_о_системе(self) -> Dict:
        """Получить полную информацию о системе"""
        return self.system_info
    
    def загрузка_процессора(self, интервал: float = 1.0) -> float:
        """
        Получить загрузку процессора в процентах
        
        Args:
            интервал: Интервал измерения в секундах
            
        Returns:
            Загрузка процессора в процентах
        """
        if not PSUTIL_AVAILABLE:
            print("❌ psutil недоступен")
            return 0.0
        
        try:
            return psutil.cpu_percent(interval=интервал)
        except Exception as e:
            print(f"❌ Ошибка получения загрузки CPU: {e}")
            return 0.0
    
    def температура_процессора(self) -> Optional[float]:
        """Получить температуру процессора"""
        if not PSUTIL_AVAILABLE:
            print("❌ psutil недоступен")
            return None
        
        try:
            temperatures = psutil.sensors_temperatures()
            if temperatures:
                # Ищем температуру CPU
                for name, entries in temperatures.items():
                    if 'cpu' in name.lower() or 'core' in name.lower():
                        if entries:
                            return entries[0].current
                
                # Если не найдено, берем первую доступную
                for name, entries in temperatures.items():
                    if entries:
                        return entries[0].current
            
            return None
        except Exception as e:
            print(f"❌ Ошибка получения температуры CPU: {e}")
            return None
    
    def использование_памяти(self) -> Dict:
        """Получить информацию об использовании памяти"""
        if not PSUTIL_AVAILABLE:
            print("❌ psutil недоступен")
            return {}
        
        try:
            memory = psutil.virtual_memory()
            return {
                "общая": round(memory.total / (1024**3), 2),  # ГБ
                "доступная": round(memory.available / (1024**3), 2),  # ГБ
                "используется": round(memory.used / (1024**3), 2),  # ГБ
                "процент_использования": memory.percent
            }
        except Exception as e:
            print(f"❌ Ошибка получения информации о памяти: {e}")
            return {}
    
    def информация_о_дисках(self) -> List[Dict]:
        """Получить информацию о дисках"""
        if not PSUTIL_AVAILABLE:
            print("❌ psutil недоступен")
            return []
        
        try:
            disks = []
            partitions = psutil.disk_partitions()
            
            for partition in partitions:
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    disk_info = {
                        "устройство": partition.device,
                        "точка_монтирования": partition.mountpoint,
                        "файловая_система": partition.fstype,
                        "общий_размер": round(usage.total / (1024**3), 2),  # ГБ
                        "использовано": round(usage.used / (1024**3), 2),  # ГБ
                        "свободно": round(usage.free / (1024**3), 2),  # ГБ
                        "процент_использования": round((usage.used / usage.total) * 100, 1)
                    }
                    disks.append(disk_info)
                except PermissionError:
                    # Пропускаем недоступные диски
                    continue
            
            return disks
        except Exception as e:
            print(f"❌ Ошибка получения информации о дисках: {e}")
            return []
    
    def загрузка_видеокарты(self) -> List[Dict]:
        """Получить информацию о видеокартах"""
        if not GPUTIL_AVAILABLE:
            print("❌ GPUtil недоступен")
            return []
        
        try:
            gpus = GPUtil.getGPUs()
            gpu_info = []
            
            for gpu in gpus:
                info = {
                    "имя": gpu.name,
                    "загрузка": round(gpu.load * 100, 1),  # Процент
                    "память_всего": gpu.memoryTotal,  # МБ
                    "память_используется": gpu.memoryUsed,  # МБ
                    "память_свободна": gpu.memoryFree,  # МБ
                    "температура": gpu.temperature,  # Градусы
                    "uuid": gpu.uuid
                }
                gpu_info.append(info)
            
            return gpu_info
        except Exception as e:
            print(f"❌ Ошибка получения информации о GPU: {e}")
            return []
    
    def температура_видеокарты(self) -> Optional[float]:
        """Получить температуру первой видеокарты"""
        gpu_info = self.загрузка_видеокарты()
        if gpu_info and len(gpu_info) > 0:
            return gpu_info[0].get("температура")
        return None
    
    def сетевая_статистика(self) -> Dict:
        """Получить статистику сети"""
        if not PSUTIL_AVAILABLE:
            print("❌ psutil недоступен")
            return {}
        
        try:
            net_io = psutil.net_io_counters()
            return {
                "байт_отправлено": net_io.bytes_sent,
                "байт_получено": net_io.bytes_recv,
                "пакетов_отправлено": net_io.packets_sent,
                "пакетов_получено": net_io.packets_recv,
                "ошибок_входящих": net_io.errin,
                "ошибок_исходящих": net_io.errout
            }
        except Exception as e:
            print(f"❌ Ошибка получения сетевой статистики: {e}")
            return {}
    
    def список_процессов(self, топ: int = 10) -> List[Dict]:
        """Получить список топ процессов по использованию CPU"""
        if not PSUTIL_AVAILABLE:
            print("❌ psutil недоступен")
            return []
        
        try:
            processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    proc_info = proc.info
                    if proc_info['cpu_percent'] is not None:
                        processes.append({
                            "pid": proc_info['pid'],
                            "имя": proc_info['name'],
                            "cpu_процент": proc_info['cpu_percent'],
                            "память_процент": round(proc_info['memory_percent'], 2)
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Сортируем по использованию CPU
            processes.sort(key=lambda x: x['cpu_процент'], reverse=True)
            return processes[:топ]
        except Exception as e:
            print(f"❌ Ошибка получения списка процессов: {e}")
            return []
    
    def мониторинг_в_реальном_времени(self, длительность: int = 10, интервал: float = 1.0):
        """Мониторинг системы в реальном времени"""
        print("🔄 Мониторинг системы в реальном времени")
        print("Нажмите Ctrl+C для остановки")
        print("-" * 60)
        
        try:
            for i in range(длительность):
                cpu_usage = self.загрузка_процессора(интервал)
                memory_info = self.использование_памяти()
                gpu_info = self.загрузка_видеокарты()
                
                print(f"\n⏱️ Время: {i+1}/{длительность}")
                print(f"🖥️ CPU: {cpu_usage}%")
                
                if memory_info:
                    print(f"💾 RAM: {memory_info['процент_использования']}% "
                          f"({memory_info['используется']}/{memory_info['общая']} ГБ)")
                
                if gpu_info:
                    for j, gpu in enumerate(gpu_info):
                        print(f"🎮 GPU {j+1}: {gpu['загрузка']}% "
                              f"({gpu['температура']}°C)")
                
                if i < длительность - 1:
                    time.sleep(интервал)
                
        except KeyboardInterrupt:
            print("\n🔚 Мониторинг остановлен пользователем")
        except Exception as e:
            print(f"❌ Ошибка мониторинга: {e}")

# Глобальный экземпляр монитора
hardware_monitor = WolfHardwareMonitor()

# Функции для использования в Wolf
def загрузка_процессора(интервал: float = 1.0) -> float:
    """Получить загрузку процессора"""
    return hardware_monitor.загрузка_процессора(интервал)

def температура_процессора() -> Optional[float]:
    """Получить температуру процессора"""
    return hardware_monitor.температура_процессора()

def использование_памяти() -> Dict:
    """Получить информацию о памяти"""
    return hardware_monitor.использование_памяти()

def информация_о_дисках() -> List[Dict]:
    """Получить информацию о дисках"""
    return hardware_monitor.информация_о_дисках()

def загрузка_видеокарты() -> List[Dict]:
    """Получить информацию о видеокартах"""
    return hardware_monitor.загрузка_видеокарты()

def температура_видеокарты() -> Optional[float]:
    """Получить температуру видеокарты"""
    return hardware_monitor.температура_видеокарты()

def информация_о_системе() -> Dict:
    """Получить информацию о системе"""
    return hardware_monitor.информация_о_системе()

def мониторинг_системы(длительность: int = 10, интервал: float = 1.0):
    """Запустить мониторинг системы"""
    hardware_monitor.мониторинг_в_реальном_времени(длительность, интервал)

class WolfHardware:
    """Основной класс для работы с аппаратурой в Wolf"""
    
    @staticmethod
    def процессор_инфо():
        """Получить информацию о процессоре"""
        return f"{platform.processor()} ({platform.machine()})"
    
    @staticmethod
    def память_инфо():
        """Получить информацию о памяти"""
        memory = использование_памяти()
        if memory:
            return f"{memory['процент_использования']}% ({memory['используется']}/{memory['общая']} ГБ)"
        return "Недоступно"
    
    @staticmethod
    def температура():
        """Получить температуру системы"""
        temp = температура_процессора()
        return temp if temp else "Недоступно"

def установить_зависимости():
    """Установить необходимые библиотеки"""
    import subprocess
    import sys
    
    libraries = ['psutil', 'gputil']
    
    for lib in libraries:
        try:
            print(f"📥 Установка {lib}...")
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', lib])
            print(f"✅ {lib} установлен")
        except subprocess.CalledProcessError as e:
            print(f"❌ Ошибка установки {lib}: {e}")

if __name__ == "__main__":
    print("🐺 Wolf Hardware Module - Demo")
    print("=" * 50)
    
    # Проверка доступности библиотек
    print("📋 ПРОВЕРКА ЗАВИСИМОСТЕЙ:")
    print(f"  psutil: {'✅ Доступен' if PSUTIL_AVAILABLE else '❌ Не установлен'}")
    print(f"  GPUtil: {'✅ Доступен' if GPUTIL_AVAILABLE else '❌ Не установлен'}")
    
    if not PSUTIL_AVAILABLE or not GPUTIL_AVAILABLE:
        choice = input("\n📥 Установить недостающие библиотеки? (y/n): ").lower()
        if choice == 'y':
            установить_зависимости()
            print("🔄 Перезапустите программу для применения изменений")
            exit()
    
    print("\n🖥️ ИНФОРМАЦИЯ О СИСТЕМЕ:")
    sys_info = информация_о_системе()
    for key, value in sys_info.items():
        print(f"  {key}: {value}")
    
    print("\n📊 ТЕКУЩЕЕ СОСТОЯНИЕ:")
    
    # CPU
    cpu_usage = загрузка_процессора()
    cpu_temp = температура_процессора()
    print(f"🖥️ CPU: {cpu_usage}%", end="")
    if cpu_temp:
        print(f" ({cpu_temp}°C)")
    else:
        print()
    
    # Память
    memory = использование_памяти()
    if memory:
        print(f"💾 RAM: {memory['процент_использования']}% "
              f"({memory['используется']}/{memory['общая']} ГБ)")
    
    # GPU
    gpu_info = загрузка_видеокарты()
    if gpu_info:
        for i, gpu in enumerate(gpu_info):
            print(f"🎮 GPU {i+1} ({gpu['имя']}): {gpu['загрузка']}% "
                  f"({gpu['температура']}°C)")
    
    # Диски
    disks = информация_о_дисках()
    if disks:
        print("\n💿 ДИСКИ:")
        for disk in disks:
            print(f"  {disk['устройство']}: {disk['процент_использования']}% "
                  f"({disk['свободно']} ГБ свободно)")
    
    # Предложение мониторинга
    choice = input("\n🔄 Запустить мониторинг в реальном времени? (y/n): ").lower()
    if choice == 'y':
        мониторинг_системы(10, 1.0)