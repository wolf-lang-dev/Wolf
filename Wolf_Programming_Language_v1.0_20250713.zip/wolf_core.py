"""
Wolf Programming Language v1.0 - Core Module
Ядро языка программирования Wolf
"""

import sys
import re
import os
import json
from typing import Dict, List, Any, Optional, Union
from enum import Enum
from dataclasses import dataclass

print("🐺 Wolf Core v1.0 загружен!")

print("🐺 Wolf Core v1.0 загружен!")

# ===== ТИПЫ ДАННЫХ =====
class WolfType(Enum):
    INT = "int"
    FLOAT = "float"
    STRING = "str"
    BOOL = "bool"
    TENSOR = "Tensor"
    LIST = "list"
    DICT = "dict"
    FUNCTION = "function"
    CLASS = "class"
    OBJECT = "object"
    NEURAL_NET = "нейросеть"
    FILE = "file"
    NONE = "None"
    
@dataclass
class WolfValue:
    """Значение в Wolf"""
    type: WolfType
    value: Any
    
    def __str__(self):
        return f"{self.type.value}({self.value})"

# ===== ИСКЛЮЧЕНИЯ =====
class WolfException(Exception):
    """Базовое исключение Wolf"""
    pass

class WolfSyntaxError(WolfException):
    """Синтаксическая ошибка"""
    pass

class WolfRuntimeError(WolfException):
    """Ошибка выполнения"""
    pass

class WolfTypeError(WolfException):
    """Ошибка типа"""
    pass

class WolfFileError(WolfException):
    """Ошибка файла"""
    pass

class WolfAttributeError(WolfException):
    """Ошибка атрибута"""
    pass

# ===== ТОКЕНЫ =====
class TokenType(Enum):
    # Ключевые слова
    FUNCTION = "функция"
    CLASS = "класс"
    NEURAL_NET = "нейросеть"
    FOR = "для"
    IN = "в"
    IF = "если"
    ELSE = "иначе"
    WHILE = "пока"
    RETURN = "вернуть"
    IMPORT = "использовать"
    TRY = "попробовать"
    EXCEPT = "исключение"
    FINALLY = "наконец"
    RAISE = "вызвать"
    SELF = "self"
    
    # Встроенные функции
    PRINT = "вывести"
    INPUT = "ввести"
    LEN = "длина"
    TYPE = "тип"
    OPEN = "открыть"
    
    # Типы данных
    INT_TYPE = "int"
    FLOAT_TYPE = "float"
    STRING_TYPE = "str"
    BOOL_TYPE = "bool"
    TENSOR_TYPE = "Tensor"
    LIST_TYPE = "list"
    DICT_TYPE = "dict"
    
    # Литералы
    INTEGER = "INTEGER"
    FLOAT = "FLOAT"
    STRING = "STRING"
    TRUE = "TRUE"
    FALSE = "FALSE"
    NONE = "NONE"
    
    # Идентификаторы
    IDENTIFIER = "IDENTIFIER"
    
    # Операторы
    PLUS = "+"
    MINUS = "-"
    MULTIPLY = "*"
    DIVIDE = "/"
    MODULO = "%"
    POWER = "**"
    ASSIGN = "="
    PLUS_ASSIGN = "+="
    MINUS_ASSIGN = "-="
    MULTIPLY_ASSIGN = "*="
    DIVIDE_ASSIGN = "/="
    
    # Сравнения
    EQUAL = "=="
    NOT_EQUAL = "!="
    LESS = "<"
    GREATER = ">"
    LESS_EQUAL = "<="
    GREATER_EQUAL = ">="
    
    # Логические
    AND = "и"
    OR = "или"
    NOT = "не"
    
    # Разделители
    LPAREN = "("
    RPAREN = ")"
    LBRACE = "{"
    RBRACE = "}"
    LBRACKET = "["
    RBRACKET = "]"
    COMMA = ","
    COLON = ":"
    SEMICOLON = ";"
    DOT = "."
    ARROW = "->"
    
    # Специальные
    NEWLINE = "NEWLINE"
    EOF = "EOF"
    INDENT = "INDENT"
    DEDENT = "DEDENT"

@dataclass
class Token:
    type: TokenType
    value: str
    line: int
    column: int

# ===== ЛЕКСЕР =====
class Lexer:
    def __init__(self, text: str):
        self.text = text
        self.pos = 0
        self.line = 1
        self.column = 1
        self.tokens = []
        self.indent_stack = [0]  # стек отступов
        
        # Ключевые слова
        self.keywords = {
            'функция': TokenType.FUNCTION,
            'класс': TokenType.CLASS,
            'нейросеть': TokenType.NEURAL_NET,
            'для': TokenType.FOR,
            'в': TokenType.IN,
            'если': TokenType.IF,
            'иначе': TokenType.ELSE,
            'пока': TokenType.WHILE,
            'вернуть': TokenType.RETURN,
            'использовать': TokenType.IMPORT,
            'попробовать': TokenType.TRY,
            'исключение': TokenType.EXCEPT,
            'наконец': TokenType.FINALLY,
            'вызвать': TokenType.RAISE,
            'self': TokenType.SELF,
            'вывести': TokenType.PRINT,
            'ввести': TokenType.INPUT,
            'длина': TokenType.LEN,
            'тип': TokenType.TYPE,
            'открыть': TokenType.OPEN,
            'int': TokenType.INT_TYPE,
            'float': TokenType.FLOAT_TYPE,
            'str': TokenType.STRING_TYPE,
            'bool': TokenType.BOOL_TYPE,
            'list': TokenType.LIST_TYPE,
            'dict': TokenType.DICT_TYPE,
            'да': TokenType.TRUE,
            'нет': TokenType.FALSE,
            'None': TokenType.NONE,
            'и': TokenType.AND,
            'или': TokenType.OR,
            'не': TokenType.NOT,
        }
    
    def current_char(self) -> Optional[str]:
        if self.pos >= len(self.text):
            return None
        return self.text[self.pos]
    
    def peek_char(self, offset: int = 1) -> Optional[str]:
        peek_pos = self.pos + offset
        if peek_pos >= len(self.text):
            return None
        return self.text[peek_pos]
    
    def advance(self):
        if self.pos < len(self.text) and self.text[self.pos] == '\n':
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        self.pos += 1
    
    def skip_whitespace(self):
        while self.current_char() and self.current_char() in ' \t\r':
            self.advance()
    
    def skip_comment(self):
        if self.current_char() == '#':
            while self.current_char() and self.current_char() != '\n':
                self.advance()
    
    def read_number(self) -> Token:
        start_pos = self.pos
        start_col = self.column
        
        while self.current_char() and self.current_char().isdigit():
            self.advance()
        
        if self.current_char() == '.' and self.peek_char() and self.peek_char().isdigit():
            self.advance()  # пропускаем точку
            while self.current_char() and self.current_char().isdigit():
                self.advance()
            return Token(TokenType.FLOAT, self.text[start_pos:self.pos], self.line, start_col)
        
        return Token(TokenType.INTEGER, self.text[start_pos:self.pos], self.line, start_col)
    
    def read_string(self) -> Token:
        start_col = self.column
        quote_char = self.current_char()
        self.advance()  # пропускаем открывающую кавычку
        
        value = ""
        while self.current_char() and self.current_char() != quote_char:
            if self.current_char() == '\\':
                self.advance()
                if self.current_char() == 'n':
                    value += '\n'
                elif self.current_char() == 't':
                    value += '\t'
                elif self.current_char() == 'r':
                    value += '\r'
                elif self.current_char() == '\\':
                    value += '\\'
                elif self.current_char() == quote_char:
                    value += quote_char
                else:
                    value += self.current_char()
            else:
                value += self.current_char()
            self.advance()
        
        if self.current_char() == quote_char:
            self.advance()  # пропускаем закрывающую кавычку
        
        return Token(TokenType.STRING, value, self.line, start_col)
    
    def read_identifier(self) -> Token:
        start_pos = self.pos
        start_col = self.column
        
        while (self.current_char() and 
               (self.current_char().isalnum() or self.current_char() == '_' or 
                ord(self.current_char()) >= 1040)):  # поддержка русских букв
            self.advance()
        
        value = self.text[start_pos:self.pos]
        token_type = self.keywords.get(value, TokenType.IDENTIFIER)
        
        return Token(token_type, value, self.line, start_col)
    
    def handle_indentation(self) -> List[Token]:
        """Обработка отступов"""
        indent_tokens = []
        
        # Считаем отступы
        indent_level = 0
        pos = self.pos
        
        while pos < len(self.text) and self.text[pos] in ' \t':
            if self.text[pos] == ' ':
                indent_level += 1
            elif self.text[pos] == '\t':
                indent_level += 4  # табуляция = 4 пробела
            pos += 1
        
        current_indent = self.indent_stack[-1]
        
        if indent_level > current_indent:
            # Увеличение отступа
            self.indent_stack.append(indent_level)
            indent_tokens.append(Token(TokenType.INDENT, "", self.line, self.column))
        elif indent_level < current_indent:
            # Уменьшение отступа
            while self.indent_stack and self.indent_stack[-1] > indent_level:
                self.indent_stack.pop()
                indent_tokens.append(Token(TokenType.DEDENT, "", self.line, self.column))
        
        # Пропускаем отступы
        while self.current_char() and self.current_char() in ' \t':
            self.advance()
        
        return indent_tokens
    
    def tokenize(self) -> List[Token]:
        tokens = []
        
        while self.current_char():
            # Обработка новой строки
            if self.current_char() == '\n':
                tokens.append(Token(TokenType.NEWLINE, '\n', self.line, self.column))
                self.advance()
                
                # Проверяем отступы после новой строки
                if self.current_char() and self.current_char() in ' \t':
                    tokens.extend(self.handle_indentation())
                
                continue
            
            # Пропускаем пробелы и табуляции
            if self.current_char() in ' \t':
                self.skip_whitespace()
                continue
            
            # Пропускаем комментарии
            if self.current_char() == '#':
                self.skip_comment()
                continue
            
            # Числа
            if self.current_char().isdigit():
                tokens.append(self.read_number())
                continue
            
            # Строки
            if self.current_char() in '"\'':
                tokens.append(self.read_string())
                continue
            
            # Идентификаторы и ключевые слова
            if (self.current_char().isalpha() or self.current_char() == '_' or 
                ord(self.current_char()) >= 1040):  # русские буквы
                tokens.append(self.read_identifier())
                continue
            
            # Операторы из двух символов
            if self.current_char() == '+' and self.peek_char() == '=':
                tokens.append(Token(TokenType.PLUS_ASSIGN, '+=', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '-' and self.peek_char() == '=':
                tokens.append(Token(TokenType.MINUS_ASSIGN, '-=', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '*' and self.peek_char() == '=':
                tokens.append(Token(TokenType.MULTIPLY_ASSIGN, '*=', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '/' and self.peek_char() == '=':
                tokens.append(Token(TokenType.DIVIDE_ASSIGN, '/=', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '*' and self.peek_char() == '*':
                tokens.append(Token(TokenType.POWER, '**', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '=' and self.peek_char() == '=':
                tokens.append(Token(TokenType.EQUAL, '==', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '!' and self.peek_char() == '=':
                tokens.append(Token(TokenType.NOT_EQUAL, '!=', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '<' and self.peek_char() == '=':
                tokens.append(Token(TokenType.LESS_EQUAL, '<=', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '>' and self.peek_char() == '=':
                tokens.append(Token(TokenType.GREATER_EQUAL, '>=', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            if self.current_char() == '-' and self.peek_char() == '>':
                tokens.append(Token(TokenType.ARROW, '->', self.line, self.column))
                self.advance()
                self.advance()
                continue
            
            # Одиночные операторы
            single_char_tokens = {
                '+': TokenType.PLUS,
                '-': TokenType.MINUS,
                '*': TokenType.MULTIPLY,
                '/': TokenType.DIVIDE,
                '%': TokenType.MODULO,
                '=': TokenType.ASSIGN,
                '<': TokenType.LESS,
                '>': TokenType.GREATER,
                '(': TokenType.LPAREN,
                ')': TokenType.RPAREN,
                '{': TokenType.LBRACE,
                '}': TokenType.RBRACE,
                '[': TokenType.LBRACKET,
                ']': TokenType.RBRACKET,
                ',': TokenType.COMMA,
                ':': TokenType.COLON,
                ';': TokenType.SEMICOLON,
                '.': TokenType.DOT,
            }
            
            if self.current_char() in single_char_tokens:
                token_type = single_char_tokens[self.current_char()]
                tokens.append(Token(token_type, self.current_char(), self.line, self.column))
                self.advance()
                continue
            
            # Неизвестный символ
            raise WolfSyntaxError(f"Неизвестный символ '{self.current_char()}' на строке {self.line}, столбец {self.column}")
        
        # Добавляем финальные DEDENT токены
        while len(self.indent_stack) > 1:
            self.indent_stack.pop()
            tokens.append(Token(TokenType.DEDENT, "", self.line, self.column))
        
        tokens.append(Token(TokenType.EOF, "", self.line, self.column))
        return tokens

# ===== AST УЗЛЫ =====
class ASTNode:
    pass

class Program(ASTNode):
    def __init__(self, statements: List[ASTNode]):
        self.statements = statements

class Statement(ASTNode):
    pass

class Expression(ASTNode):
    pass

class FunctionDef(Statement):
    def __init__(self, name: str, params: List[str], body: List[Statement], return_type: Optional[str] = None):
        self.name = name
        self.params = params
        self.body = body
        self.return_type = return_type

class ClassDef(Statement):
    def __init__(self, name: str, methods: List[FunctionDef], attributes: Dict[str, Any] = None):
        self.name = name
        self.methods = methods
        self.attributes = attributes or {}

class IfStatement(Statement):
    def __init__(self, condition: Expression, then_body: List[Statement], else_body: Optional[List[Statement]] = None):
        self.condition = condition
        self.then_body = then_body
        self.else_body = else_body or []

class ForStatement(Statement):
    def __init__(self, var: str, iterable: Expression, body: List[Statement]):
        self.var = var
        self.iterable = iterable
        self.body = body

class WhileStatement(Statement):
    def __init__(self, condition: Expression, body: List[Statement]):
        self.condition = condition
        self.body = body

class TryStatement(Statement):
    def __init__(self, try_body: List[Statement], except_clauses: List[tuple], finally_body: Optional[List[Statement]] = None):
        self.try_body = try_body
        self.except_clauses = except_clauses  # [(exception_type, var_name, body), ...]
        self.finally_body = finally_body or []

class Assignment(Statement):
    def __init__(self, target: str, value: Expression, op: str = "="):
        self.target = target
        self.value = value
        self.op = op

class ReturnStatement(Statement):
    def __init__(self, value: Optional[Expression] = None):
        self.value = value

class ExpressionStatement(Statement):
    def __init__(self, expression: Expression):
        self.expression = expression

class BinaryOp(Expression):
    def __init__(self, left: Expression, op: str, right: Expression):
        self.left = left
        self.op = op
        self.right = right

class UnaryOp(Expression):
    def __init__(self, op: str, operand: Expression):
        self.op = op
        self.operand = operand

class FunctionCall(Expression):
    def __init__(self, name: str, args: List[Expression]):
        self.name = name
        self.args = args

class MethodCall(Expression):
    def __init__(self, object: Expression, method: str, args: List[Expression]):
        self.object = object
        self.method = method
        self.args = args

class AttributeAccess(Expression):
    def __init__(self, object: Expression, attribute: str):
        self.object = object
        self.attribute = attribute

class ListLiteral(Expression):
    def __init__(self, elements: List[Expression]):
        self.elements = elements

class DictLiteral(Expression):
    def __init__(self, pairs: List[tuple]):
        self.pairs = pairs  # [(key, value), ...]

class IndexAccess(Expression):
    def __init__(self, object: Expression, index: Expression):
        self.object = object
        self.index = index

class Identifier(Expression):
    def __init__(self, name: str):
        self.name = name

class Literal(Expression):
    def __init__(self, value: Any, type: WolfType):
        self.value = value
        self.type = type

# ===== ВСТРОЕННЫЕ ФУНКЦИИ =====
class WolfBuiltins:
    @staticmethod
    def wolf_print(*args):
        """Функция вывести"""
        output = []
        for arg in args:
            if isinstance(arg, WolfValue):
                if arg.type == WolfType.STRING:
                    output.append(arg.value)
                else:
                    output.append(str(arg.value))
            else:
                output.append(str(arg))
        print(' '.join(output))
    
    @staticmethod
    def wolf_input(prompt=""):
        """Функция ввести"""
        return input(prompt)
    
    @staticmethod
    def wolf_len(obj):
        """Функция длина"""
        if isinstance(obj, WolfValue):
            if obj.type in [WolfType.LIST, WolfType.STRING, WolfType.DICT]:
                return len(obj.value)
        return len(obj)
    
    @staticmethod
    def wolf_type(obj):
        """Функция тип"""
        if isinstance(obj, WolfValue):
            return obj.type.value
        return type(obj).__name__
    
    @staticmethod
    def wolf_str(obj):
        """Функция строка"""
        if isinstance(obj, WolfValue):
            return str(obj.value)
        return str(obj)
    
    @staticmethod
    def wolf_int(obj):
        """Функция число"""
        if isinstance(obj, WolfValue):
            return int(obj.value)
        return int(obj)
    
    @staticmethod
    def wolf_float(obj):
        """Функция дробь"""
        if isinstance(obj, WolfValue):
            return float(obj.value)
        return float(obj)
    
    @staticmethod
    def wolf_open(filename, mode="r"):
        """Функция открыть"""
        try:
            return open(filename, mode, encoding='utf-8')
        except Exception as e:
            raise WolfFileError(f"Ошибка открытия файла: {e}")

# ===== КЛАСС WOLF =====
class WolfClass:
    def __init__(self, name: str, methods: Dict[str, 'WolfFunction'], attributes: Dict[str, Any] = None):
        self.name = name
        self.methods = methods
        self.attributes = attributes or {}
    
    def create_instance(self, *args, **kwargs):
        """Создание экземпляра класса"""
        instance = WolfObject(self)
        
        # Вызываем __init__ если есть
        if '__init__' in self.methods:
            self.methods['__init__'].call(instance, *args, **kwargs)
        
        return instance

class WolfObject:
    def __init__(self, wolf_class: WolfClass):
        self.wolf_class = wolf_class
        self.attributes = {}
    
    def get_attribute(self, name: str):
        """Получение атрибута"""
        if name in self.attributes:
            return self.attributes[name]
        elif name in self.wolf_class.methods:
            return self.wolf_class.methods[name]
        elif name in self.wolf_class.attributes:
            return self.wolf_class.attributes[name]
        else:
            raise WolfAttributeError(f"У объекта {self.wolf_class.name} нет атрибута {name}")
    
    def set_attribute(self, name: str, value: Any):
        """Установка атрибута"""
        self.attributes[name] = value

class WolfFunction:
    def __init__(self, name: str, params: List[str], body: List[Statement], closure: Dict[str, Any] = None):
        self.name = name
        self.params = params
        self.body = body
        self.closure = closure or {}
    
    def call(self, interpreter, *args, **kwargs):
        """Вызов функции"""
        # Создаем новую область видимости
        old_scope = interpreter.current_scope
        new_scope = dict(self.closure)
        
        # Привязываем аргументы к параметрам
        for i, param in enumerate(self.params):
            if i < len(args):
                new_scope[param] = args[i]
        
        interpreter.current_scope = new_scope
        
        try:
            # Выполняем тело функции
            result = None
            for stmt in self.body:
                result = interpreter.visit(stmt)
                if isinstance(result, ReturnValue):
                    return result.value
            return result
        finally:
            interpreter.current_scope = old_scope

class ReturnValue:
    def __init__(self, value):
        self.value = value

# ===== ФАЙЛОВЫЕ ОПЕРАЦИИ =====
class WolfFile:
    def __init__(self, file_obj):
        self.file_obj = file_obj
        self.closed = False
    
    def read(self, size=-1):
        """Чтение файла"""
        if self.closed:
            raise WolfFileError("Файл закрыт")
        return self.file_obj.read(size)
    
    def write(self, data):
        """Запись в файл"""
        if self.closed:
            raise WolfFileError("Файл закрыт")
        return self.file_obj.write(data)
    
    def close(self):
        """Закрытие файла"""
        if not self.closed:
            self.file_obj.close()
            self.closed = True
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

# ===== ПРОДВИНУТЫЕ КОЛЛЕКЦИИ =====
class WolfDict:
    def __init__(self, data=None):
        self.data = data or {}
    
    def get(self, key, default=None):
        return self.data.get(key, default)
    
    def keys(self):
        return list(self.data.keys())
    
    def values(self):
        return list(self.data.values())
    
    def items(self):
        return list(self.data.items())
    
    def __getitem__(self, key):
        return self.data[key]
    
    def __setitem__(self, key, value):
        self.data[key] = value
    
    def __len__(self):
        return len(self.data)
    
    def __contains__(self, key):
        return key in self.data

class WolfList:
    def __init__(self, data=None):
        self.data = data or []
    
    def append(self, item):
        self.data.append(item)
    
    def pop(self, index=-1):
        return self.data.pop(index)
    
    def remove(self, item):
        self.data.remove(item)
    
    def insert(self, index, item):
        self.data.insert(index, item)
    
    def sort(self):
        self.data.sort()
    
    def reverse(self):
        self.data.reverse()
    
    def __getitem__(self, index):
        return self.data[index]
    
    def __setitem__(self, index, value):
        self.data[index] = value
    
    def __len__(self):
        return len(self.data)
    
    def __iter__(self):
        return iter(self.data)

# ===== СТРОКОВЫЕ ОПЕРАЦИИ =====
class WolfString:
    def __init__(self, data=""):
        self.data = str(data)
    
    def upper(self):
        """Верхний регистр"""
        return WolfString(self.data.upper())
    
    def lower(self):
        """Нижний регистр"""
        return WolfString(self.data.lower())
    
    def split(self, separator=" "):
        """Разделение строки"""
        return WolfList(self.data.split(separator))
    
    def join(self, iterable):
        """Объединение строк"""
        return WolfString(self.data.join(str(x) for x in iterable))
    
    def replace(self, old, new):
        """Замена подстроки"""
        return WolfString(self.data.replace(old, new))
    
    def startswith(self, prefix):
        """Начинается с"""
        return self.data.startswith(prefix)
    
    def endswith(self, suffix):
        """Заканчивается на"""
        return self.data.endswith(suffix)
    
    def find(self, substring):
        """Поиск подстроки"""
        return self.data.find(substring)
    
    def strip(self):
        """Удаление пробелов"""
        return WolfString(self.data.strip())
    
    def __str__(self):
        return self.data
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, index):
        return self.data[index]

print("🐺 Wolf Core Advanced загружен!")