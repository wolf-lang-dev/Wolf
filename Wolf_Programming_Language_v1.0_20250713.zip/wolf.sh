#!/bin/bash
# Wolf Programming Language v1.0 - Unix/Linux Launcher
# Запуск Wolf на Unix/Linux

cd "$(dirname "$0")"
python3 wolf.py "$@"