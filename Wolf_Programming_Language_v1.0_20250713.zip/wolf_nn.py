"""
Wolf Neural Network Module - Встроенная библиотека нейронных сетей
Полностью самодостаточная реализация нейронных сетей
"""

from typing import List, Optional, Callable, Dict, Any
from dataclasses import dataclass
from wolf_math import Tensor, WolfLinAlg, Activation, Loss, WolfMath, Variable

# ===== БАЗОВЫЕ КЛАССЫ =====

class Layer:
    """Базовый класс для слоев нейронной сети"""
    
    def __init__(self):
        self.parameters = []
        self.training = True
    
    def forward(self, x: Tensor) -> Tensor:
        """Прямое распространение"""
        raise NotImplementedError
    
    def backward(self, grad_output: Tensor) -> Tensor:
        """Обратное распространение"""
        raise NotImplementedError
    
    def get_parameters(self) -> List[Variable]:
        """Получить параметры слоя"""
        return self.parameters
    
    def train(self):
        """Перевести слой в режим обучения"""
        self.training = True
    
    def eval(self):
        """Перевести слой в режим инференса"""
        self.training = False

# ===== ЛИНЕЙНЫЙ СЛОЙ =====

class Linear(Layer):
    """Линейный (полносвязный) слой"""
    
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.use_bias = bias
        
        # Инициализация весов (Xavier/Glorot)
        limit = WolfMath.sqrt(6.0 / (in_features + out_features))
        self.weight = Variable(
            WolfLinAlg.randn((out_features, in_features), seed=42) * limit,
            requires_grad=True
        )
        self.parameters.append(self.weight)
        
        if bias:
            self.bias = Variable(
                WolfLinAlg.zeros((out_features,)),
                requires_grad=True
            )
            self.parameters.append(self.bias)
        else:
            self.bias = None
    
    def forward(self, x: Tensor) -> Tensor:
        """Прямое распространение: y = xW^T + b"""
        if x.shape.ndim == 1:
            x = x.reshape((1, x.shape.dims[0]))
        
        if x.shape.dims[1] != self.in_features:
            raise ValueError(f"Размер входа {x.shape.dims[1]} не соответствует ожидаемому {self.in_features}")
        
        # Матричное умножение
        output = x.dot(self.weight.tensor.transpose())
        
        if self.use_bias:
            # Добавляем bias ко всем строкам
            for i in range(output.shape.dims[0]):
                for j in range(output.shape.dims[1]):
                    output[i, j] = output[i, j] + self.bias.tensor[j]
        
        return output
    
    def __str__(self) -> str:
        return f"Linear(in_features={self.in_features}, out_features={self.out_features}, bias={self.use_bias})"

# ===== АКТИВАЦИИ =====

class ReLU(Layer):
    """Слой ReLU активации"""
    
    def forward(self, x: Tensor) -> Tensor:
        return Activation.relu(x)
    
    def __str__(self) -> str:
        return "ReLU()"

class Sigmoid(Layer):
    """Слой Sigmoid активации"""
    
    def forward(self, x: Tensor) -> Tensor:
        return Activation.sigmoid(x)
    
    def __str__(self) -> str:
        return "Sigmoid()"

class Tanh(Layer):
    """Слой Tanh активации"""
    
    def forward(self, x: Tensor) -> Tensor:
        return Activation.tanh(x)
    
    def __str__(self) -> str:
        return "Tanh()"

class Softmax(Layer):
    """Слой Softmax активации"""
    
    def forward(self, x: Tensor) -> Tensor:
        if x.shape.ndim == 2:
            # Применяем softmax к каждой строке
            result_data = []
            for i in range(x.shape.dims[0]):
                row = Tensor([x[i, j] for j in range(x.shape.dims[1])])
                softmax_row = Activation.softmax(row)
                result_data.extend(softmax_row.data)
            return Tensor(result_data, x.shape.dims)
        else:
            return Activation.softmax(x)
    
    def __str__(self) -> str:
        return "Softmax()"

# ===== НЕЙРОННАЯ СЕТЬ =====

class NeuralNetwork:
    """Класс нейронной сети"""
    
    def __init__(self, layers: List[Layer]):
        self.layers = layers
        self.training = True
    
    def forward(self, x: Tensor) -> Tensor:
        """Прямое распространение через всю сеть"""
        for layer in self.layers:
            x = layer.forward(x)
        return x
    
    def predict(self, x: Tensor) -> Tensor:
        """Предсказание (инференс)"""
        self.eval()
        result = self.forward(x)
        self.train()
        return result
    
    def get_parameters(self) -> List[Variable]:
        """Получить все параметры сети"""
        params = []
        for layer in self.layers:
            params.extend(layer.get_parameters())
        return params
    
    def train(self):
        """Перевести сеть в режим обучения"""
        self.training = True
        for layer in self.layers:
            layer.train()
    
    def eval(self):
        """Перевести сеть в режим инференса"""
        self.training = False
        for layer in self.layers:
            layer.eval()
    
    def __str__(self) -> str:
        layers_str = "\n  ".join(str(layer) for layer in self.layers)
        return f"NeuralNetwork(\n  {layers_str}\n)"

# ===== ОПТИМИЗАТОРЫ =====

class Optimizer:
    """Базовый класс для оптимизаторов"""
    
    def __init__(self, parameters: List[Variable]):
        self.parameters = parameters
    
    def step(self):
        """Шаг оптимизации"""
        raise NotImplementedError
    
    def zero_grad(self):
        """Обнулить градиенты"""
        for param in self.parameters:
            param.grad = None

class SGD(Optimizer):
    """Стохастический градиентный спуск"""
    
    def __init__(self, parameters: List[Variable], lr: float = 0.01, momentum: float = 0.0):
        super().__init__(parameters)
        self.lr = lr
        self.momentum = momentum
        self.velocities = [WolfLinAlg.zeros(param.tensor.shape.dims) for param in parameters]
    
    def step(self):
        """Шаг SGD"""
        for i, param in enumerate(self.parameters):
            if param.grad is not None:
                # Обновление с momentum
                if self.momentum > 0:
                    self.velocities[i] = self.velocities[i] * self.momentum + param.grad.tensor * self.lr
                    param.tensor = param.tensor - self.velocities[i]
                else:
                    param.tensor = param.tensor - param.grad.tensor * self.lr

class Adam(Optimizer):
    """Оптимизатор Adam"""
    
    def __init__(self, parameters: List[Variable], lr: float = 0.001, beta1: float = 0.9, beta2: float = 0.999, eps: float = 1e-8):
        super().__init__(parameters)
        self.lr = lr
        self.beta1 = beta1
        self.beta2 = beta2
        self.eps = eps
        self.step_count = 0
        
        # Моменты первого и второго порядка
        self.m = [WolfLinAlg.zeros(param.tensor.shape.dims) for param in parameters]
        self.v = [WolfLinAlg.zeros(param.tensor.shape.dims) for param in parameters]
    
    def step(self):
        """Шаг Adam"""
        self.step_count += 1
        
        for i, param in enumerate(self.parameters):
            if param.grad is not None:
                # Обновление моментов
                self.m[i] = self.m[i] * self.beta1 + param.grad.tensor * (1 - self.beta1)
                self.v[i] = self.v[i] * self.beta2 + (param.grad.tensor * param.grad.tensor) * (1 - self.beta2)
                
                # Коррекция смещения
                m_corrected = self.m[i] * (1 / (1 - self.beta1 ** self.step_count))
                v_corrected = self.v[i] * (1 / (1 - self.beta2 ** self.step_count))
                
                # Обновление параметров
                # v_corrected_sqrt = sqrt(v_corrected) + eps
                v_corrected_sqrt = Tensor([WolfMath.sqrt(val) + self.eps for val in v_corrected.data], v_corrected.shape.dims)
                update = m_corrected / v_corrected_sqrt * self.lr
                param.tensor = param.tensor - update

# ===== ОБУЧЕНИЕ =====

class Trainer:
    """Класс для обучения нейронной сети"""
    
    def __init__(self, model: NeuralNetwork, optimizer: Optimizer, loss_fn: str = "mse"):
        self.model = model
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.history = {"loss": [], "accuracy": []}
    
    def train_step(self, x: Tensor, y: Tensor) -> float:
        """Один шаг обучения"""
        # Прямое распространение
        output = self.model.forward(x)
        
        # Вычисление потерь
        if self.loss_fn == "mse":
            loss = Loss.mse(y, output)
        elif self.loss_fn == "cross_entropy":
            loss = Loss.cross_entropy(y, output)
        else:
            raise ValueError(f"Неизвестная функция потерь: {self.loss_fn}")
        
        # Обратное распространение (упрощенная версия)
        # В полной реализации здесь была бы автоматическая дифференциация
        
        # Обнуление градиентов
        self.optimizer.zero_grad()
        
        # Простое обновление градиентов для демонстрации
        # В реальности здесь должен быть вызов loss.backward()
        
        # Шаг оптимизации
        self.optimizer.step()
        
        return loss
    
    def train(self, x_train: Tensor, y_train: Tensor, epochs: int = 100, batch_size: int = 32, verbose: bool = True):
        """Обучение модели"""
        n_samples = x_train.shape.dims[0]
        
        for epoch in range(epochs):
            total_loss = 0.0
            n_batches = 0
            
            # Простая реализация батчей
            for i in range(0, n_samples, batch_size):
                end_idx = min(i + batch_size, n_samples)
                
                # Извлечение батча
                x_batch = Tensor(
                    x_train.data[i * x_train.shape.dims[1]:(end_idx) * x_train.shape.dims[1]],
                    (end_idx - i, x_train.shape.dims[1])
                )
                y_batch = Tensor(
                    y_train.data[i * y_train.shape.dims[1]:(end_idx) * y_train.shape.dims[1]],
                    (end_idx - i, y_train.shape.dims[1])
                )
                
                # Шаг обучения
                loss = self.train_step(x_batch, y_batch)
                total_loss += loss
                n_batches += 1
            
            avg_loss = total_loss / n_batches
            self.history["loss"].append(avg_loss)
            
            if verbose and epoch % 10 == 0:
                print(f"Epoch {epoch + 1}/{epochs}, Loss: {avg_loss:.4f}")
    
    def evaluate(self, x_test: Tensor, y_test: Tensor) -> Dict[str, float]:
        """Оценка модели"""
        self.model.eval()
        
        # Предсказание
        predictions = self.model.predict(x_test)
        
        # Вычисление потерь
        if self.loss_fn == "mse":
            loss = Loss.mse(y_test, predictions)
        elif self.loss_fn == "cross_entropy":
            loss = Loss.cross_entropy(y_test, predictions)
        else:
            loss = 0.0
        
        # Точность для классификации
        accuracy = 0.0
        if y_test.shape.dims[1] > 1:  # многоклассовая классификация
            correct = 0
            for i in range(y_test.shape.dims[0]):
                # Находим индекс максимального элемента
                pred_class = 0
                true_class = 0
                max_pred = predictions[i, 0]
                max_true = y_test[i, 0]
                
                for j in range(y_test.shape.dims[1]):
                    if predictions[i, j] > max_pred:
                        max_pred = predictions[i, j]
                        pred_class = j
                    if y_test[i, j] > max_true:
                        max_true = y_test[i, j]
                        true_class = j
                
                if pred_class == true_class:
                    correct += 1
            
            accuracy = correct / y_test.shape.dims[0]
        
        self.model.train()
        return {"loss": loss, "accuracy": accuracy}

# ===== ГОТОВЫЕ АРХИТЕКТУРЫ =====

class MLP:
    """Многослойный перцептрон"""
    
    @staticmethod
    def create(input_size: int, hidden_sizes: List[int], output_size: int, activation: str = "relu") -> NeuralNetwork:
        """Создать MLP"""
        layers = []
        
        # Входной слой
        layers.append(Linear(input_size, hidden_sizes[0]))
        
        # Активация
        if activation == "relu":
            layers.append(ReLU())
        elif activation == "sigmoid":
            layers.append(Sigmoid())
        elif activation == "tanh":
            layers.append(Tanh())
        
        # Скрытые слои
        for i in range(1, len(hidden_sizes)):
            layers.append(Linear(hidden_sizes[i-1], hidden_sizes[i]))
            if activation == "relu":
                layers.append(ReLU())
            elif activation == "sigmoid":
                layers.append(Sigmoid())
            elif activation == "tanh":
                layers.append(Tanh())
        
        # Выходной слой
        layers.append(Linear(hidden_sizes[-1], output_size))
        
        return NeuralNetwork(layers)

# ===== ДАТАСЕТЫ =====

class Dataset:
    """Класс для работы с датасетами"""
    
    def __init__(self, x: Tensor, y: Tensor):
        self.x = x
        self.y = y
        self.size = x.shape.dims[0]
    
    def __len__(self) -> int:
        return self.size
    
    def __getitem__(self, idx: int) -> tuple:
        return (self.x[idx], self.y[idx])
    
    def shuffle(self, seed: int = 42):
        """Перемешать датасет"""
        # Простая реализация перемешивания
        indices = list(range(self.size))
        
        # Алгоритм Фишера-Йетса
        current_seed = seed
        for i in range(self.size - 1, 0, -1):
            # Простой линейный конгруэнтный генератор
            current_seed = (current_seed * 1103515245 + 12345) % (2**31)
            j = current_seed % (i + 1)
            indices[i], indices[j] = indices[j], indices[i]
        
        # Перестановка данных
        new_x_data = []
        new_y_data = []
        
        for idx in indices:
            for j in range(self.x.shape.dims[1]):
                new_x_data.append(self.x[idx, j])
            for j in range(self.y.shape.dims[1]):
                new_y_data.append(self.y[idx, j])
        
        self.x = Tensor(new_x_data, self.x.shape.dims)
        self.y = Tensor(new_y_data, self.y.shape.dims)
    
    def split(self, test_size: float = 0.2) -> tuple:
        """Разделить датасет на тренировочный и тестовый"""
        test_samples = int(self.size * test_size)
        train_samples = self.size - test_samples
        
        # Тренировочная выборка
        x_train_data = self.x.data[:train_samples * self.x.shape.dims[1]]
        y_train_data = self.y.data[:train_samples * self.y.shape.dims[1]]
        
        x_train = Tensor(x_train_data, (train_samples, self.x.shape.dims[1]))
        y_train = Tensor(y_train_data, (train_samples, self.y.shape.dims[1]))
        
        # Тестовая выборка
        x_test_data = self.x.data[train_samples * self.x.shape.dims[1]:]
        y_test_data = self.y.data[train_samples * self.y.shape.dims[1]:]
        
        x_test = Tensor(x_test_data, (test_samples, self.x.shape.dims[1]))
        y_test = Tensor(y_test_data, (test_samples, self.y.shape.dims[1]))
        
        return Dataset(x_train, y_train), Dataset(x_test, y_test)

# ===== ВСТРОЕННЫЕ ДАТАСЕТЫ =====

class BuiltinDatasets:
    """Встроенные датасеты"""
    
    @staticmethod
    def make_classification(n_samples: int = 100, n_features: int = 2, n_classes: int = 2, seed: int = 42) -> Dataset:
        """Создать синтетический датасет для классификации"""
        # Генерация случайных данных
        x = WolfLinAlg.randn((n_samples, n_features), seed)
        
        # Создание классов
        y_data = []
        current_seed = seed
        
        for i in range(n_samples):
            # Простая линейная граница
            if n_classes == 2:
                if x[i, 0] + x[i, 1] > 0:
                    y_data.extend([1, 0])  # one-hot encoding
                else:
                    y_data.extend([0, 1])
            else:
                # Для многоклассовой классификации
                current_seed = (current_seed * 1103515245 + 12345) % (2**31)
                class_idx = current_seed % n_classes
                one_hot = [0] * n_classes
                one_hot[class_idx] = 1
                y_data.extend(one_hot)
        
        y = Tensor(y_data, (n_samples, n_classes))
        return Dataset(x, y)
    
    @staticmethod
    def make_regression(n_samples: int = 100, n_features: int = 1, noise: float = 0.1, seed: int = 42) -> Dataset:
        """Создать синтетический датасет для регрессии"""
        x = WolfLinAlg.randn((n_samples, n_features), seed)
        
        # Создание целевых значений (простая линейная зависимость)
        y_data = []
        noise_tensor = WolfLinAlg.randn((n_samples, 1), seed + 1) * noise
        
        for i in range(n_samples):
            # y = sum(x_i) + noise
            y_val = sum(x[i, j] for j in range(n_features)) + noise_tensor[i, 0]
            y_data.append(y_val)
        
        y = Tensor(y_data, (n_samples, 1))
        return Dataset(x, y)
    
    @staticmethod
    def xor_dataset() -> Dataset:
        """Классический XOR датасет"""
        x_data = [
            0, 0,
            0, 1,
            1, 0,
            1, 1
        ]
        y_data = [
            0, 1,  # XOR(0,0) = 0
            1, 0,  # XOR(0,1) = 1
            1, 0,  # XOR(1,0) = 1
            0, 1   # XOR(1,1) = 0
        ]
        
        x = Tensor(x_data, (4, 2))
        y = Tensor(y_data, (4, 2))
        return Dataset(x, y)

# ===== УТИЛИТЫ =====

class ModelUtils:
    """Утилиты для работы с моделями"""
    
    @staticmethod
    def count_parameters(model: NeuralNetwork) -> int:
        """Подсчитать количество параметров в модели"""
        total = 0
        for param in model.get_parameters():
            total += param.tensor.shape.size
        return total
    
    @staticmethod
    def save_model(model: NeuralNetwork, filepath: str):
        """Сохранить модель (упрощенная версия)"""
        # В реальной реализации здесь была бы сериализация
        print(f"Модель сохранена в {filepath}")
    
    @staticmethod
    def load_model(filepath: str) -> NeuralNetwork:
        """Загрузить модель (упрощенная версия)"""
        # В реальной реализации здесь была бы десериализация
        print(f"Модель загружена из {filepath}")
        return MLP.create(2, [4, 4], 2)

# ===== ТЕСТИРОВАНИЕ =====

if __name__ == "__main__":
    print("=== Тестирование Wolf Neural Network ===")
    
    # Создание простой модели
    model = MLP.create(input_size=2, hidden_sizes=[4, 4], output_size=2, activation="relu")
    print(f"Модель:\n{model}")
    print(f"Количество параметров: {ModelUtils.count_parameters(model)}")
    
    # Создание датасета
    print("\n=== Создание XOR датасета ===")
    dataset = BuiltinDatasets.xor_dataset()
    print(f"X: {dataset.x}")
    print(f"Y: {dataset.y}")
    
    # Разделение на train/test
    train_dataset, test_dataset = dataset.split(test_size=0.25)
    print(f"Train size: {len(train_dataset)}, Test size: {len(test_dataset)}")
    
    # Создание оптимизатора
    optimizer = SGD(model.get_parameters(), lr=0.01)
    
    # Создание тренера
    trainer = Trainer(model, optimizer, loss_fn="cross_entropy")
    
    # Обучение
    print("\n=== Обучение модели ===")
    trainer.train(train_dataset.x, train_dataset.y, epochs=50, batch_size=4, verbose=True)
    
    # Оценка
    print("\n=== Оценка модели ===")
    results = trainer.evaluate(test_dataset.x, test_dataset.y)
    print(f"Test Loss: {results['loss']:.4f}, Test Accuracy: {results['accuracy']:.4f}")
    
    # Предсказание
    print("\n=== Предсказания ===")
    predictions = model.predict(test_dataset.x)
    print(f"Predictions: {predictions}")
    print(f"True labels: {test_dataset.y}")
    
    # Тестирование других датасетов
    print("\n=== Тестирование синтетических датасетов ===")
    
    # Классификация
    clf_dataset = BuiltinDatasets.make_classification(n_samples=100, n_features=2, n_classes=2)
    print(f"Classification dataset: X shape = {clf_dataset.x.shape.dims}, Y shape = {clf_dataset.y.shape.dims}")
    
    # Регрессия
    reg_dataset = BuiltinDatasets.make_regression(n_samples=100, n_features=1, noise=0.1)
    print(f"Regression dataset: X shape = {reg_dataset.x.shape.dims}, Y shape = {reg_dataset.y.shape.dims}")
    
    # Создание регрессионной модели
    reg_model = MLP.create(input_size=1, hidden_sizes=[8], output_size=1, activation="relu")
    reg_optimizer = Adam(reg_model.get_parameters(), lr=0.001)
    reg_trainer = Trainer(reg_model, reg_optimizer, loss_fn="mse")
    
    # Разделение датасета
    reg_train, reg_test = reg_dataset.split(test_size=0.2)
    
    # Обучение регрессии
    print("\n=== Обучение регрессионной модели ===")
    reg_trainer.train(reg_train.x, reg_train.y, epochs=100, batch_size=16, verbose=True)
    
    # Оценка регрессии
    reg_results = reg_trainer.evaluate(reg_test.x, reg_test.y)
    print(f"Regression Test Loss: {reg_results['loss']:.4f}")
    
    print("\n=== Тестирование завершено ===")