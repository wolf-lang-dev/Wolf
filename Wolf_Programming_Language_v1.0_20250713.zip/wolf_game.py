#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Wolf Programming Language - Game Module
Игровая библиотека для создания 2D игр
"""

try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError:
    PYGAME_AVAILABLE = False
    print("⚠️ pygame не установлен. Установите: pip install pygame")

import math
import random
from typing import Tuple, List, Optional, Callable
from dataclasses import dataclass

@dataclass
class WolfColor:
    """Цвета для Wolf Game"""
    ЧЕРНЫЙ = (0, 0, 0)
    БЕЛЫЙ = (255, 255, 255)
    КРАСНЫЙ = (255, 0, 0)
    ЗЕЛЕНЫЙ = (0, 255, 0)
    СИНИЙ = (0, 0, 255)
    ЖЕЛТЫЙ = (255, 255, 0)
    ФИОЛЕТОВЫЙ = (255, 0, 255)
    ЦИАН = (0, 255, 255)
    СЕРЫЙ = (128, 128, 128)

class WolfSprite:
    """Спрайт в Wolf Game"""
    
    def __init__(self, x: float, y: float, ширина: int, высота: int, цвет: Tuple[int, int, int]):
        self.x = x
        self.y = y
        self.ширина = ширина
        self.высота = высота
        self.цвет = цвет
        self.скорость_x = 0
        self.скорость_y = 0
        self.видимый = True
        self.изображение = None
        
    def установить_позицию(self, x: float, y: float):
        """Установить позицию спрайта"""
        self.x = x
        self.y = y
    
    def двигать(self, dx: float, dy: float):
        """Переместить спрайт"""
        self.x += dx
        self.y += dy
    
    def установить_скорость(self, скорость_x: float, скорость_y: float):
        """Установить скорость спрайта"""
        self.скорость_x = скорость_x
        self.скорость_y = скорость_y
    
    def обновить(self):
        """Обновить позицию спрайта"""
        self.x += self.скорость_x
        self.y += self.скорость_y
    
    def загрузить_изображение(self, путь: str):
        """Загрузить изображение для спрайта"""
        if PYGAME_AVAILABLE:
            try:
                self.изображение = pygame.image.load(путь)
                self.ширина = self.изображение.get_width()
                self.высота = self.изображение.get_height()
                return True
            except:
                print(f"❌ Не удалось загрузить изображение: {путь}")
                return False
        return False
    
    def столкновение_с(self, другой_спрайт) -> bool:
        """Проверить столкновение с другим спрайтом"""
        return (self.x < другой_спрайт.x + другой_спрайт.ширина and
                self.x + self.ширина > другой_спрайт.x and
                self.y < другой_спрайт.y + другой_спрайт.высота and
                self.y + self.высота > другой_спрайт.y)
    
    def в_границах_экрана(self, ширина_экрана: int, высота_экрана: int) -> bool:
        """Проверить, находится ли спрайт в границах экрана"""
        return (0 <= self.x <= ширина_экрана - self.ширина and
                0 <= self.y <= высота_экрана - self.высота)

class WolfGame:
    """Основной класс игры Wolf"""
    
    def __init__(self):
        self.экран = None
        self.часы = None
        self.запущена = False
        self.ширина = 800
        self.высота = 600
        self.fps = 60
        self.спрайты = []
        self.обработчики_событий = {}
        self.фон_цвет = WolfColor.ЧЕРНЫЙ
    
    @staticmethod
    def create_game(название: str, ширина: int, высота: int):
        """Создать новую игру"""
        игра = WolfGame()
        if игра.создать_экран(ширина, высота, название):
            return игра
        return None
    
    @staticmethod
    def create_sprite(*args, **kwargs):
        """Создать спрайт (заглушка)"""
        print("⚠️ Функция create_sprite в разработке")
        return None
    
    @staticmethod
    def load_sound(*args, **kwargs):
        """Загрузить звук (заглушка)"""
        print("⚠️ Функция load_sound в разработке")
        return None
    
    @staticmethod
    def play_music(*args, **kwargs):
        """Воспроизвести музыку (заглушка)"""
        print("⚠️ Функция play_music в разработке")
        return None
    
    @staticmethod
    def run(*args, **kwargs):
        """Запустить игру (заглушка)"""
        print("⚠️ Функция run в разработке")
        return None
    
    # Псевдоним для WolfColor
    Color = None  # Будет инициализирован ниже
        
    def создать_экран(self, ширина: int, высота: int, заголовок: str = "Wolf Game") -> bool:
        """Создать игровое окно"""
        if not PYGAME_AVAILABLE:
            print("❌ pygame недоступен")
            return False
        
        try:
            pygame.init()
            self.экран = pygame.display.set_mode((ширина, высота))
            pygame.display.set_caption(заголовок)
            self.часы = pygame.time.Clock()
            self.ширина = ширина
            self.высота = высота
            self.запущена = True
            print(f"✅ Игровое окно создано: {ширина}x{высота}")
            return True
        except Exception as e:
            print(f"❌ Ошибка создания окна: {e}")
            return False
    
    def создать_спрайт(self, x: float, y: float, ширина: int, высота: int, 
                       цвет: Tuple[int, int, int] = WolfColor.БЕЛЫЙ) -> WolfSprite:
        """Создать новый спрайт"""
        спрайт = WolfSprite(x, y, ширина, высота, цвет)
        self.спрайты.append(спрайт)
        return спрайт
    
    def загрузить_спрайт(self, путь: str, x: float, y: float) -> Optional[WolfSprite]:
        """Загрузить спрайт из файла"""
        спрайт = WolfSprite(x, y, 32, 32, WolfColor.БЕЛЫЙ)
        if спрайт.загрузить_изображение(путь):
            self.спрайты.append(спрайт)
            return спрайт
        return None
    
    def удалить_спрайт(self, спрайт: WolfSprite):
        """Удалить спрайт"""
        if спрайт in self.спрайты:
            self.спрайты.remove(спрайт)
    
    def установить_фон(self, цвет: Tuple[int, int, int]):
        """Установить цвет фона"""
        self.фон_цвет = цвет
    
    def установить_fps(self, fps: int):
        """Установить частоту кадров"""
        self.fps = fps
    
    def добавить_обработчик(self, событие: str, функция: Callable):
        """Добавить обработчик события"""
        self.обработчики_событий[событие] = функция
    
    def _обработать_события(self):
        """Обработать события pygame"""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.запущена = False
            elif event.type == pygame.KEYDOWN:
                if 'нажатие_клавиши' in self.обработчики_событий:
                    self.обработчики_событий['нажатие_клавиши'](event.key)
            elif event.type == pygame.KEYUP:
                if 'отпускание_клавиши' in self.обработчики_событий:
                    self.обработчики_событий['отпускание_клавиши'](event.key)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if 'клик_мыши' in self.обработчики_событий:
                    self.обработчики_событий['клик_мыши'](event.pos, event.button)
    
    def _обновить_спрайты(self):
        """Обновить все спрайты"""
        for спрайт in self.спрайты:
            спрайт.обновить()
    
    def _отрисовать(self):
        """Отрисовать все объекты"""
        if not self.экран:
            return
        
        # Очистить экран
        self.экран.fill(self.фон_цвет)
        
        # Отрисовать спрайты
        for спрайт in self.спрайты:
            if спрайт.видимый:
                if спрайт.изображение:
                    self.экран.blit(спрайт.изображение, (int(спрайт.x), int(спрайт.y)))
                else:
                    pygame.draw.rect(self.экран, спрайт.цвет,
                                   (int(спрайт.x), int(спрайт.y), 
                                    спрайт.ширина, спрайт.высота))
        
        # Обновить экран
        pygame.display.flip()
    
    def запустить(self, функция_обновления: Callable = None):
        """Запустить главный игровой цикл"""
        if not self.экран:
            print("❌ Экран не создан")
            return
        
        print("🎮 Игра запущена! Нажмите ESC или закройте окно для выхода")
        
        while self.запущена:
            # Обработка событий
            self._обработать_события()
            
            # Пользовательская функция обновления
            if функция_обновления:
                try:
                    функция_обновления()
                except Exception as e:
                    print(f"❌ Ошибка в функции обновления: {e}")
            
            # Обновление спрайтов
            self._обновить_спрайты()
            
            # Отрисовка
            self._отрисовать()
            
            # Контроль FPS
            self.часы.tick(self.fps)
        
        # Завершение
        pygame.quit()
        print("🔚 Игра завершена")
    
    def остановить(self):
        """Остановить игру"""
        self.запущена = False
    
    def нарисовать_текст(self, текст: str, x: int, y: int, размер: int = 24, 
                         цвет: Tuple[int, int, int] = WolfColor.БЕЛЫЙ):
        """Нарисовать текст на экране"""
        if not PYGAME_AVAILABLE or not self.экран:
            return
        
        try:
            font = pygame.font.Font(None, размер)
            text_surface = font.render(текст, True, цвет)
            self.экран.blit(text_surface, (x, y))
        except Exception as e:
            print(f"❌ Ошибка отрисовки текста: {e}")
    
    def нарисовать_линию(self, start: Tuple[int, int], end: Tuple[int, int], 
                         цвет: Tuple[int, int, int] = WolfColor.БЕЛЫЙ, толщина: int = 1):
        """Нарисовать линию"""
        if not PYGAME_AVAILABLE or not self.экран:
            return
        
        pygame.draw.line(self.экран, цвет, start, end, толщина)
    
    def нарисовать_круг(self, центр: Tuple[int, int], радиус: int, 
                        цвет: Tuple[int, int, int] = WolfColor.БЕЛЫЙ):
        """Нарисовать круг"""
        if not PYGAME_AVAILABLE or not self.экран:
            return
        
        pygame.draw.circle(self.экран, цвет, центр, радиус)

# Глобальный экземпляр игры
game = WolfGame()

# Функции для использования в Wolf
def создать_экран(ширина: int, высота: int, заголовок: str = "Wolf Game") -> bool:
    """Создать игровое окно"""
    return game.создать_экран(ширина, высота, заголовок)

def создать_спрайт(x: float, y: float, ширина: int, высота: int, 
                   цвет: Tuple[int, int, int] = WolfColor.БЕЛЫЙ) -> WolfSprite:
    """Создать спрайт"""
    return game.создать_спрайт(x, y, ширина, высота, цвет)

def загрузить_спрайт(путь: str, x: float, y: float) -> Optional[WolfSprite]:
    """Загрузить спрайт из файла"""
    return game.загрузить_спрайт(путь, x, y)

def установить_фон(цвет: Tuple[int, int, int]):
    """Установить цвет фона"""
    game.установить_фон(цвет)

def запустить_игру(функция_обновления: Callable = None):
    """Запустить игру"""
    game.запустить(функция_обновления)

def остановить_игру():
    """Остановить игру"""
    game.остановить()

def доступна_игровая_библиотека() -> bool:
    """Проверить доступность pygame"""
    return PYGAME_AVAILABLE

# Примеры игр
def пример_простая_игра():
    """Пример простой игры с движущимся квадратом"""
    if not создать_экран(800, 600, "Простая игра Wolf"):
        return
    
    # Создаем игрока
    игрок = создать_спрайт(375, 275, 50, 50, WolfColor.ЗЕЛЕНЫЙ)
    
    def обновление():
        # Получаем нажатые клавиши
        keys = pygame.key.get_pressed()
        
        # Управление
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            игрок.x -= 5
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            игрок.x += 5
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            игрок.y -= 5
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            игрок.y += 5
        
        # Ограничение движения границами экрана
        игрок.x = max(0, min(750, игрок.x))
        игрок.y = max(0, min(550, игрок.y))
        
        # Отображение инструкций
        game.нарисовать_текст("Используйте WASD или стрелки для движения", 10, 10)
        game.нарисовать_текст("ESC - выход", 10, 40)
    
    запустить_игру(обновление)

def пример_игра_змейка():
    """Пример игры Змейка"""
    if not создать_экран(600, 600, "Змейка Wolf"):
        return
    
    установить_фон(WolfColor.ЧЕРНЫЙ)
    
    # Игровые переменные
    размер_клетки = 20
    змея = [(300, 300)]
    направление = (размер_клетки, 0)
    еда = (random.randint(0, 29) * размер_клетки, random.randint(0, 29) * размер_клетки)
    счет = 0
    
    def обновление():
        nonlocal направление, еда, счет, змея
        
        # Обработка клавиш
        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP] and направление != (0, размер_клетки):
            направление = (0, -размер_клетки)
        elif keys[pygame.K_DOWN] and направление != (0, -размер_клетки):
            направление = (0, размер_клетки)
        elif keys[pygame.K_LEFT] and направление != (размер_клетки, 0):
            направление = (-размер_клетки, 0)
        elif keys[pygame.K_RIGHT] and направление != (-размер_клетки, 0):
            направление = (размер_клетки, 0)
        
        # Движение змеи
        голова = (змея[0][0] + направление[0], змея[0][1] + направление[1])
        
        # Проверка границ
        if (голова[0] < 0 or голова[0] >= 600 or 
            голова[1] < 0 or голова[1] >= 600 or 
            голова in змея):
            # Игра окончена
            game.нарисовать_текст("ИГРА ОКОНЧЕНА!", 200, 250, 36, WolfColor.КРАСНЫЙ)
            game.нарисовать_текст(f"Счет: {счет}", 250, 300, 24, WolfColor.БЕЛЫЙ)
            return
        
        змея.insert(0, голова)
        
        # Проверка поедания еды
        if голова == еда:
            счет += 1
            еда = (random.randint(0, 29) * размер_клетки, random.randint(0, 29) * размер_клетки)
        else:
            змея.pop()
        
        # Отрисовка змеи
        for сегмент in змея:
            game.нарисовать_круг((сегмент[0] + размер_клетки//2, 
                                 сегмент[1] + размер_клетки//2), 
                                размер_клетки//2, WolfColor.ЗЕЛЕНЫЙ)
        
        # Отрисовка еды
        game.нарисовать_круг((еда[0] + размер_клетки//2, 
                             еда[1] + размер_клетки//2), 
                            размер_клетки//2, WolfColor.КРАСНЫЙ)
        
        # Счет
        game.нарисовать_текст(f"Счет: {счет}", 10, 10, 24, WolfColor.БЕЛЫЙ)
    
    запустить_игру(обновление)

if __name__ == "__main__":
    print("🐺 Wolf Game Module - Demo")
    print("=" * 40)
    
    if доступна_игровая_библиотека():
        print("✅ pygame доступен")
        print("\nВыберите демонстрацию:")
        print("1. Простая игра (движущийся квадрат)")
        print("2. Змейка")
        
        choice = input("\nВаш выбор (1-2): ").strip()
        
        if choice == "1":
            пример_простая_игра()
        elif choice == "2":
            пример_игра_змейка()
        else:
            print("❌ Неверный выбор")
    else:
        print("❌ pygame недоступен")
        choice = input("📥 Установить pygame? (y/n): ").lower()
        if choice == 'y':
            import subprocess
            import sys
            try:
                subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'pygame'])
                print("✅ pygame установлен. Перезапустите программу.")
            except subprocess.CalledProcessError as e:
                print(f"❌ Ошибка установки: {e}")

# Инициализация псевдонима Color
WolfGame.Color = WolfColor