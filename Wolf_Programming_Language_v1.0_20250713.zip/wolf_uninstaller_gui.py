"""
Wolf Programming Language v1.0 - GUI Uninstaller
Графический деинсталлятор Wolf с поддержкой иконок
"""

import os
import sys
import shutil
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
import winreg
import subprocess

class WolfUninstaller:
    """GUI Деинсталлятор Wolf Programming Language"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Wolf Programming Language v1.0 - Деинсталлятор")
        self.root.geometry("500x400")
        self.root.resizable(False, False)
        
        # Пытаемся загрузить иконку деинсталлятора
        try:
            icon_path = Path(__file__).parent / "Wolf Uninstaller.ico"
            if icon_path.exists():
                self.root.iconbitmap(str(icon_path))
        except:
            pass  # Игнорируем ошибки иконки
        
        self.progress_var = tk.DoubleVar()
        self.status_var = tk.StringVar(value="Готов к деинсталляции")
        
        # Поиск установленных версий Wolf
        self.wolf_installations = self.find_wolf_installations()
        
        self.setup_ui()
    
    def find_wolf_installations(self):
        """Поиск установленных версий Wolf"""
        installations = []
        
        # Стандартные пути
        common_paths = [
            Path.home() / "Wolf",
            Path("C:/Program Files/Wolf"),
            Path("C:/Wolf"),
            Path(os.path.expanduser("~/AppData/Local/Wolf"))
        ]
        
        for path in common_paths:
            if path.exists() and (path / "wolf.py").exists():
                installations.append(path)
        
        # Поиск в PATH
        try:
            path_env = os.environ.get("PATH", "")
            for path_dir in path_env.split(os.pathsep):
                wolf_path = Path(path_dir)
                if wolf_path.exists() and (wolf_path / "wolf.py").exists():
                    if wolf_path not in installations:
                        installations.append(wolf_path)
        except:
            pass
        
        return installations
    
    def setup_ui(self):
        """Настройка интерфейса"""
        # Заголовок
        title_frame = ttk.Frame(self.root)
        title_frame.pack(fill="x", padx=20, pady=20)
        
        ttk.Label(
            title_frame,
            text="🗑️ Wolf Programming Language v1.0",
            font=("Arial", 16, "bold")
        ).pack()
        
        ttk.Label(
            title_frame,
            text="Деинсталлятор языка программирования Wolf",
            font=("Arial", 10)
        ).pack()
        
        # Найденные установки
        if self.wolf_installations:
            installations_frame = ttk.LabelFrame(self.root, text="Найденные установки Wolf")
            installations_frame.pack(fill="both", expand=True, padx=20, pady=10)
            
            self.installation_vars = []
            
            for i, installation in enumerate(self.wolf_installations):
                var = tk.BooleanVar(value=True)
                self.installation_vars.append(var)
                
                ttk.Checkbutton(
                    installations_frame,
                    text=str(installation),
                    variable=var
                ).pack(anchor="w", padx=10, pady=5)
        else:
            # Wolf не найден
            not_found_frame = ttk.LabelFrame(self.root, text="Статус")
            not_found_frame.pack(fill="x", padx=20, pady=10)
            
            ttk.Label(
                not_found_frame,
                text="❌ Wolf Programming Language не найден в системе",
                font=("Arial", 12)
            ).pack(padx=20, pady=20)
        
        # Опции удаления
        options_frame = ttk.LabelFrame(self.root, text="Параметры удаления")
        options_frame.pack(fill="x", padx=20, pady=10)
        
        self.remove_from_path = tk.BooleanVar(value=True)
        self.remove_file_associations = tk.BooleanVar(value=True)
        self.remove_shortcuts = tk.BooleanVar(value=True)
        self.remove_registry = tk.BooleanVar(value=True)
        
        ttk.Checkbutton(
            options_frame,
            text="Удалить из PATH системы",
            variable=self.remove_from_path
        ).pack(anchor="w", padx=10, pady=2)
        
        ttk.Checkbutton(
            options_frame,
            text="Удалить ассоциации файлов .wolf",
            variable=self.remove_file_associations
        ).pack(anchor="w", padx=10, pady=2)
        
        ttk.Checkbutton(
            options_frame,
            text="Удалить ярлыки",
            variable=self.remove_shortcuts
        ).pack(anchor="w", padx=10, pady=2)
        
        ttk.Checkbutton(
            options_frame,
            text="Очистить записи реестра",
            variable=self.remove_registry
        ).pack(anchor="w", padx=10, pady=2)
        
        # Прогресс
        progress_frame = ttk.Frame(self.root)
        progress_frame.pack(fill="x", padx=20, pady=10)
        
        ttk.Label(progress_frame, textvariable=self.status_var).pack(anchor="w")
        self.progress_bar = ttk.Progressbar(
            progress_frame,
            variable=self.progress_var,
            maximum=100
        )
        self.progress_bar.pack(fill="x", pady=(5, 0))
        
        # Кнопки
        button_frame = ttk.Frame(self.root)
        button_frame.pack(fill="x", padx=20, pady=20)
        
        if self.wolf_installations:
            ttk.Button(
                button_frame,
                text="Удалить Wolf",
                command=self.uninstall_wolf
            ).pack(side="right", padx=(10, 0))
        
        ttk.Button(
            button_frame,
            text="Отмена",
            command=self.root.quit
        ).pack(side="right")
        
        ttk.Button(
            button_frame,
            text="Обновить список",
            command=self.refresh_installations
        ).pack(side="left")
    
    def refresh_installations(self):
        """Обновление списка установок"""
        self.wolf_installations = self.find_wolf_installations()
        self.root.destroy()
        self.__init__()
        self.run()
    
    def update_progress(self, value: float, status: str):
        """Обновление прогресса"""
        self.progress_var.set(value)
        self.status_var.set(status)
        self.root.update()
    
    def remove_from_system_path(self, install_path: Path):
        """Удаление из PATH системы"""
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                "Environment",
                0,
                winreg.KEY_SET_VALUE | winreg.KEY_READ
            ) as key:
                current_path, _ = winreg.QueryValueEx(key, "PATH")
                install_str = str(install_path)
                
                # Удаляем все вхождения пути Wolf
                new_path = current_path.replace(f";{install_str}", "")
                new_path = new_path.replace(f"{install_str};", "")
                new_path = new_path.replace(install_str, "")
                
                # Очищаем лишние точки с запятой
                while ";;" in new_path:
                    new_path = new_path.replace(";;", ";")
                
                new_path = new_path.strip(";")
                
                winreg.SetValueEx(key, "PATH", 0, winreg.REG_EXPAND_SZ, new_path)
                
        except Exception as e:
            print(f"Ошибка удаления из PATH: {e}")
    
    def remove_file_associations_registry(self):
        """Удаление ассоциаций файлов из реестра"""
        try:
            # Удаляем .wolf расширение
            try:
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\.wolf")
            except FileNotFoundError:
                pass
            
            # Удаляем WolfScript класс
            try:
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\WolfScript\shell\open\command")
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\WolfScript\shell\open")
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\WolfScript\shell")
                winreg.DeleteKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\WolfScript")
            except FileNotFoundError:
                pass
                
        except Exception as e:
            print(f"Ошибка удаления ассоциаций: {e}")
    
    def remove_desktop_shortcuts(self):
        """Удаление ярлыков с рабочего стола"""
        try:
            desktop = Path.home() / "Desktop"
            
            # Список возможных ярлыков Wolf
            shortcuts = [
                "Wolf REPL.lnk",
                "Wolf Programming Language.lnk",
                "Wolf.lnk"
            ]
            
            for shortcut in shortcuts:
                shortcut_path = desktop / shortcut
                if shortcut_path.exists():
                    shortcut_path.unlink()
                    
        except Exception as e:
            print(f"Ошибка удаления ярлыков: {e}")
    
    def clean_registry(self):
        """Очистка записей реестра"""
        try:
            # Удаляем записи Wolf из реестра программ
            registry_paths = [
                r"Software\Microsoft\Windows\CurrentVersion\Uninstall\Wolf",
                r"Software\Classes\Applications\wolf.exe",
                r"Software\Wolf"
            ]
            
            for reg_path in registry_paths:
                try:
                    winreg.DeleteKey(winreg.HKEY_CURRENT_USER, reg_path)
                except FileNotFoundError:
                    pass
                    
        except Exception as e:
            print(f"Ошибка очистки реестра: {e}")
    
    def uninstall_wolf(self):
        """Деинсталляция Wolf"""
        # Подтверждение
        selected_installations = [
            install for i, install in enumerate(self.wolf_installations)
            if self.installation_vars[i].get()
        ]
        
        if not selected_installations:
            messagebox.showwarning("Внимание", "Выберите хотя бы одну установку для удаления")
            return
        
        result = messagebox.askyesno(
            "Подтверждение удаления",
            f"Вы действительно хотите удалить Wolf Programming Language?\n\n"
            f"Будет удалено установок: {len(selected_installations)}\n\n"
            "Это действие нельзя отменить!"
        )
        
        if not result:
            return
        
        try:
            total_steps = len(selected_installations) * 4 + 4  # Установки + общие действия
            current_step = 0
            
            # Удаляем выбранные установки
            for installation in selected_installations:
                current_step += 1
                self.update_progress(
                    (current_step / total_steps) * 100,
                    f"Удаление файлов из {installation}..."
                )
                
                if installation.exists():
                    shutil.rmtree(installation, ignore_errors=True)
                
                current_step += 1
                self.update_progress(
                    (current_step / total_steps) * 100,
                    f"Очистка PATH для {installation}..."
                )
                
                if self.remove_from_path.get():
                    self.remove_from_system_path(installation)
            
            # Общие действия
            if self.remove_file_associations.get():
                current_step += 1
                self.update_progress(
                    (current_step / total_steps) * 100,
                    "Удаление ассоциаций файлов..."
                )
                self.remove_file_associations_registry()
            
            if self.remove_shortcuts.get():
                current_step += 1
                self.update_progress(
                    (current_step / total_steps) * 100,
                    "Удаление ярлыков..."
                )
                self.remove_desktop_shortcuts()
            
            if self.remove_registry.get():
                current_step += 1
                self.update_progress(
                    (current_step / total_steps) * 100,
                    "Очистка реестра..."
                )
                self.clean_registry()
            
            current_step += 1
            self.update_progress(100, "Деинсталляция завершена!")
            
            messagebox.showinfo(
                "Деинсталляция завершена",
                "Wolf Programming Language v1.0 успешно удален из системы!\n\n"
                "Возможно потребуется перезагрузка для полного удаления всех компонентов."
            )
            
            self.root.quit()
            
        except Exception as e:
            messagebox.showerror("Ошибка деинсталляции", f"Произошла ошибка: {e}")
            self.update_progress(0, "Ошибка деинсталляции")
    
    def run(self):
        """Запуск деинсталлятора"""
        self.root.mainloop()

if __name__ == "__main__":
    print("🗑️ Wolf Programming Language v1.0 - Uninstaller")
    uninstaller = WolfUninstaller()
    uninstaller.run()